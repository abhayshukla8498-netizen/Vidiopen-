package com.example.utils

import timber.log.Timber

object Logger {
    fun d(message: String, vararg args: Any) {
        Timber.d(message, *args)
    }

    fun e(throwable: Throwable?, message: String, vararg args: Any) {
        if (throwable != null) {
            Timber.e(throwable, message, *args)
        } else {
            Timber.e(message, *args)
        }
    }

    fun i(message: String, vararg args: Any) {
        Timber.i(message, *args)
    }
}
