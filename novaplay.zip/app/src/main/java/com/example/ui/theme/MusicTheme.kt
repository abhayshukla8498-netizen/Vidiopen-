package com.example.ui.theme

import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color

data class MusicTheme(
    val id: String,
    val name: String,
    val isDark: Boolean = true,
    val backgroundColor: Color = Color.Black,
    val backgroundBrush: Brush? = null,
    val accentColor: Color = Color(0xFF00D9FF),     // Used for sliders, progress indicators, active icons
    val primaryColor: Color = Color(0xFF7C4DFF),    // Used for main buttons, primary highlights
    val cardBackground: Color = Color(0x0FFFFFFF),  // Card background color
    val textColor: Color = Color.White,
    val subtitleColor: Color = Color(0xFF9E9E9E),
    val glassBorderColor: Color = Color(0x33FFFFFF),
    val bgImageUri: String? = null                  // Used if a custom image/photo background is set
) {
    // Helper to get actual background modifier brush
    fun getBgBrush(): Brush {
        return backgroundBrush ?: Brush.verticalGradient(listOf(backgroundColor, backgroundColor))
    }
}

object MusicThemeRegistry {
    val BuiltInThemes = listOf(
        MusicTheme(
            id = "nova_black",
            name = "Nova Black",
            backgroundColor = Color(0xFF000000),
            accentColor = Color(0xFF00D9FF),
            primaryColor = Color(0xFF7C4DFF),
            cardBackground = Color(0xFF151515),
            glassBorderColor = Color(0x22FFFFFF)
        ),
        MusicTheme(
            id = "galaxy",
            name = "Galaxy",
            backgroundBrush = Brush.verticalGradient(
                listOf(Color(0xFF0B001A), Color(0xFF1D0B3A))
            ),
            accentColor = Color(0xFF00FFCC),
            primaryColor = Color(0xFF9C27B0),
            cardBackground = Color(0x221D0B3A),
            glassBorderColor = Color(0x33FFFFFF)
        ),
        MusicTheme(
            id = "neon_blue",
            name = "Neon Blue",
            backgroundBrush = Brush.verticalGradient(
                listOf(Color(0xFF000511), Color(0xFF001533))
            ),
            accentColor = Color(0xFF00D9FF),
            primaryColor = Color(0xFF0066FF),
            cardBackground = Color(0x1A00D9FF),
            glassBorderColor = Color(0x25FFFFFF)
        ),
        MusicTheme(
            id = "ocean",
            name = "Ocean",
            backgroundBrush = Brush.verticalGradient(
                listOf(Color(0xFF00111A), Color(0xFF002A3A))
            ),
            accentColor = Color(0xFF26A69A),
            primaryColor = Color(0xFF00796B),
            cardBackground = Color(0x15004D40),
            glassBorderColor = Color(0x20FFFFFF)
        ),
        MusicTheme(
            id = "sunset",
            name = "Sunset",
            backgroundBrush = Brush.verticalGradient(
                listOf(Color(0xFF1A000A), Color(0xFF3B0B1A))
            ),
            accentColor = Color(0xFFFF9800),
            primaryColor = Color(0xFFD81B60),
            cardBackground = Color(0x1F3B0B1A),
            glassBorderColor = Color(0x25FFFFFF)
        ),
        MusicTheme(
            id = "forest",
            name = "Forest",
            backgroundBrush = Brush.verticalGradient(
                listOf(Color(0xFF031405), Color(0xFF0B2411))
            ),
            accentColor = Color(0xFF00FF88),
            primaryColor = Color(0xFF1B5E20),
            cardBackground = Color(0x150B2411),
            glassBorderColor = Color(0x20FFFFFF)
        ),
        MusicTheme(
            id = "purple_night",
            name = "Purple Night",
            backgroundBrush = Brush.verticalGradient(
                listOf(Color(0xFF0A0012), Color(0xFF180424))
            ),
            accentColor = Color(0xFFE040FB),
            primaryColor = Color(0xFF6A1B9A),
            cardBackground = Color(0x1F180424),
            glassBorderColor = Color(0x2AFFFFFF)
        ),
        MusicTheme(
            id = "cyberpunk",
            name = "Cyberpunk",
            backgroundBrush = Brush.verticalGradient(
                listOf(Color(0xFF0A0A0F), Color(0xFF140E1B))
            ),
            accentColor = Color(0xFFFFEA00),
            primaryColor = Color(0xFFFF007F),
            cardBackground = Color(0xFF1A1A24),
            glassBorderColor = Color(0x44FF007F)
        ),
        MusicTheme(
            id = "ice_crystal",
            name = "Ice Crystal",
            backgroundBrush = Brush.verticalGradient(
                listOf(Color(0xFF0A192F), Color(0xFF1F3A60))
            ),
            accentColor = Color(0xFF8CE8FF),
            primaryColor = Color(0xFF0D9488),
            cardBackground = Color(0x1C1F3A60),
            glassBorderColor = Color(0x20FFFFFF)
        ),
        MusicTheme(
            id = "rose_gold",
            name = "Rose Gold",
            backgroundBrush = Brush.verticalGradient(
                listOf(Color(0xFF1E1214), Color(0xFF2B1A1E))
            ),
            accentColor = Color(0xFFE0A96D),
            primaryColor = Color(0xFFD4A373),
            cardBackground = Color(0x1C2B1A1E),
            glassBorderColor = Color(0x25FFFFFF)
        )
    )

    fun getThemeById(id: String, customUri: String? = null): MusicTheme {
        if (id == "custom_image" && customUri != null) {
            return MusicTheme(
                id = "custom_image",
                name = "Favorite Image",
                backgroundColor = Color.Black.copy(alpha = 0.5f), // Translucent overlay to see the image
                accentColor = Color(0xFF00D9FF),
                primaryColor = Color(0xFF7C4DFF),
                cardBackground = Color(0x2A000000),
                glassBorderColor = Color(0x22FFFFFF),
                bgImageUri = customUri
            )
        }
        return BuiltInThemes.find { it.id == id } ?: BuiltInThemes.first()
    }
}
