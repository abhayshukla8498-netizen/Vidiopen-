package com.example.ui.components

import android.widget.Toast
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.model.ScannedSong
import com.example.ui.viewmodel.MusicViewModel
import com.example.ui.theme.ElectricBlue
import com.example.ui.theme.RoyalPurple
import com.example.ui.theme.GlassWhiteBorder
import com.example.ui.theme.MusicTheme
import com.example.ui.theme.MusicThemeRegistry
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import android.net.Uri

@Composable
fun MusicMiniPlayer(
    musicViewModel: MusicViewModel,
    onExpand: () -> Unit,
    modifier: Modifier = Modifier
) {
    val activeTrack by musicViewModel.currentPlayingSong.collectAsState()
    val isPlaying by musicViewModel.isPlaying.collectAsState()
    val currentPosition by musicViewModel.currentPosition.collectAsState()
    val duration by musicViewModel.duration.collectAsState()
    val theme by musicViewModel.currentTheme.collectAsState()

    val song = activeTrack ?: return

    val progress = remember(currentPosition, duration) {
        if (duration > 0f) (currentPosition.toFloat() / duration.toFloat()).coerceIn(0f, 1f) else 0f
    }

    Box(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp)
            .shadow(
                elevation = 16.dp,
                shape = RoundedCornerShape(20.dp),
                ambientColor = theme.accentColor,
                spotColor = theme.primaryColor
            )
            .border(1.dp, theme.glassBorderColor, RoundedCornerShape(20.dp))
            .clip(RoundedCornerShape(20.dp))
            .background(theme.cardBackground.copy(alpha = 0.95f))
            .clickable(onClick = onExpand)
            .testTag("music_mini_player")
    ) {
        Column {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 10.dp)
            ) {
                // Vinyl disk animation
                val infiniteTransition = rememberInfiniteTransition(label = "VinylSpinMini")
                val rotationAngle by infiniteTransition.animateFloat(
                    initialValue = 0f,
                    targetValue = 360f,
                    animationSpec = infiniteRepeatable(
                        animation = tween(durationMillis = 8000, easing = LinearEasing),
                        repeatMode = RepeatMode.Restart
                    ),
                    label = "VinylRotationMini"
                )

                Box(
                    modifier = Modifier
                        .size(44.dp)
                        .clip(CircleShape)
                        .rotate(if (isPlaying) rotationAngle else 0f)
                        .background(
                            Brush.sweepGradient(
                                colors = listOf(theme.primaryColor, theme.accentColor, theme.primaryColor)
                            )
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    // Small Album Cover Inside Vinyl
                    AsyncImage(
                        model = song.artworkUri,
                        contentDescription = "Cover Art",
                        contentScale = ContentScale.Crop,
                        modifier = Modifier
                            .size(34.dp)
                            .clip(CircleShape)
                    )
                    Box(
                        modifier = Modifier
                            .size(10.dp)
                            .clip(CircleShape)
                            .background(Color.Black)
                    )
                }

                Spacer(modifier = Modifier.width(14.dp))

                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = song.title,
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = song.artist ?: "Unknown Artist",
                        color = Color.Gray,
                        fontSize = 11.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(
                        onClick = {
                            if (isPlaying) musicViewModel.pause() else musicViewModel.play()
                        },
                        modifier = Modifier.testTag("mini_play_pause_btn")
                    ) {
                        Icon(
                            imageVector = if (isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                            tint = theme.accentColor,
                            contentDescription = "Play/Pause"
                        )
                    }
                    IconButton(
                        onClick = { musicViewModel.next() },
                        modifier = Modifier.testTag("mini_next_btn")
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.SkipNext,
                            tint = Color.White,
                            contentDescription = "Next"
                        )
                    }
                    IconButton(onClick = onExpand) {
                        Icon(Icons.Rounded.KeyboardArrowUp, tint = Color.Gray, contentDescription = "Expand")
                    }
                }
            }

            // Slim glow progress bar at bottom of card
            LinearProgressIndicator(
                progress = { progress },
                color = theme.accentColor,
                trackColor = Color.White.copy(alpha = 0.05f),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(2.dp)
            )
        }
    }
}

@Composable
fun MusicExpandedPlayer(
    musicViewModel: MusicViewModel,
    onCollapse: () -> Unit
) {
    val context = LocalContext.current
    var activeTab by remember { mutableStateOf("Player") } // Player, Lyrics, Queue

    val activeTrack by musicViewModel.currentPlayingSong.collectAsState()
    val isPlaying by musicViewModel.isPlaying.collectAsState()
    val currentPosition by musicViewModel.currentPosition.collectAsState()
    val duration by musicViewModel.duration.collectAsState()
    val repeatMode by musicViewModel.repeatMode.collectAsState()
    val shuffleEnabled by musicViewModel.shuffleModeEnabled.collectAsState()
    val playbackSpeed by musicViewModel.playbackSpeed.collectAsState()
    var showAudioSettings by remember { mutableStateOf(false) }
    val theme by musicViewModel.currentTheme.collectAsState()

    val song = activeTrack ?: return

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(theme.backgroundColor)
            .testTag("expanded_music_player")
    ) {
        if (theme.bgImageUri != null) {
            AsyncImage(
                model = theme.bgImageUri,
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.Black.copy(alpha = 0.75f))
            )
        } else {
            // Decorative glowing fluid background using theme primary
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .drawBehind {
                        drawRect(
                            brush = Brush.radialGradient(
                                colors = listOf(theme.primaryColor.copy(alpha = 0.25f), Color.Transparent),
                                center = Offset(this.size.width / 2f, this.size.height / 3f),
                                radius = this.size.width
                            )
                        )
                    }
            )
        }

        Column(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Header row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onCollapse, modifier = Modifier.testTag("expanded_collapse_btn")) {
                    Icon(Icons.Rounded.KeyboardArrowDown, tint = Color.White, contentDescription = "Minimize")
                }
                Text(
                    text = "Now Playing",
                    color = Color.White,
                    fontWeight = FontWeight.Black,
                    fontSize = 16.sp
                )
                IconButton(onClick = {
                    musicViewModel.replay()
                    Toast.makeText(context, "Replaying from start", Toast.LENGTH_SHORT).show()
                }) {
                    Icon(
                        imageVector = Icons.Rounded.Replay,
                        tint = theme.accentColor,
                        contentDescription = "Replay"
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Navigation tabs
            Row(
                modifier = Modifier
                    .width(260.dp)
                    .background(Color.White.copy(alpha = 0.05f), RoundedCornerShape(12.dp))
                    .padding(3.dp)
            ) {
                listOf("Player", "Lyrics", "Queue").forEach { tab ->
                    val active = activeTab == tab
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(8.dp))
                            .background(if (active) theme.primaryColor else Color.Transparent)
                            .clickable { activeTab = tab }
                            .padding(vertical = 6.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = tab,
                            color = Color.White,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            // Tab Content Switcher
            Box(
                modifier = Modifier.weight(1f),
                contentAlignment = Alignment.Center
            ) {
                when (activeTab) {
                    "Player" -> PlayerTab(song, isPlaying, theme)
                    "Lyrics" -> LyricsTab(theme)
                    "Queue" -> QueueTab(musicViewModel, theme)
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            // Equalizer and speed controls row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Seek Backward 10s
                IconButton(onClick = { musicViewModel.fastSeekBackward() }) {
                    Icon(Icons.Rounded.Replay10, contentDescription = "Rewind 10s", tint = theme.accentColor)
                }

                // Playback speed toggle
                var showSpeedMenu by remember { mutableStateOf(false) }
                Box {
                    TextButton(onClick = { showSpeedMenu = true }) {
                        Text(text = "${playbackSpeed}x Speed", color = theme.accentColor, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }
                    DropdownMenu(
                        expanded = showSpeedMenu,
                        onDismissRequest = { showSpeedMenu = false },
                        modifier = Modifier.background(Color(0xFF1E1E1E))
                    ) {
                        listOf(0.5f, 0.75f, 1.0f, 1.25f, 1.5f, 2.0f).forEach { speed ->
                            DropdownMenuItem(
                                text = { Text("${speed}x", color = Color.White) },
                                onClick = {
                                    musicViewModel.setPlaybackSpeed(speed)
                                    showSpeedMenu = false
                                }
                            )
                        }
                    }
                }

                // Equalizer/Audio Settings Button
                IconButton(onClick = { showAudioSettings = true }, modifier = Modifier.testTag("audio_settings_btn")) {
                    Icon(Icons.Rounded.Tune, contentDescription = "Audio Settings", tint = theme.accentColor)
                }

                // Seek Forward 10s
                IconButton(onClick = { musicViewModel.fastSeekForward() }) {
                    Icon(Icons.Rounded.Forward10, contentDescription = "Forward 10s", tint = theme.accentColor)
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Timestamps and Timeline Slider
            val progress = if (duration > 0) (currentPosition.toFloat() / duration.toFloat()).coerceIn(0f, 1f) else 0f
            val remainingMs = maxOf(0L, duration - currentPosition)

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = formatMusicMillis(currentPosition),
                    color = Color.Gray,
                    fontSize = 11.sp
                )
                Slider(
                    value = progress,
                    onValueChange = {
                        val targetMs = (it * duration).toLong()
                        musicViewModel.seekTo(targetMs)
                    },
                    colors = SliderDefaults.colors(
                        thumbColor = theme.primaryColor,
                        activeTrackColor = theme.accentColor,
                        inactiveTrackColor = Color.DarkGray
                    ),
                    modifier = Modifier
                        .weight(1f)
                        .padding(horizontal = 16.dp)
                )
                Text(
                    text = "-" + formatMusicMillis(remainingMs),
                    color = Color.Gray,
                    fontSize = 11.sp
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Playback controls row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Shuffle Mode
                IconButton(onClick = {
                    musicViewModel.setShuffleMode(!shuffleEnabled)
                    Toast.makeText(context, if (!shuffleEnabled) "Shuffle Enabled" else "Shuffle Disabled", Toast.LENGTH_SHORT).show()
                }) {
                    Icon(
                        imageVector = Icons.Rounded.Shuffle,
                        tint = if (shuffleEnabled) theme.accentColor else Color.Gray,
                        contentDescription = "Shuffle",
                        modifier = Modifier.size(24.dp)
                    )
                }

                // Skip Previous
                IconButton(onClick = { musicViewModel.previous() }) {
                    Icon(Icons.Rounded.SkipPrevious, tint = Color.White, contentDescription = "Previous", modifier = Modifier.size(36.dp))
                }

                // Play / Pause Circle Action
                IconButton(
                    onClick = {
                        if (isPlaying) musicViewModel.pause() else musicViewModel.play()
                    },
                    modifier = Modifier
                        .size(72.dp)
                        .shadow(12.dp, CircleShape, spotColor = theme.primaryColor)
                        .background(theme.primaryColor, CircleShape)
                        .testTag("expanded_play_pause_btn")
                ) {
                    Icon(
                        imageVector = if (isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                        tint = Color.White,
                        contentDescription = "Play/Pause",
                        modifier = Modifier.size(38.dp)
                    )
                }

                // Skip Next
                IconButton(onClick = { musicViewModel.next() }) {
                    Icon(Icons.Rounded.SkipNext, tint = Color.White, contentDescription = "Next", modifier = Modifier.size(36.dp))
                }

                // Repeat Mode Cycle
                val repeatIcon = when (repeatMode) {
                    1 -> Icons.Rounded.RepeatOne
                    else -> Icons.Rounded.Repeat
                }
                val repeatTint = if (repeatMode != 0) theme.accentColor else Color.Gray

                IconButton(onClick = {
                    val nextMode = (repeatMode + 1) % 3
                    musicViewModel.setRepeatMode(nextMode)
                    val modeLabel = when (nextMode) {
                        0 -> "Repeat Off"
                        1 -> "Repeat One"
                        else -> "Repeat All"
                    }
                    Toast.makeText(context, modeLabel, Toast.LENGTH_SHORT).show()
                }) {
                    Icon(
                        imageVector = repeatIcon,
                        tint = repeatTint,
                        contentDescription = "Repeat Mode",
                        modifier = Modifier.size(24.dp)
                    )
                }
            }
        }

        // Render premium configuration studio sheet overlay
        if (showAudioSettings) {
            AudioSettingsSheet(
                musicViewModel = musicViewModel,
                onDismiss = { showAudioSettings = false }
            )
        }
    }
}
@Composable
fun PlayerTab(song: ScannedSong, isPlaying: Boolean, theme: MusicTheme) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        val infiniteTransition = rememberInfiniteTransition(label = "VinylSpinExpanded")
        val rotationAngle by infiniteTransition.animateFloat(
            initialValue = 0f,
            targetValue = 360f,
            animationSpec = infiniteRepeatable(
                animation = tween(durationMillis = 10000, easing = LinearEasing),
                repeatMode = RepeatMode.Restart
            ),
            label = "VinylRotationExpanded"
        )

        Box(
            modifier = Modifier
                .size(240.dp)
                .shadow(24.dp, CircleShape, ambientColor = theme.accentColor, spotColor = theme.primaryColor)
                .border(2.dp, theme.glassBorderColor, CircleShape)
                .rotate(if (isPlaying) rotationAngle else 0f)
                .background(
                    Brush.sweepGradient(
                        colors = listOf(Color.Black, theme.primaryColor, theme.accentColor, Color.Black)
                    )
                ),
            contentAlignment = Alignment.Center
        ) {
            // Inner vinyl grooves
            Canvas(modifier = Modifier.size(220.dp)) {
                drawCircle(color = Color.White.copy(alpha = 0.05f), radius = size.minDimension / 2.5f, style = Stroke(1f))
                drawCircle(color = Color.White.copy(alpha = 0.05f), radius = size.minDimension / 3f, style = Stroke(1f))
            }

            // High Quality album cover
            Box(
                modifier = Modifier
                    .size(100.dp)
                    .clip(CircleShape)
                    .background(Color.DarkGray)
            ) {
                AsyncImage(
                    model = song.artworkUri,
                    contentDescription = "Artwork",
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
            }
        }

        Spacer(modifier = Modifier.height(32.dp))

        // Titles
        Text(
            text = song.title,
            color = Color.White,
            fontWeight = FontWeight.Black,
            fontSize = 20.sp,
            textAlign = TextAlign.Center,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.padding(horizontal = 16.dp)
        )
        Text(
            text = (song.artist ?: "Unknown Artist") + " • " + (song.album ?: "Unknown Album"),
            color = theme.accentColor,
            fontSize = 13.sp,
            fontWeight = FontWeight.Medium,
            textAlign = TextAlign.Center,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.padding(horizontal = 16.dp)
        )

        Spacer(modifier = Modifier.height(24.dp))

        // Premium Sound Visualizer Bars
        Row(
            horizontalArrangement = Arrangement.spacedBy(4.dp),
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.height(40.dp)
        ) {
            val count = 20
            for (i in 0 until count) {
                val waveInfinite = rememberInfiniteTransition(label = "Wave$i")
                val heightPercent by waveInfinite.animateFloat(
                    initialValue = 0.2f,
                    targetValue = 0.9f,
                    animationSpec = infiniteRepeatable(
                        animation = tween(
                            durationMillis = 300 + (i * 45),
                            easing = FastOutSlowInEasing
                        ),
                        repeatMode = RepeatMode.Reverse
                    ),
                    label = "WaveHeight$i"
                )

                Box(
                    modifier = Modifier
                        .width(4.dp)
                        .fillMaxHeight(if (isPlaying) heightPercent else 0.2f)
                        .clip(CircleShape)
                        .background(
                            Brush.verticalGradient(
                                colors = listOf(theme.accentColor, theme.primaryColor)
                            )
                        )
                )
            }
        }
    }
}

@Composable
fun LyricsTab(theme: MusicTheme) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp)
    ) {
        Text(
            "Acoustic Sanctuary Synced Karaoke Lyrics Active",
            color = theme.accentColor,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.fillMaxWidth(),
            textAlign = TextAlign.Center
        )
        Spacer(modifier = Modifier.height(16.dp))

        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .verticalScroll(rememberScrollState()),
            contentAlignment = Alignment.TopCenter
        ) {
            Column(
                verticalArrangement = Arrangement.spacedBy(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.padding(vertical = 20.dp)
            ) {
                LyricLine("Deep beats echoing in the silence", active = false)
                LyricLine("Streaming high-fidelity pure frequency", active = false)
                LyricLine("We are floating in the acoustic sanctuary", active = true)
                LyricLine("Offline tranquility wash away your worries", active = false)
                LyricLine("Studio grade dynamic resonance", active = false)
                LyricLine("Spinning clean on a physical drive", active = false)
                LyricLine("Chasing notes until the sunrise breaks...", active = false)
            }
        }
    }
}

@Composable
fun QueueTab(musicViewModel: MusicViewModel, theme: MusicTheme) {
    val queueList by musicViewModel.queue.collectAsState()
    val activeTrack by musicViewModel.currentPlayingSong.collectAsState()

    Column(modifier = Modifier.fillMaxSize()) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "Playing Queue (${queueList.size} tracks)",
                color = Color.Gray,
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold
            )
            TextButton(
                onClick = { musicViewModel.clearQueue() },
                colors = ButtonDefaults.textButtonColors(contentColor = Color.Red)
            ) {
                Icon(Icons.Rounded.DeleteForever, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("Clear Queue", fontSize = 11.sp)
            }
        }
        Spacer(modifier = Modifier.height(12.dp))

        if (queueList.isEmpty()) {
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                contentAlignment = Alignment.Center
            ) {
                Text("Queue is empty", color = Color.DarkGray, fontSize = 13.sp)
            }
        } else {
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.weight(1f)
            ) {
                itemsIndexed(queueList, key = { index, song -> "queue_${song.id}_$index" }) { index, song ->
                    val isActive = song.id == activeTrack?.id
                    val cardBg = if (isActive) theme.primaryColor.copy(alpha = 0.2f) else theme.cardBackground
                    val cardBorder = if (isActive) theme.accentColor else Color.Transparent

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(cardBg)
                            .border(1.dp, cardBorder, RoundedCornerShape(12.dp))
                            .clickable {
                                musicViewModel.playSong(song, queueList)
                            }
                            .padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .clip(RoundedCornerShape(8.dp))
                        ) {
                            AsyncImage(
                                model = song.artworkUri,
                                contentDescription = null,
                                contentScale = ContentScale.Crop,
                                modifier = Modifier.fillMaxSize()
                            )
                        }
                        Spacer(modifier = Modifier.width(14.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = song.title,
                                color = if (isActive) theme.accentColor else Color.White,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                text = song.artist ?: "Unknown Artist",
                                color = Color.Gray,
                                fontSize = 11.sp,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }

                        IconButton(onClick = { musicViewModel.removeFromQueue(song.id) }) {
                            Icon(Icons.Rounded.Close, contentDescription = "Remove", tint = Color.DarkGray, modifier = Modifier.size(16.dp))
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun LyricLine(text: String, active: Boolean) {
    Text(
        text = text,
        color = if (active) ElectricBlue else Color.White.copy(alpha = 0.4f),
        fontWeight = if (active) FontWeight.Black else FontWeight.Normal,
        fontSize = if (active) 18.sp else 15.sp,
        textAlign = TextAlign.Center,
        style = androidx.compose.ui.text.TextStyle(
            shadow = if (active) Shadow(ElectricBlue, blurRadius = 8f) else null
        ),
        modifier = Modifier.fillMaxWidth()
    )
}

private fun formatMusicMillis(ms: Long): String {
    val totalSecs = ms / 1000
    val minutes = totalSecs / 60
    val seconds = totalSecs % 60
    return String.format("%02d:%02d", minutes, seconds)
}

@Composable
fun AudioSettingsSheet(
    musicViewModel: MusicViewModel,
    onDismiss: () -> Unit
) {
    // Collect StateFlows
    val eqEnabled by musicViewModel.eqEnabled.collectAsState()
    val selectedPreset by musicViewModel.selectedPreset.collectAsState()
    val eqBands by musicViewModel.eqBands.collectAsState()

    val bassBoostEnabled by musicViewModel.bassBoostEnabled.collectAsState()
    val bassBoostStrength by musicViewModel.bassBoostStrength.collectAsState()

    val virtualizerEnabled by musicViewModel.virtualizerEnabled.collectAsState()
    val virtualizerStrength by musicViewModel.virtualizerStrength.collectAsState()

    val loudnessEnabled by musicViewModel.loudnessEnabled.collectAsState()
    val loudnessGain by musicViewModel.loudnessGain.collectAsState()

    val balance by musicViewModel.balance.collectAsState()

    val sleepTimerRemaining by musicViewModel.sleepTimerRemaining.collectAsState()
    val sleepTimerMode by musicViewModel.sleepTimerMode.collectAsState()

    val fadeInEnabled by musicViewModel.fadeInEnabled.collectAsState()
    val fadeInDurationMs by musicViewModel.fadeInDurationMs.collectAsState()
    val fadeOutEnabled by musicViewModel.fadeOutEnabled.collectAsState()
    val fadeOutDurationMs by musicViewModel.fadeOutDurationMs.collectAsState()

    var showCustomPresetDialog by remember { mutableStateOf(false) }
    var newPresetName by remember { mutableStateOf("") }
    
    // For custom presets list
    var customPresetNames by remember { mutableStateOf(musicViewModel.getCustomPresetNames()) }

    val currentTheme by musicViewModel.currentTheme.collectAsState()
    val customThemeImageUri by musicViewModel.customThemeImageUri.collectAsState()
    var settingsTab by remember { mutableStateOf("Audio Tuning") }

    val launcher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            musicViewModel.setCustomThemeImage(uri.toString())
        }
    }

    // Dialog or full screen sheet overlay with entering/exiting animations
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black.copy(alpha = 0.95f))
            .clickable(enabled = true, onClick = {}) // consume clicks to prevent behind clicks
            .testTag("audio_settings_sheet")
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .padding(20.dp)
        ) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Premium Audio Studio",
                    color = Color.White,
                    fontWeight = FontWeight.Black,
                    fontSize = 20.sp,
                    style = androidx.compose.ui.text.TextStyle(
                        shadow = Shadow(currentTheme.accentColor, blurRadius = 12f)
                    )
                )
                IconButton(
                    onClick = onDismiss,
                    modifier = Modifier
                        .background(Color.White.copy(alpha = 0.1f), CircleShape)
                ) {
                    Icon(Icons.Rounded.Close, contentDescription = "Close", tint = Color.White)
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Tab Row
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color.White.copy(alpha = 0.05f), RoundedCornerShape(12.dp))
                    .padding(3.dp)
            ) {
                listOf("Audio Tuning", "Premium Themes").forEach { tab ->
                    val active = settingsTab == tab
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(8.dp))
                            .background(if (active) currentTheme.primaryColor else Color.Transparent)
                            .clickable { settingsTab = tab }
                            .padding(vertical = 8.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = tab,
                            color = Color.White,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            if (settingsTab == "Audio Tuning") {
                // Scrollable Content
                LazyColumn(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                // Sleep Timer Card
                item {
                    LuxurySettingsCard(title = "Sleep Timer", icon = Icons.Rounded.Timer, theme = currentTheme) {
                        Column {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = if (sleepTimerMode != null) "Active: $sleepTimerMode" else "Timer Inactive",
                                    color = if (sleepTimerMode != null) currentTheme.accentColor else Color.Gray,
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                if (sleepTimerRemaining != null) {
                                    Text(
                                        text = formatMusicMillis(sleepTimerRemaining!!),
                                        color = currentTheme.accentColor,
                                        fontSize = 14.sp,
                                        fontWeight = FontWeight.Black
                                    )
                                }
                            }
                            Spacer(modifier = Modifier.height(10.dp))
                            // Row of options
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                listOf(15, 30, 45, 60).forEach { mins ->
                                    val active = sleepTimerMode == "$mins min"
                                    Box(
                                        modifier = Modifier
                                            .weight(1f)
                                            .padding(2.dp)
                                            .clip(RoundedCornerShape(8.dp))
                                            .background(if (active) currentTheme.primaryColor else Color.White.copy(alpha = 0.05f))
                                            .clickable {
                                                if (active) musicViewModel.setSleepTimer(null)
                                                else musicViewModel.setSleepTimer(mins)
                                            }
                                            .padding(vertical = 8.dp),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text("${mins}m", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                                val isEndSong = sleepTimerMode == "End of Song"
                                Box(
                                    modifier = Modifier
                                        .weight(1.5f)
                                        .padding(2.dp)
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(if (isEndSong) currentTheme.primaryColor else Color.White.copy(alpha = 0.05f))
                                        .clickable {
                                            if (isEndSong) musicViewModel.setSleepTimer(null)
                                            else musicViewModel.setSleepTimerEndOfSong()
                                        }
                                        .padding(vertical = 8.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text("End Song", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }

                // 10-Band Equalizer Card
                item {
                    LuxurySettingsCard(title = "10-Band Equalizer", icon = Icons.Rounded.Equalizer, theme = currentTheme) {
                        Column {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("Enable Equalizer", color = Color.White, fontSize = 14.sp)
                                Switch(
                                    checked = eqEnabled,
                                    onCheckedChange = { musicViewModel.setEqEnabled(it) },
                                    colors = SwitchDefaults.colors(
                                        checkedThumbColor = Color.White,
                                        checkedTrackColor = ElectricBlue
                                    )
                                )
                            }
                            if (eqEnabled) {
                                Spacer(modifier = Modifier.height(12.dp))
                                
                                // Preset selector dropdown or scrollable row
                                var showPresetMenu by remember { mutableStateOf(false) }
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .background(Color.White.copy(alpha = 0.05f), RoundedCornerShape(8.dp))
                                        .clickable { showPresetMenu = true }
                                        .padding(12.dp)
                                ) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text("Preset: $selectedPreset", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                        Icon(Icons.Rounded.KeyboardArrowDown, tint = Color.White, contentDescription = "Select Preset")
                                    }
                                    
                                    DropdownMenu(
                                        expanded = showPresetMenu,
                                        onDismissRequest = { showPresetMenu = false },
                                        modifier = Modifier.background(Color(0xFF1E1E1E))
                                    ) {
                                        // Default Presets
                                        listOf("Normal", "Pop", "Rock", "Jazz", "Classical", "Dance", "Bass Boost", "Vocal").forEach { preset ->
                                            DropdownMenuItem(
                                                text = { Text(preset, color = Color.White) },
                                                onClick = {
                                                    musicViewModel.selectPreset(preset)
                                                    showPresetMenu = false
                                                }
                                            )
                                        }
                                        // Custom Presets
                                        customPresetNames.forEach { preset ->
                                            DropdownMenuItem(
                                                text = {
                                                    Row(
                                                        modifier = Modifier.fillMaxWidth(),
                                                        horizontalArrangement = Arrangement.SpaceBetween,
                                                        verticalAlignment = Alignment.CenterVertically
                                                    ) {
                                                        Text(preset, color = ElectricBlue)
                                                        IconButton(
                                                            onClick = {
                                                                musicViewModel.deleteCustomPreset(preset)
                                                                customPresetNames = musicViewModel.getCustomPresetNames()
                                                            },
                                                            modifier = Modifier.size(24.dp)
                                                        ) {
                                                            Icon(Icons.Rounded.Delete, contentDescription = "Delete", tint = Color.Red, modifier = Modifier.size(16.dp))
                                                        }
                                                    }
                                                },
                                                onClick = {
                                                    musicViewModel.selectPreset(preset)
                                                    showPresetMenu = false
                                                }
                                            )
                                        }
                                    }
                                }

                                Spacer(modifier = Modifier.height(12.dp))

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    TextButton(onClick = { showCustomPresetDialog = true }) {
                                        Icon(Icons.Rounded.Save, contentDescription = "Save Custom", tint = ElectricBlue, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("Save Custom Preset", color = ElectricBlue, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                    }
                                }

                                Spacer(modifier = Modifier.height(16.dp))

                                // Bands grid or row
                                // Since we have 10 bands, we can show them as nice sliders inside a horizontal scroll or vertical grid
                                val frequencies = listOf("32Hz", "64Hz", "125Hz", "250Hz", "500Hz", "1kHz", "2kHz", "4kHz", "8kHz", "16kHz")
                                Column(
                                    verticalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    for (i in 0..9) {
                                        val bandGain = eqBands.getOrElse(i) { 0 }
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Text(
                                                text = frequencies[i],
                                                color = Color.Gray,
                                                fontSize = 11.sp,
                                                modifier = Modifier.width(50.dp)
                                            )
                                            Slider(
                                                value = bandGain.toFloat(),
                                                onValueChange = {
                                                    musicViewModel.setEqBand(i, it.toInt())
                                                },
                                                valueRange = -15f..15f,
                                                colors = SliderDefaults.colors(
                                                    thumbColor = ElectricBlue,
                                                    activeTrackColor = ElectricBlue,
                                                    inactiveTrackColor = Color.DarkGray
                                                ),
                                                modifier = Modifier.weight(1f)
                                            )
                                            Text(
                                                text = "${if (bandGain >= 0) "+" else ""}${bandGain}dB",
                                                color = Color.White,
                                                fontSize = 11.sp,
                                                modifier = Modifier.width(40.dp),
                                                textAlign = TextAlign.End
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                // Audio Effects (DSP enhancements)
                item {
                    LuxurySettingsCard(title = "Studio Enhancements", icon = Icons.Rounded.SettingsVoice, theme = currentTheme) {
                        Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
                            // Bass Boost
                            Column {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text("Bass Boost", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                                    Switch(
                                        checked = bassBoostEnabled,
                                        onCheckedChange = { musicViewModel.setBassBoostEnabled(it) },
                                        colors = SwitchDefaults.colors(checkedTrackColor = currentTheme.accentColor)
                                    )
                                }
                                if (bassBoostEnabled) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(Icons.Rounded.VolumeDown, contentDescription = null, tint = Color.Gray, modifier = Modifier.size(16.dp))
                                        Slider(
                                            value = bassBoostStrength.toFloat(),
                                            onValueChange = { musicViewModel.setBassBoostStrength(it.toInt()) },
                                            valueRange = 0f..1000f,
                                            colors = SliderDefaults.colors(activeTrackColor = currentTheme.accentColor, thumbColor = currentTheme.accentColor),
                                            modifier = Modifier.weight(1f)
                                        )
                                        Text("${(bassBoostStrength / 10)}%", color = Color.White, fontSize = 11.sp, modifier = Modifier.width(30.dp), textAlign = TextAlign.End)
                                    }
                                }
                            }

                            Box(modifier = Modifier.fillMaxWidth().height(1.dp).background(Color.White.copy(alpha = 0.05f)))

                            // Virtualizer
                            Column {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text("3D Virtualizer (Surround)", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                                    Switch(
                                        checked = virtualizerEnabled,
                                        onCheckedChange = { musicViewModel.setVirtualizerEnabled(it) },
                                        colors = SwitchDefaults.colors(checkedTrackColor = currentTheme.accentColor)
                                    )
                                }
                                if (virtualizerEnabled) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(Icons.Rounded.VolumeDown, contentDescription = null, tint = Color.Gray, modifier = Modifier.size(16.dp))
                                        Slider(
                                            value = virtualizerStrength.toFloat(),
                                            onValueChange = { musicViewModel.setVirtualizerStrength(it.toInt()) },
                                            valueRange = 0f..1000f,
                                            colors = SliderDefaults.colors(activeTrackColor = currentTheme.accentColor, thumbColor = currentTheme.accentColor),
                                            modifier = Modifier.weight(1f)
                                        )
                                        Text("${(virtualizerStrength / 10)}%", color = Color.White, fontSize = 11.sp, modifier = Modifier.width(30.dp), textAlign = TextAlign.End)
                                    }
                                }
                            }

                            Box(modifier = Modifier.fillMaxWidth().height(1.dp).background(Color.White.copy(alpha = 0.05f)))

                            // Loudness
                            Column {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text("Loudness Enhancer", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                                    Switch(
                                        checked = loudnessEnabled,
                                        onCheckedChange = { musicViewModel.setLoudnessEnabled(it) },
                                        colors = SwitchDefaults.colors(checkedTrackColor = currentTheme.accentColor)
                                    )
                                }
                                if (loudnessEnabled) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(Icons.Rounded.VolumeDown, contentDescription = null, tint = Color.Gray, modifier = Modifier.size(16.dp))
                                        Slider(
                                            value = loudnessGain,
                                            onValueChange = { musicViewModel.setLoudnessGain(it) },
                                            valueRange = 0f..1000f,
                                            colors = SliderDefaults.colors(activeTrackColor = currentTheme.accentColor, thumbColor = currentTheme.accentColor),
                                            modifier = Modifier.weight(1f)
                                        )
                                        Text("${loudnessGain.toInt()}mB", color = Color.White, fontSize = 11.sp, modifier = Modifier.width(45.dp), textAlign = TextAlign.End)
                                    }
                                }
                            }

                            Box(modifier = Modifier.fillMaxWidth().height(1.dp).background(Color.White.copy(alpha = 0.05f)))

                            // Stereo Balance
                            Column {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text("Stereo Balance", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                                    TextButton(onClick = { musicViewModel.setBalance(0f) }) {
                                        Text("Center", color = currentTheme.accentColor, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text("L", color = Color.Gray, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                    Slider(
                                        value = balance,
                                        onValueChange = { musicViewModel.setBalance(it) },
                                        valueRange = -1f..1f,
                                        colors = SliderDefaults.colors(activeTrackColor = currentTheme.accentColor, thumbColor = currentTheme.accentColor),
                                        modifier = Modifier.weight(1f)
                                    )
                                    Text("R", color = Color.Gray, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }

                // Fading and transitions (Gapless / Fades)
                item {
                    LuxurySettingsCard(title = "Fades & Transitions", icon = Icons.Rounded.HourglassEmpty, theme = currentTheme) {
                        Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
                            // Fade In
                            Column {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text("Fade In on Play", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                                    Switch(
                                        checked = fadeInEnabled,
                                        onCheckedChange = { musicViewModel.setFadeInEnabled(it) },
                                        colors = SwitchDefaults.colors(checkedTrackColor = currentTheme.accentColor)
                                    )
                                }
                                if (fadeInEnabled) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Slider(
                                            value = fadeInDurationMs.toFloat(),
                                            onValueChange = { musicViewModel.setFadeInDuration(it.toLong()) },
                                            valueRange = 200f..5000f,
                                            colors = SliderDefaults.colors(activeTrackColor = currentTheme.accentColor, thumbColor = currentTheme.accentColor),
                                            modifier = Modifier.weight(1f)
                                        )
                                        Text("${String.format("%.1f", fadeInDurationMs / 1000f)}s", color = Color.White, fontSize = 11.sp, modifier = Modifier.width(35.dp), textAlign = TextAlign.End)
                                    }
                                }
                            }

                            Box(modifier = Modifier.fillMaxWidth().height(1.dp).background(Color.White.copy(alpha = 0.05f)))

                            // Fade Out
                            Column {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text("Fade Out on Pause", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                                    Switch(
                                        checked = fadeOutEnabled,
                                        onCheckedChange = { musicViewModel.setFadeOutEnabled(it) },
                                        colors = SwitchDefaults.colors(checkedTrackColor = currentTheme.accentColor)
                                    )
                                }
                                if (fadeOutEnabled) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Slider(
                                            value = fadeOutDurationMs.toFloat(),
                                            onValueChange = { musicViewModel.setFadeOutDuration(it.toLong()) },
                                            valueRange = 200f..5000f,
                                            colors = SliderDefaults.colors(activeTrackColor = currentTheme.accentColor, thumbColor = currentTheme.accentColor),
                                            modifier = Modifier.weight(1f)
                                        )
                                        Text("${String.format("%.1f", fadeOutDurationMs / 1000f)}s", color = Color.White, fontSize = 11.sp, modifier = Modifier.width(35.dp), textAlign = TextAlign.End)
                                    }
                                }
                            }

                            Box(modifier = Modifier.fillMaxWidth().height(1.dp).background(Color.White.copy(alpha = 0.05f)))

                            // Gapless Playback and Phone Focus Status Indicators
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(Icons.Rounded.Audiotrack, tint = currentTheme.accentColor, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "Gapless Playback & Call Resume is active",
                                    color = Color.Gray,
                                    fontSize = 11.sp
                                )
                            }
                        }
                    }
                }
            }
        } else {
            // PREMIUM THEMES Tab
                Column(
                    modifier = Modifier.weight(1f)
                ) {
                    // Custom Photo Theme Studio Hero Card
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(16.dp))
                            .background(Color.White.copy(alpha = 0.03f))
                            .border(1.dp, currentTheme.glassBorderColor, RoundedCornerShape(16.dp))
                            .padding(16.dp)
                    ) {
                        Column {
                            Row(
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(Icons.Rounded.Brush, contentDescription = null, tint = currentTheme.accentColor, modifier = Modifier.size(22.dp))
                                Spacer(modifier = Modifier.width(10.dp))
                                Text("Custom Photo Theme", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                            }
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = "Design a personal sanctuary by uploading any background image from your gallery.",
                                color = Color.Gray,
                                fontSize = 12.sp,
                                lineHeight = 16.sp
                            )
                            Spacer(modifier = Modifier.height(14.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Button(
                                    onClick = { launcher.launch("image/*") },
                                    colors = ButtonDefaults.buttonColors(containerColor = currentTheme.primaryColor),
                                    shape = RoundedCornerShape(10.dp)
                                ) {
                                    Icon(Icons.Rounded.AddAPhoto, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("Select Photo", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                }

                                if (customThemeImageUri != null) {
                                    Box(
                                        modifier = Modifier
                                            .size(50.dp)
                                            .clip(RoundedCornerShape(8.dp))
                                            .border(1.dp, currentTheme.accentColor, RoundedCornerShape(8.dp))
                                    ) {
                                        AsyncImage(
                                            model = customThemeImageUri,
                                            contentDescription = "Custom preview",
                                            contentScale = ContentScale.Crop,
                                            modifier = Modifier.fillMaxSize()
                                        )
                                    }
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Text(
                        "Soundscape Skins Grid",
                        color = Color.Gray,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(start = 4.dp, bottom = 8.dp)
                    )                     // Themes Grid inside a LazyColumn to integrate scroll beautifully
                    val allThemes = MusicThemeRegistry.BuiltInThemes
                    val themePairs = allThemes.chunked(2)

                    LazyColumn(
                        modifier = Modifier.weight(1f),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        items(themePairs.size) { index ->
                            val pair = themePairs[index]
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                pair.forEach { theme ->
                                    val isCurrent = currentTheme.id == theme.id
                                    Box(
                                        modifier = Modifier
                                            .weight(1f)
                                            .clip(RoundedCornerShape(16.dp))
                                            .background(Color.White.copy(alpha = 0.02f))
                                            .border(
                                                width = if (isCurrent) 2.dp else 1.dp,
                                                color = if (isCurrent) theme.accentColor else Color.White.copy(alpha = 0.08f),
                                                shape = RoundedCornerShape(16.dp)
                                            )
                                            .clickable {
                                                musicViewModel.selectTheme(theme.id)
                                            }
                                            .padding(12.dp)
                                    ) {
                                        Column {
                                            // Mini visual preview card
                                            Box(
                                                modifier = Modifier
                                                    .fillMaxWidth()
                                                    .height(64.dp)
                                                    .clip(RoundedCornerShape(8.dp))
                                                    .background(theme.backgroundColor)
                                                    .border(1.dp, theme.glassBorderColor, RoundedCornerShape(8.dp))
                                            ) {
                                                // Dynamic colors preview circle or brush gradient
                                                Box(
                                                    modifier = Modifier
                                                        .fillMaxSize()
                                                        .drawBehind {
                                                            drawRect(
                                                                brush = Brush.radialGradient(
                                                                    colors = listOf(theme.primaryColor.copy(alpha = 0.4f), Color.Transparent),
                                                                    center = Offset(size.width / 2f, size.height / 2f),
                                                                    radius = size.width
                                                                )
                                                            )
                                                        }
                                                )
                                            }
                                            Spacer(modifier = Modifier.height(10.dp))
                                            Row(
                                                modifier = Modifier.fillMaxWidth(),
                                                horizontalArrangement = Arrangement.SpaceBetween,
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                Text(
                                                    text = theme.name,
                                                    color = Color.White,
                                                    fontWeight = FontWeight.Bold,
                                                    fontSize = 13.sp,
                                                    maxLines = 1,
                                                    overflow = TextOverflow.Ellipsis,
                                                    modifier = Modifier.weight(1f)
                                                )
                                                if (isCurrent) {
                                                    Box(
                                                        modifier = Modifier
                                                            .clip(RoundedCornerShape(6.dp))
                                                            .background(theme.primaryColor)
                                                            .padding(horizontal = 6.dp, vertical = 2.dp)
                                                    ) {
                                                        Text("Active", color = Color.White, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                                if (pair.size == 1) {
                                    Spacer(modifier = Modifier.weight(1f))
                                }
                            }
                        }
                    }
                }
            }
        }

        // Save Custom Preset Name Dialog
        if (showCustomPresetDialog) {
            AlertDialog(
                onDismissRequest = { showCustomPresetDialog = false },
                title = { Text("Save Custom Preset", color = Color.White) },
                text = {
                    Column {
                        Text("Enter a unique name for your equalizer preset:", color = Color.Gray, fontSize = 12.sp)
                        Spacer(modifier = Modifier.height(8.dp))
                        TextField(
                            value = newPresetName,
                            onValueChange = { newPresetName = it },
                            placeholder = { Text("My Custom Preset", color = Color.DarkGray) },
                            singleLine = true,
                            colors = TextFieldDefaults.colors(
                                focusedContainerColor = Color.White.copy(alpha = 0.05f),
                                unfocusedContainerColor = Color.White.copy(alpha = 0.05f),
                                focusedTextColor = Color.White,
                                unfocusedTextColor = Color.White,
                                focusedIndicatorColor = ElectricBlue
                            ),
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                },
                confirmButton = {
                    Button(
                        onClick = {
                            if (newPresetName.isNotBlank()) {
                                musicViewModel.saveCustomPreset(newPresetName, eqBands)
                                customPresetNames = musicViewModel.getCustomPresetNames()
                                musicViewModel.selectPreset(newPresetName)
                                newPresetName = ""
                                showCustomPresetDialog = false
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = ElectricBlue)
                    ) {
                        Text("Save", color = Color.Black, fontWeight = FontWeight.Bold)
                    }
                },
                dismissButton = {
                    TextButton(onClick = { showCustomPresetDialog = false }) {
                        Text("Cancel", color = Color.White)
                    }
                },
                containerColor = Color(0xFF151515)
            )
        }
    }
}

@Composable
fun LuxurySettingsCard(
    title: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    theme: MusicTheme,
    content: @Composable () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, theme.glassBorderColor, RoundedCornerShape(16.dp))
            .background(Color.White.copy(alpha = 0.03f), RoundedCornerShape(16.dp))
            .padding(16.dp)
    ) {
        Column {
            Row(
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(icon, contentDescription = null, tint = theme.accentColor, modifier = Modifier.size(20.dp))
                Spacer(modifier = Modifier.width(10.dp))
                Text(title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
            }
            Spacer(modifier = Modifier.height(14.dp))
            content()
        }
    }
}
