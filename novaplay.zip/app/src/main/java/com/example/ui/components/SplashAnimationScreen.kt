package com.example.ui.components

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay

@Composable
fun SplashAnimationScreen(
    appLanguage: String,
    onFinished: () -> Unit
) {
    // 5 seconds loading duration as requested by the user
    LaunchedEffect(Unit) {
        delay(5000)
        onFinished()
    }

    val infiniteTransition = rememberInfiniteTransition(label = "SplashScreenInfinite")

    // Animated states for sequential reveal
    var logoVisible by remember { mutableStateOf(false) }
    var textVisible by remember { mutableStateOf(false) }
    var taglineVisible by remember { mutableStateOf(false) }
    var progressVal by remember { mutableStateOf(0f) }

    LaunchedEffect(Unit) {
        delay(150)
        logoVisible = true
        delay(350)
        textVisible = true
        delay(300)
        taglineVisible = true
    }

    // Dynamic step progress filling perfectly over 4.7 seconds
    LaunchedEffect(Unit) {
        val durationMs = 4600L
        val steps = 100
        val stepDelay = durationMs / steps
        for (i in 1..steps) {
            delay(stepDelay)
            progressVal = i.toFloat() / steps
        }
        progressVal = 1.0f
    }

    // Spring animations for clean entry transitions
    val logoScale by animateFloatAsState(
        targetValue = if (logoVisible) 1f else 0.4f,
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioMediumBouncy,
            stiffness = Spring.StiffnessLow
        ),
        label = "LogoScale"
    )

    val logoAlpha by animateFloatAsState(
        targetValue = if (logoVisible) 1f else 0f,
        animationSpec = tween(1200, easing = EaseOutCubic),
        label = "LogoAlpha"
    )

    val textAlpha by animateFloatAsState(
        targetValue = if (textVisible) 1f else 0f,
        animationSpec = tween(1000, easing = EaseOutCubic),
        label = "TextAlpha"
    )

    val taglineAlpha by animateFloatAsState(
        targetValue = if (taglineVisible) 1f else 0f,
        animationSpec = tween(1200, easing = EaseOutCubic),
        label = "TaglineAlpha"
    )

    // Pulsing outer halo scale
    val haloPulse by infiniteTransition.animateFloat(
        initialValue = 1.0f,
        targetValue = 1.25f,
        animationSpec = infiniteRepeatable(
            animation = tween(2000, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "HaloPulse"
    )

    // Glowing rotating circle effect
    val rotationAngle by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(6000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "Rotation"
    )

    // Dynamic loading text updates depending on current progress
    val statusText = when {
        progressVal < 0.2f -> if (appLanguage == "hi") "प्लेयर इंजन शुरू किया जा रहा है..." else "Initializing Video Engine..."
        progressVal < 0.4f -> if (appLanguage == "hi") "हार्डवेयर डिकोडिंग कॉन्फ़िगर की जा रही है..." else "Configuring Hardware Decoding..."
        progressVal < 0.6f -> if (appLanguage == "hi") "लोकल मीडिया फ़ाइलें स्कैन की जा रही हैं..." else "Scanning Local Media Files..."
        progressVal < 0.8f -> if (appLanguage == "hi") "प्लेबैक बफ़र्स अनुकूलित किए जा रहे हैं..." else "Optimizing Playback Buffers..."
        progressVal < 0.95f -> if (appLanguage == "hi") "सभी घटक तैयार किए जा रहे हैं..." else "Finalizing Core Components..."
        else -> if (appLanguage == "hi") "तैयार! शुरू हो रहा है..." else "Ready! Starting Player..."
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF070709)), // Absolute sleek deep black background
        contentAlignment = Alignment.Center
    ) {
        // Deep glowing background radial spotlight (Red/Orange/Green soft gradient)
        Box(
            modifier = Modifier
                .size(500.dp)
                .align(Alignment.Center)
                .background(
                    Brush.radialGradient(
                        colors = listOf(
                            Color(0xFFFF1E27).copy(alpha = 0.15f),
                            Color(0xFF10B981).copy(alpha = 0.05f),
                            Color.Transparent
                        )
                    )
                )
        )

        // Draw animating particles on canvas for an immersive premium cosmic feel
        Canvas(modifier = Modifier.fillMaxSize()) {
            // Draw background ambient star grids
            val starPositions = listOf(
                Offset(size.width * 0.15f, size.height * 0.12f),
                Offset(size.width * 0.85f, size.height * 0.08f),
                Offset(size.width * 0.72f, size.height * 0.28f),
                Offset(size.width * 0.25f, size.height * 0.35f),
                Offset(size.width * 0.88f, size.height * 0.68f),
                Offset(size.width * 0.12f, size.height * 0.75f),
                Offset(size.width * 0.35f, size.height * 0.85f),
                Offset(size.width * 0.65f, size.height * 0.92f)
            )
            starPositions.forEachIndexed { i, offset ->
                val alpha = if (i % 2 == 0) 0.45f else 0.25f
                drawCircle(
                    color = Color.White.copy(alpha = alpha),
                    radius = if (i % 3 == 0) 3f else 2f,
                    center = offset
                )
            }
        }

        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 24.dp)
        ) {
            // Glow Ring + App Icon Box
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier
                    .size(160.dp)
                    .scale(logoScale)
                    .alpha(logoAlpha)
            ) {
                // Pulse halo bloom
                Box(
                    modifier = Modifier
                        .size(130.dp)
                        .scale(haloPulse)
                        .blur(12.dp)
                        .background(Color(0xFFFF1E27).copy(alpha = 0.25f), CircleShape)
                )

                // Beautiful rotating gradient border ring
                Canvas(
                    modifier = Modifier
                        .size(140.dp)
                        .graphicsLayer(rotationZ = rotationAngle)
                ) {
                    drawCircle(
                        brush = Brush.sweepGradient(
                            colors = listOf(
                                Color(0xFFFF1E27),  // Vidiopen Red
                                Color(0xFFFF5252),  // Coral Red
                                Color(0xFF10B981),  // India Green/Teal
                                Color(0xFFFF1E27)   // Back to Red
                            )
                        ),
                        style = Stroke(width = 3.dp.toPx(), cap = StrokeCap.Round)
                    )
                }

                // Inner clean dark backing circle for the logo
                Box(
                    modifier = Modifier
                        .size(116.dp)
                        .background(Color(0xFF0F0F13), CircleShape)
                        .border(1.dp, Color.White.copy(alpha = 0.08f), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    // Crisp, beautifully scaled main App Logo
                    AppLogo(
                        modifier = Modifier.size(76.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(40.dp))

            // Text elements (Logo name + Tagline)
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.fillMaxWidth()
            ) {
                // Main elegant brand text
                Text(
                    text = "VIDIOPEN",
                    color = Color.White,
                    fontSize = 36.sp,
                    fontWeight = FontWeight.Black,
                    letterSpacing = 10.sp,
                    textAlign = TextAlign.Center,
                    modifier = Modifier
                        .alpha(textAlpha)
                        .graphicsLayer(scaleX = textAlpha, scaleY = textAlpha)
                )

                Spacer(modifier = Modifier.height(12.dp))

                // User requested subtitle: "India's first offline video player app"
                Text(
                    text = if (appLanguage == "hi") "भारत का पहला ऑफलाइन वीडियो प्लेयर ऐप" else "India's First Offline Video Player App",
                    color = Color(0xFF10B981), // Beautiful Green/Teal accent
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.5.sp,
                    textAlign = TextAlign.Center,
                    lineHeight = 22.sp,
                    modifier = Modifier
                        .alpha(taglineAlpha)
                        .padding(horizontal = 16.dp)
                )
            }

            Spacer(modifier = Modifier.height(60.dp))

            // Premium modern linear loading bar
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier
                    .width(220.dp)
                    .alpha(taglineAlpha)
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(4.dp)
                        .clip(CircleShape)
                        .background(Color.White.copy(alpha = 0.06f))
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxHeight()
                            .fillMaxWidth(progressVal)
                            .clip(CircleShape)
                            .background(
                                Brush.horizontalGradient(
                                    colors = listOf(
                                        Color(0xFFFF1E27), // Saffron Red
                                        Color(0xFFFFB03A), // Saffron Orange
                                        Color(0xFF10B981)  // India Green
                                    )
                                )
                            )
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Percentage indicator
                Text(
                    text = "${(progressVal * 100).toInt()}%",
                    color = Color.White,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp
                )

                Spacer(modifier = Modifier.height(8.dp))

                // Dynamic loading status message
                Text(
                    text = statusText,
                    color = Color.Gray,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Medium,
                    letterSpacing = 0.5.sp,
                    textAlign = TextAlign.Center
                )
            }
        }

        // Beautiful, highly-polished "Made in India" label at the bottom
        Column(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .navigationBarsPadding()
                .padding(bottom = 40.dp)
                .alpha(taglineAlpha),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Mini India Tricolor glowing visual strip
            Row(
                modifier = Modifier
                    .width(48.dp)
                    .height(3.dp)
                    .clip(CircleShape)
            ) {
                Box(modifier = Modifier.weight(1f).fillMaxHeight().background(Color(0xFFFF671F))) // Saffron
                Box(modifier = Modifier.weight(1f).fillMaxHeight().background(Color.White))       // White
                Box(modifier = Modifier.weight(1f).fillMaxHeight().background(Color(0xFF046A38))) // India Green
            }

            Spacer(modifier = Modifier.height(10.dp))

            Row(
                modifier = Modifier
                    .background(
                        color = Color.White.copy(alpha = 0.02f),
                        shape = RoundedCornerShape(12.dp)
                    )
                    .border(
                        width = 1.dp,
                        color = Color.White.copy(alpha = 0.05f),
                        shape = RoundedCornerShape(12.dp)
                    )
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center
            ) {
                Text(
                    text = if (appLanguage == "hi") "आत्मनिर्भर भारत" else "MADE IN INDIA",
                    color = Color.LightGray,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 2.sp
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "🇮🇳",
                    fontSize = 14.sp
                )
            }
        }
    }
}
