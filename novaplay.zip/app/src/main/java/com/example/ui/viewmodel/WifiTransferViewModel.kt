package com.example.ui.viewmodel

import android.app.Application
import android.content.Context
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.model.ActiveTransfer
import com.example.data.model.ConnectionRequest
import com.example.data.model.TransferHistoryEntity
import com.example.data.repository.WifiTransferRepository
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.io.File

class WifiTransferViewModel(
    application: Application,
    private val repository: WifiTransferRepository
) : AndroidViewModel(application) {

    val isServerRunning: StateFlow<Boolean> = repository.isServerRunning
    val serverIp: StateFlow<String?> = repository.serverIp
    val serverPort: StateFlow<Int> = repository.serverPort
    val sessionCode: StateFlow<String?> = repository.sessionCode
    val connectionRequest: StateFlow<ConnectionRequest?> = repository.connectionRequest
    val activeTransfers: StateFlow<List<ActiveTransfer>> = repository.activeTransfers
    val discoveredDevices: StateFlow<List<String>> = repository.discoveredDevices
    val isScanning: StateFlow<Boolean> = repository.isScanning

    val transferHistory: StateFlow<List<TransferHistoryEntity>> = repository.transferHistory
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    private val _sendResultFlow = MutableSharedFlow<Result<Unit>>()
    val sendResultFlow: SharedFlow<Result<Unit>> = _sendResultFlow.asSharedFlow()

    fun startServer(context: Context) {
        repository.startServer(context)
    }

    fun stopServer() {
        repository.stopServer()
    }

    fun scanForDevices() {
        repository.scanForDevices(getApplication())
    }

    fun approveConnection(approved: Boolean) {
        repository.approveConnection(approved)
    }

    fun cancelTransfer(id: String) {
        repository.cancelTransfer(id)
    }

    fun clearHistory() {
        viewModelScope.launch {
            repository.clearHistory()
        }
    }

    fun sendFiles(targetIp: String, targetPort: Int, files: List<File>, targetSessionCode: String) {
        viewModelScope.launch {
            val result = repository.sendFilesNatively(targetIp, targetPort, files, targetSessionCode)
            _sendResultFlow.emit(result)
        }
    }
}

class WifiTransferViewModelFactory(
    private val application: Application,
    private val repository: WifiTransferRepository
) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(WifiTransferViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return WifiTransferViewModel(application, repository) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
