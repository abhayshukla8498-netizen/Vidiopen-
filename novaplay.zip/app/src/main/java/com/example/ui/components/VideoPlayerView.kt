package com.example.ui.components

import android.app.Activity
import android.content.Context
import android.content.pm.ActivityInfo
import android.media.AudioManager
import android.os.Build
import android.util.TypedValue
import android.view.ViewGroup
import android.widget.Toast
import androidx.annotation.OptIn
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.common.Tracks
import androidx.media3.common.TrackSelectionOverride
import androidx.media3.common.PlaybackException
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.CaptionStyleCompat
import androidx.media3.ui.PlayerView
import com.example.data.model.MediaEntity
import com.example.data.model.VideoBookmarkEntity
import com.example.data.model.CapturedFrameEntity
import com.example.data.model.VideoPlaylistEntity
import com.example.data.model.PlaylistVideoEntity
import com.example.data.model.QueueVideoEntity
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ModalBottomSheet
import com.example.ui.theme.ElectricBlue
import androidx.media3.common.text.Cue
import androidx.media3.common.text.CueGroup
import com.example.ui.components.parseSubtitleFile
import com.example.ui.components.SubtitleCue
import com.example.ui.components.SubtitleLayoutContainer
import com.example.ui.components.SubtitleManagerSheetContent
import com.example.ui.theme.RoyalPurple
import com.example.ui.viewmodel.MediaViewModel
import com.example.ui.viewmodel.MediaConversionState
import coil.compose.AsyncImage
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.abs
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalDensity
import android.graphics.Bitmap

@OptIn(UnstableApi::class)
enum class ScreenMode(val label: String, val modeValue: Int) {
    FIT("Fit", AspectRatioFrameLayout.RESIZE_MODE_FIT),
    FILL("Fill", AspectRatioFrameLayout.RESIZE_MODE_FILL),
    STRETCH("Stretch", AspectRatioFrameLayout.RESIZE_MODE_FILL),
    ZOOM("Zoom", AspectRatioFrameLayout.RESIZE_MODE_ZOOM),
    ORIGINAL("Original", AspectRatioFrameLayout.RESIZE_MODE_FIT)
}

enum class BookmarkSort {
    TIME_ASC,
    TIME_DESC,
    DATE_DESC,
    DATE_ASC
}

data class AudioTrackInfo(
    val group: Tracks.Group,
    val trackIndex: Int,
    val name: String,
    val language: String,
    val isSelected: Boolean
)

data class SubtitleTrackInfo(
    val group: Tracks.Group?,
    val trackIndex: Int,
    val name: String,
    val language: String,
    val isSelected: Boolean
)

private fun isEmulator(): Boolean {
    val fingerprint = android.os.Build.FINGERPRINT
    val model = android.os.Build.MODEL
    val manufacturer = android.os.Build.MANUFACTURER
    val brand = android.os.Build.BRAND
    val device = android.os.Build.DEVICE
    val product = android.os.Build.PRODUCT
    return fingerprint.startsWith("generic")
            || fingerprint.startsWith("unknown")
            || model.contains("google_sdk")
            || model.contains("Emulator")
            || model.contains("Android SDK built for x86")
            || manufacturer.contains("Genymotion")
            || (brand.startsWith("generic") && device.startsWith("generic"))
            || "google_sdk" == product
}

@OptIn(UnstableApi::class)
@kotlin.OptIn(ExperimentalMaterial3Api::class)
@Composable
fun VideoPlayerView(
    media: MediaEntity,
    viewModel: MediaViewModel,
    onClose: (Long) -> Unit,
    onAudioConverted: () -> Unit = {},
    onNavigateToMusic: () -> Unit = {}
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val audioManager = remember { context.getSystemService(Context.AUDIO_SERVICE) as AudioManager }

    // Observe Subtitle Preferences from ViewModel
    val isSubEnabled by viewModel.subtitleEnabled.collectAsState()
    val subSize by viewModel.subtitleSize.collectAsState()
    val subDelay by viewModel.subtitleDelay.collectAsState()
    val subFontFamily by viewModel.subtitleFontFamily.collectAsState()
    val subFontWeight by viewModel.subtitleFontWeight.collectAsState()
    val subTextColor by viewModel.subtitleTextColor.collectAsState()
    val subBgColor by viewModel.subtitleBgColor.collectAsState()
    val subBgOpacity by viewModel.subtitleBgOpacity.collectAsState()
    val subOutlineColor by viewModel.subtitleOutlineColor.collectAsState()
    val subOutlineWidth by viewModel.subtitleOutlineWidth.collectAsState()
    val subBottomPadding by viewModel.subtitleBottomPadding.collectAsState()
    val subPosition by viewModel.subtitlePosition.collectAsState()
    val customSubPath by viewModel.activeCustomSubtitlePath.collectAsState()

    var nativeCues by remember { mutableStateOf<List<Cue>>(emptyList()) }

    // Screen Scale State for Pinch-to-Zoom
    var scaleFactor by remember(media.id) { mutableStateOf(1.0f) }

    // Screen Modes State
    var screenMode by remember { mutableStateOf(ScreenMode.FIT) }

    // Track states
    val audioTracks = remember { mutableStateListOf<AudioTrackInfo>() }
    val subtitleTracks = remember { mutableStateListOf<SubtitleTrackInfo>() }
    var activeAudioTrackName by remember(media.id) { mutableStateOf("Default") }
    var activeSubtitleTrackName by remember(media.id) { mutableStateOf("None") }

    // Playback Speed State
    val initialSpeed by viewModel.playbackSpeed.collectAsState()
    var currentSpeedSetting by remember { mutableStateOf(initialSpeed) }

    // Initialize state
    var isHdrEnabled by remember(media.id) { mutableStateOf(false) }
    var isPlaying by remember(media.id) { mutableStateOf(true) }
    var currentPos by remember(media.id) { mutableStateOf(media.lastPlayedPosition) }
    var totalDuration by remember(media.id) { mutableStateOf(media.duration) }
    var isBuffering by remember(media.id) { mutableStateOf(false) }
    var isLocked by remember { mutableStateOf(false) }

    // Manual subtitle file cues parsing and active cue text lookup
    var customCues by remember(customSubPath) { mutableStateOf<List<SubtitleCue>>(emptyList()) }
    LaunchedEffect(customSubPath) {
        if (customSubPath != null) {
            val file = java.io.File(customSubPath!!)
            if (file.exists()) {
                customCues = parseSubtitleFile(file)
            } else {
                customCues = emptyList()
            }
        } else {
            customCues = emptyList()
        }
    }

    val activeSubtitleText by remember(currentPos, customCues, isSubEnabled, activeSubtitleTrackName, subDelay, nativeCues) {
        derivedStateOf {
            if (!isSubEnabled) return@derivedStateOf ""
            
            // Check if manual/external track is active
            val originalName = customSubPath?.substringAfterLast("/")
            if (originalName != null && activeSubtitleTrackName == originalName) {
                val targetTime = currentPos - subDelay
                val matchingCue = customCues.find { targetTime in it.startTimeMs..it.endTimeMs }
                matchingCue?.text ?: ""
            } else {
                if (nativeCues.isNotEmpty()) {
                    nativeCues.joinToString("\n") { it.text?.toString() ?: "" }
                } else {
                    ""
                }
            }
        }
    }

    // Gesture Overlay Status
    var gestureOverlayText by remember { mutableStateOf("") }
    var showGestureIndicator by remember { mutableStateOf(false) }
    var currentVolume by remember { mutableStateOf(0.5f) }
    var currentBrightness by remember { mutableStateOf(0.7f) }

    // Screen Rotation Lock
    var isLandscape by remember { mutableStateOf(true) }

    // Dialog sheets
    var showAudioTrackDialog by remember { mutableStateOf(false) }
    var showSubtitleDialog by remember { mutableStateOf(false) }
    var showSpeedDialog by remember { mutableStateOf(false) }
    var showAspectDialog by remember { mutableStateOf(false) }
    var showBookmarksDialog by remember { mutableStateOf(false) }
    val bookmarks by viewModel.getBookmarksForVideo(media.id).collectAsState(initial = emptyList())
    var bookmarkSort by remember { mutableStateOf(BookmarkSort.TIME_ASC) }
    var showRenameDialog by remember { mutableStateOf(false) }
    var bookmarkToRename by remember { mutableStateOf<VideoBookmarkEntity?>(null) }
    var renameValue by remember { mutableStateOf("") }

    var showAbRepeatPanel by remember { mutableStateOf(false) }
    val abRepeatActive by viewModel.abRepeatActive.collectAsState()
    val abPointA by viewModel.abPointA.collectAsState()
    val abPointB by viewModel.abPointB.collectAsState()
    val loopCount by viewModel.loopCount.collectAsState()

    val precisionSeekEnabled by viewModel.precisionSeekEnabled.collectAsState()
    var isDraggingSeek by remember { mutableStateOf(false) }
    var dragSeekTime by remember { mutableStateOf(0L) }
    var previewBitmap by remember { mutableStateOf<Bitmap?>(null) }
    var isPrecisionActiveState by remember { mutableStateOf(false) }
    var currentSensitivityState by remember { mutableStateOf(1f) }

    // Queue & Playlist Sheets States
    var showQueueSheet by remember { mutableStateOf(false) }

    // Frame Capture States
    var extractedBitmap by remember { mutableStateOf<Bitmap?>(null) }
    var isExtractingFrame by remember { mutableStateOf(false) }
    var extractionProgress by remember { mutableStateOf(0f) }
    var extractionError by remember { mutableStateOf<String?>(null) }
    var showCaptureSettingsDialog by remember { mutableStateOf(false) }
    var savedFrameEntity by remember { mutableStateOf<CapturedFrameEntity?>(null) }
    var showFrameSavedDialog by remember { mutableStateOf(false) }

    // Error State
    var playerErrorMsg by remember { mutableStateOf<String?>(null) }

    // Screen flash for Screenshot Action
    var isFlashing by remember { mutableStateOf(false) }

    // Auto-hide controls timer
    var showControls by remember { mutableStateOf(true) }
    val isInPip by viewModel.isInPictureInPictureMode.collectAsState()
    var lastInteractionTime by remember { mutableStateOf(System.currentTimeMillis()) }

    // Multi-tap tracking
    var lastTapTime by remember { mutableStateOf(0L) }
    var lastTapRight by remember { mutableStateOf(false) }

    // Initialize ExoPlayer simply and robustly with built-in hardware & software fallbacks
    val exoPlayer = remember {
        viewModel.getOrCreatePlayer(context)
    }

    // Setup Track Change Listener
    DisposableEffect(exoPlayer) {
        val listener = object : Player.Listener {
            override fun onTracksChanged(tracks: Tracks) {
                audioTracks.clear()
                subtitleTracks.clear()
                
                // Add "None" option to subtitles
                subtitleTracks.add(SubtitleTrackInfo(null, -1, "None", "none", activeSubtitleTrackName == "None"))

                for (group in tracks.groups) {
                    if (group.type == C.TRACK_TYPE_AUDIO) {
                        for (trackIndex in 0 until group.length) {
                            val format = group.getTrackFormat(trackIndex)
                            val name = format.label ?: "Audio Track ${trackIndex + 1}"
                            val lang = format.language ?: "und"
                            val isSelected = group.isTrackSelected(trackIndex)
                            if (isSelected) {
                                activeAudioTrackName = "$name ($lang)"
                            }
                            audioTracks.add(AudioTrackInfo(group, trackIndex, name, lang, isSelected))
                        }
                    } else if (group.type == C.TRACK_TYPE_TEXT) {
                        for (trackIndex in 0 until group.length) {
                            val format = group.getTrackFormat(trackIndex)
                            val name = format.label ?: "Subtitle ${trackIndex + 1}"
                            val lang = format.language ?: "und"
                            val isSelected = group.isTrackSelected(trackIndex)
                            if (isSelected) {
                                activeSubtitleTrackName = "$name ($lang)"
                            }
                            subtitleTracks.add(SubtitleTrackInfo(group, trackIndex, name, lang, isSelected))
                        }
                    }
                }
            }

            override fun onCues(cues: List<Cue>) {
                nativeCues = cues
            }

            override fun onPlayerError(error: PlaybackException) {
                playerErrorMsg = when (error.errorCode) {
                    PlaybackException.ERROR_CODE_DECODER_INIT_FAILED -> "Decoder initialization failed. Using Software decoder fallback."
                    PlaybackException.ERROR_CODE_IO_FILE_NOT_FOUND,
                    PlaybackException.ERROR_CODE_IO_BAD_HTTP_STATUS -> "Unsupported file format or source corrupted."
                    else -> "An error occurred during video decoding. (Code: ${error.errorCode})"
                }
            }

            override fun onPlaybackStateChanged(state: Int) {
                isBuffering = (state == Player.STATE_BUFFERING)
                if (state == Player.STATE_ENDED) {
                    viewModel.playNextVideo(media) { nextMedia ->
                        // The next video is triggered successfully
                    }
                }
            }
        }
        exoPlayer.addListener(listener)
        onDispose {
            exoPlayer.removeListener(listener)
        }
    }

    // Orientation management
    DisposableEffect(isLandscape) {
        val activity = context as? Activity
        val oldOrientation = activity?.requestedOrientation
        activity?.requestedOrientation = if (isLandscape) {
            ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        } else {
            ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT
        }
        onDispose {
            activity?.requestedOrientation = oldOrientation ?: ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        }
    }

    // HDR Dynamic Window Manager
    LaunchedEffect(isHdrEnabled) {
        val activity = context as? Activity
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val isScreenHdr = context.resources.configuration.isScreenHdr
            if (isScreenHdr && !isEmulator()) {
                activity?.window?.colorMode = if (isHdrEnabled) {
                    ActivityInfo.COLOR_MODE_HDR
                } else {
                    ActivityInfo.COLOR_MODE_DEFAULT
                }
            } else {
                activity?.window?.colorMode = ActivityInfo.COLOR_MODE_DEFAULT
            }
        }
    }

    // Prepare Player with Media Resource
    LaunchedEffect(media.url) {
        val mediaItem = MediaItem.Builder()
            .setUri(media.url)
            .setMediaMetadata(
                androidx.media3.common.MediaMetadata.Builder()
                    .setTitle(media.title)
                    .setArtist(media.artist ?: media.category)
                    .build()
            )
            .build()
        exoPlayer.setMediaItem(mediaItem)
        exoPlayer.seekTo(media.lastPlayedPosition)
        exoPlayer.prepare()
        exoPlayer.setPlaybackSpeed(currentSpeedSetting)
        
        // Start Video Playback Service for Background play
        com.example.service.VideoPlaybackService.start(
            context = context,
            player = exoPlayer,
            title = media.title,
            artist = media.artist ?: media.category
        )
    }

    // Real-time Position & Duration updater loop
    LaunchedEffect(exoPlayer, abRepeatActive, abPointA, abPointB) {
        var lastSaveTime = 0L
        while (true) {
            val isPlayingNow = exoPlayer.isPlaying
            if (isPlayingNow) {
                currentPos = exoPlayer.currentPosition
                totalDuration = if (exoPlayer.duration > 0) exoPlayer.duration else media.duration
                isPlaying = true
                
                // Continuous position saving for process death / sudden app restarts (throttled to every 3 seconds to preserve performance)
                val currentTime = System.currentTimeMillis()
                if (currentTime - lastSaveTime >= 3000L) {
                    viewModel.updatePlaybackPosition(media.id, currentPos)
                    viewModel.saveLastWatchedVideo(media.id, currentPos, true)
                    lastSaveTime = currentTime
                }
                
                // Looping Check
                val pA = abPointA
                val pB = abPointB
                if (abRepeatActive && pA != null && pB != null) {
                    val currentPosition = exoPlayer.currentPosition
                    if (currentPosition >= pB) {
                        exoPlayer.seekTo(pA)
                        currentPos = pA
                        viewModel.incrementLoopCount()
                    } else if (currentPosition < pA) {
                        exoPlayer.seekTo(pA)
                        currentPos = pA
                    }
                }
            } else {
                isPlaying = false
            }
            delay(if (abRepeatActive) 50L else 500L)
        }
    }

    // Auto-hide controls monitoring loop
    LaunchedEffect(showControls, lastInteractionTime) {
        if (showControls && !isLocked) {
            delay(4000)
            if (System.currentTimeMillis() - lastInteractionTime >= 4000) {
                showControls = false
            }
        }
    }

    // Automatically load the last used subtitle file/settings on media ID change
    LaunchedEffect(media.id) {
        viewModel.loadLastSubtitleForVideo(media.id)
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black)
            .testTag("video_player_box")
    ) {
        // ExoPlayer Renderer Canvas with Pinch-to-Zoom Scale transformations
        AndroidView(
            factory = { ctx ->
                PlayerView(ctx).apply {
                    player = exoPlayer
                    useController = false
                    layoutParams = ViewGroup.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.MATCH_PARENT
                    )
                }
            },
            update = { playerView ->
                playerView.resizeMode = when (screenMode) {
                    ScreenMode.FIT -> AspectRatioFrameLayout.RESIZE_MODE_FIT
                    ScreenMode.FILL -> AspectRatioFrameLayout.RESIZE_MODE_FILL
                    ScreenMode.ZOOM -> AspectRatioFrameLayout.RESIZE_MODE_ZOOM
                    ScreenMode.STRETCH -> AspectRatioFrameLayout.RESIZE_MODE_FILL
                    ScreenMode.ORIGINAL -> AspectRatioFrameLayout.RESIZE_MODE_FIT
                }
                
                // Hide native subtitleView to allow our custom Compose Subtitle Renderer to display styles perfectly
                playerView.subtitleView?.visibility = android.view.View.GONE
            },
            modifier = Modifier
                .fillMaxSize()
                .graphicsLayer(
                    scaleX = scaleFactor,
                    scaleY = scaleFactor
                )
        )

        // Buffering Indicator Layer
        if (isBuffering) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.Black.copy(alpha = 0.5f)),
                contentAlignment = Alignment.Center
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    CircularProgressIndicator(
                        color = ElectricBlue,
                        modifier = Modifier.size(50.dp),
                        strokeWidth = 4.dp
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    Text(
                        text = "Buffering video...",
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )
                }
            }
        }

        // Simulated Brightness Overlay Layer
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.Black.copy(alpha = (1.0f - currentBrightness).coerceIn(0.0f, 0.85f)))
        )

        // Unified Premium Compose Subtitle Overlay (Requirement 4)
        if (isSubEnabled && activeSubtitleText.isNotEmpty()) {
            SubtitleLayoutContainer(
                text = activeSubtitleText,
                size = subSize,
                fontFamily = subFontFamily,
                fontWeight = subFontWeight,
                textColorHex = subTextColor,
                bgColorHex = subBgColor,
                bgOpacity = subBgOpacity,
                outlineColorHex = subOutlineColor,
                outlineWidth = subOutlineWidth,
                bottomPadding = subBottomPadding,
                position = subPosition,
                modifier = Modifier.fillMaxSize()
            )
        }

        // Action camera flash highlight
        if (isFlashing) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.White)
            )
            LaunchedEffect(Unit) {
                delay(80)
                isFlashing = false
            }
        }

        // Timeline Preview Overlay Card
        AnimatedVisibility(
            visible = isDraggingSeek,
            enter = fadeIn(animationSpec = tween(150)) + scaleIn(initialScale = 0.9f),
            exit = fadeOut(animationSpec = tween(150)) + scaleOut(targetScale = 0.9f),
            modifier = Modifier.align(Alignment.Center)
        ) {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color.Black.copy(alpha = 0.85f)),
                border = BorderStroke(1.5.dp, ElectricBlue),
                modifier = Modifier
                    .width(260.dp)
                    .padding(16.dp)
            ) {
                Column(
                    modifier = Modifier.padding(12.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    // Thumbnail Frame
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(130.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(Color.DarkGray),
                        contentAlignment = Alignment.Center
                    ) {
                        if (previewBitmap != null) {
                            Image(
                                bitmap = previewBitmap!!.asImageBitmap(),
                                contentDescription = "Preview frame",
                                contentScale = ContentScale.Crop,
                                modifier = Modifier.fillMaxSize()
                            )
                        } else {
                            CircularProgressIndicator(
                                color = ElectricBlue,
                                modifier = Modifier.size(24.dp),
                                strokeWidth = 2.dp
                            )
                        }
                        
                        // Fine control mode badge
                        if (isPrecisionActiveState) {
                            Box(
                                modifier = Modifier
                                    .align(Alignment.TopEnd)
                                    .padding(6.dp)
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(ElectricBlue)
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                            ) {
                                Text(
                                    text = "FINE: ${(currentSensitivityState * 100).toInt()}%",
                                    color = Color.Black,
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                    
                    Spacer(modifier = Modifier.height(8.dp))
                    
                    // Timestamp label
                    Text(
                        text = "${formatVideoTime(dragSeekTime)} / ${formatVideoTime(totalDuration)}",
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )
                    
                    if (isPrecisionActiveState) {
                        Text(
                            text = "Drag up/down to adjust precision",
                            color = ElectricBlue,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Medium,
                            modifier = Modifier.padding(top = 2.dp)
                        )
                    }
                }
            }
        }

        // Advanced Gesture Panel (Brightness, Volume, Seek, Skip, and Long Press)
        Box(
            modifier = Modifier
                .fillMaxSize()
                .pointerInput(isLocked) {
                    if (isLocked) return@pointerInput
                    detectTransformGestures { _, _, zoom, _ ->
                        scaleFactor = (scaleFactor * zoom).coerceIn(1.0f, 4.0f)
                        gestureOverlayText = "Zoom: ${"%.1f".format(scaleFactor)}x"
                        showGestureIndicator = true
                        lastInteractionTime = System.currentTimeMillis()
                    }
                }
                .pointerInput(isLocked) {
                    if (isLocked) {
                        detectTapGestures(onTap = {
                            showControls = !showControls
                            lastInteractionTime = System.currentTimeMillis()
                        })
                        return@pointerInput
                    }

                    detectDragGestures(
                        onDragStart = { offset ->
                            lastInteractionTime = System.currentTimeMillis()
                        },
                        onDragEnd = {
                            scope.launch {
                                delay(800)
                                showGestureIndicator = false
                            }
                        },
                        onDrag = { change, dragAmount ->
                            change.consume()
                            val dragX = dragAmount.x
                            val dragY = dragAmount.y
                            val width = size.width
                            val height = size.height

                            if (abs(dragX) > abs(dragY)) {
                                // Seek adjustment
                                val delta = (dragX / width) * totalDuration
                                val targetPos = (exoPlayer.currentPosition + delta).toLong().coerceIn(0L, totalDuration)
                                exoPlayer.seekTo(targetPos)
                                currentPos = targetPos
                                gestureOverlayText = "Seek: ${formatVideoTime(targetPos)}"
                                showGestureIndicator = true
                            } else {
                                if (change.position.x < width / 2) {
                                    // Brightness adjustment
                                    val delta = -dragY / height
                                    currentBrightness = (currentBrightness + delta).coerceIn(0.1f, 1.0f)
                                    val activity = context as? Activity
                                    activity?.window?.attributes?.let { lp ->
                                        lp.screenBrightness = currentBrightness
                                        activity.window.attributes = lp
                                    }
                                    gestureOverlayText = "Brightness: ${(currentBrightness * 100).toInt()}%"
                                    showGestureIndicator = true
                                } else {
                                    // Volume adjustment
                                    val delta = -dragY / height
                                    val maxVal = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
                                    val curVal = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC)
                                    val target = (curVal + delta * maxVal).coerceIn(0f, maxVal.toFloat())
                                    audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, target.toInt(), 0)
                                    currentVolume = target / maxVal
                                    gestureOverlayText = "Volume: ${(currentVolume * 100).toInt()}%"
                                    showGestureIndicator = true
                                }
                            }
                        }
                    )
                }
                .pointerInput(isLocked) {
                    detectTapGestures(
                        onTap = {
                            showControls = !showControls
                            lastInteractionTime = System.currentTimeMillis()
                        },
                        onDoubleTap = { offset ->
                            if (isLocked) return@detectTapGestures
                            val isRight = offset.x > size.width / 2
                            if (isRight) {
                                val targetVal = (exoPlayer.currentPosition + 10000L).coerceAtMost(totalDuration)
                                exoPlayer.seekTo(targetVal)
                                currentPos = targetVal
                                gestureOverlayText = "+10s Skip Forward"
                            } else {
                                val targetVal = (exoPlayer.currentPosition - 10000L).coerceAtLeast(0L)
                                exoPlayer.seekTo(targetVal)
                                currentPos = targetVal
                                gestureOverlayText = "-10s Skip Backward"
                            }
                            showGestureIndicator = true
                            scope.launch {
                                delay(800)
                                showGestureIndicator = false
                            }
                        },
                        onLongPress = {
                            if (isLocked) return@detectTapGestures
                            exoPlayer.setPlaybackSpeed(2.0f)
                            gestureOverlayText = "2.0x Fast Forward"
                            showGestureIndicator = true
                            scope.launch {
                                // Hold speed for 3 seconds or until standard tap
                                delay(3000)
                                exoPlayer.setPlaybackSpeed(currentSpeedSetting)
                                showGestureIndicator = false
                            }
                        }
                    )
                }
        )

        // Glowing HUD Center Gesture Indicator
        AnimatedVisibility(
            visible = showGestureIndicator,
            enter = fadeIn() + scaleIn(),
            exit = fadeOut() + scaleOut(),
            modifier = Modifier.align(Alignment.Center)
        ) {
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(16.dp))
                    .background(Color.Black.copy(alpha = 0.82f))
                    .padding(horizontal = 24.dp, vertical = 14.dp)
            ) {
                Text(
                    text = gestureOverlayText,
                    color = ElectricBlue,
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp,
                    textAlign = TextAlign.Center
                )
            }
        }

        // Luxury Top Control Overlay
        AnimatedVisibility(
            visible = showControls && !isInPip,
            enter = fadeIn() + slideInVertically(initialOffsetY = { -it }),
            exit = fadeOut() + slideOutVertically(targetOffsetY = { -it }),
            modifier = Modifier.align(Alignment.TopCenter)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color.Black.copy(alpha = 0.65f))
                    .statusBarsPadding()
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(
                        onClick = {
                            onClose(currentPos)
                        },
                        modifier = Modifier.testTag("player_back_btn")
                    ) {
                        Icon(
                            Icons.AutoMirrored.Rounded.ArrowBack,
                            contentDescription = "Exit Player",
                            tint = Color.White
                        )
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = media.title,
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                fontSize = 16.sp,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                modifier = Modifier.widthIn(max = 200.dp)
                            )
                            if (isHdrEnabled) {
                                Spacer(modifier = Modifier.width(8.dp))
                                Box(
                                    modifier = Modifier
                                        .background(
                                            androidx.compose.ui.graphics.Brush.horizontalGradient(
                                                listOf(Color(0xFFFF5722), Color(0xFFFF9800))
                                            ),
                                            shape = RoundedCornerShape(4.dp)
                                        )
                                        .padding(horizontal = 6.dp, vertical = 2.dp)
                                ) {
                                    Text(
                                        text = "HDR 10+",
                                        color = Color.White,
                                        fontSize = 9.sp,
                                        fontWeight = FontWeight.Black
                                    )
                                }
                            }
                        }
                        Text(
                            text = media.artist ?: "Vidiopen Ultra Engine",
                            color = ElectricBlue,
                            fontWeight = FontWeight.Medium,
                            fontSize = 12.sp
                        )
                    }
                }

                if (!isLocked) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        // Picture in Picture Button
                        IconButton(onClick = {
                            val activity = context as? Activity
                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                                val params = android.app.PictureInPictureParams.Builder().build()
                                activity?.enterPictureInPictureMode(params)
                            } else {
                                Toast.makeText(context, "PiP not supported on this device version", Toast.LENGTH_SHORT).show()
                            }
                        }) {
                            Icon(
                                Icons.Rounded.PictureInPicture,
                                contentDescription = "Picture in Picture",
                                tint = Color.White
                            )
                        }

                        // Floating Window Button (PiP Pro)
                        IconButton(onClick = {
                            viewModel.setFloatingMode(true)
                        }) {
                            Icon(
                                Icons.Rounded.Launch,
                                contentDescription = "Floating Window",
                                tint = ElectricBlue
                            )
                        }

                        // Capture Screenshot Action
                        IconButton(onClick = {
                            lastInteractionTime = System.currentTimeMillis()
                            if (isPlaying) {
                                exoPlayer.pause()
                                isPlaying = false
                            }
                            isExtractingFrame = true
                            extractionProgress = 0f
                            extractionError = null
                            viewModel.extractFullFrame(
                                videoUrl = media.url,
                                timestampMs = exoPlayer.currentPosition,
                                onProgress = { progress ->
                                    extractionProgress = progress
                                },
                                onSuccess = { bitmap ->
                                    extractedBitmap = bitmap
                                    isExtractingFrame = false
                                    showCaptureSettingsDialog = true
                                },
                                onError = { errorMsg ->
                                    isExtractingFrame = false
                                    extractionError = errorMsg
                                }
                            )
                        }) {
                            Icon(
                                Icons.Rounded.PhotoCamera,
                                contentDescription = "Take Frame Capture",
                                tint = Color.White
                            )
                        }

                        var showMoreMenu by remember { mutableStateOf(false) }

                        // More Options Action
                        IconButton(onClick = {
                            showMoreMenu = true
                            lastInteractionTime = System.currentTimeMillis()
                        }) {
                            Icon(
                                Icons.Rounded.MoreVert,
                                contentDescription = "More Options",
                                tint = Color.White
                            )
                        }

                        DropdownMenu(
                            expanded = showMoreMenu,
                            onDismissRequest = { showMoreMenu = false },
                            modifier = Modifier
                                .background(Color(0xFF161622))
                                .border(1.dp, Color.White.copy(alpha = 0.1f), RoundedCornerShape(12.dp))
                        ) {
                            DropdownMenuItem(
                                leadingIcon = {
                                    Icon(
                                        Icons.Rounded.HighQuality,
                                        contentDescription = null,
                                        tint = if (isHdrEnabled) ElectricBlue else Color.Gray
                                    )
                                },
                                text = {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            text = "HDR Booster",
                                            color = Color.White,
                                            fontSize = 14.sp
                                        )
                                        Switch(
                                            checked = isHdrEnabled,
                                            onCheckedChange = { checked ->
                                                val isScreenHdr = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                                                    context.resources.configuration.isScreenHdr
                                                } else false
                                                if (checked && (isEmulator() || !isScreenHdr)) {
                                                    Toast.makeText(context, "HDR is not supported on this device/emulator", Toast.LENGTH_SHORT).show()
                                                    isHdrEnabled = false
                                                } else {
                                                    isHdrEnabled = checked
                                                    val activity = context as? Activity
                                                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                                                        activity?.window?.colorMode = if (checked) {
                                                            ActivityInfo.COLOR_MODE_HDR
                                                        } else {
                                                            ActivityInfo.COLOR_MODE_DEFAULT
                                                        }
                                                    }
                                                    Toast.makeText(
                                                        context,
                                                        if (checked) "HDR Booster Enabled" else "HDR Booster Disabled",
                                                        Toast.LENGTH_SHORT
                                                    ).show()
                                                }
                                            },
                                            colors = SwitchDefaults.colors(
                                                checkedThumbColor = ElectricBlue,
                                                checkedTrackColor = ElectricBlue.copy(alpha = 0.5f)
                                            ),
                                            modifier = Modifier.scale(0.8f)
                                        )
                                    }
                                },
                                onClick = {
                                    val checked = !isHdrEnabled
                                    val isScreenHdr = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                                        context.resources.configuration.isScreenHdr
                                    } else false
                                    if (checked && (isEmulator() || !isScreenHdr)) {
                                        Toast.makeText(context, "HDR is not supported on this device/emulator", Toast.LENGTH_SHORT).show()
                                        isHdrEnabled = false
                                    } else {
                                        isHdrEnabled = checked
                                        val activity = context as? Activity
                                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                                            activity?.window?.colorMode = if (checked) {
                                                ActivityInfo.COLOR_MODE_HDR
                                            } else {
                                                ActivityInfo.COLOR_MODE_DEFAULT
                                            }
                                        }
                                        Toast.makeText(
                                            context,
                                            if (checked) "HDR Booster Enabled" else "HDR Booster Disabled",
                                            Toast.LENGTH_SHORT
                                        ).show()
                                    }
                                }
                            )

                            DropdownMenuItem(
                                leadingIcon = {
                                    Icon(
                                        Icons.Rounded.PhotoCamera,
                                        contentDescription = null,
                                        tint = ElectricBlue
                                    )
                                },
                                text = {
                                    Text(
                                        text = "Capture Frame",
                                        color = Color.White,
                                        fontSize = 14.sp
                                    )
                                },
                                onClick = {
                                    showMoreMenu = false
                                    if (isPlaying) {
                                        exoPlayer.pause()
                                        isPlaying = false
                                    }
                                    isExtractingFrame = true
                                    extractionProgress = 0f
                                    extractionError = null
                                    viewModel.extractFullFrame(
                                        videoUrl = media.url,
                                        timestampMs = exoPlayer.currentPosition,
                                        onProgress = { progress ->
                                            extractionProgress = progress
                                        },
                                        onSuccess = { bitmap ->
                                            extractedBitmap = bitmap
                                            isExtractingFrame = false
                                            showCaptureSettingsDialog = true
                                        },
                                        onError = { errorMsg ->
                                            isExtractingFrame = false
                                            extractionError = errorMsg
                                        }
                                    )
                                }
                            )

                            DropdownMenuItem(
                                leadingIcon = {
                                    Icon(
                                        Icons.Rounded.Timer,
                                        contentDescription = null,
                                        tint = ElectricBlue
                                    )
                                },
                                text = {
                                    Text(
                                        text = "Sleep Timer (30 mins)",
                                        color = Color.White,
                                        fontSize = 14.sp
                                    )
                                },
                                onClick = {
                                    showMoreMenu = false
                                    viewModel.startSleepTimer(30)
                                    Toast.makeText(context, "Playback will stop in 30 mins", Toast.LENGTH_SHORT).show()
                                }
                            )

                            DropdownMenuItem(
                                leadingIcon = {
                                    Icon(
                                        Icons.Rounded.MusicNote,
                                        contentDescription = null,
                                        tint = ElectricBlue
                                    )
                                },
                                text = {
                                    Text(
                                        text = "Convert to MP3",
                                        color = Color.White,
                                        fontSize = 14.sp
                                    )
                                },
                                onClick = {
                                    showMoreMenu = false
                                    if (isPlaying) {
                                        exoPlayer.pause()
                                        isPlaying = false
                                    }
                                    viewModel.convertVideoToMp3(
                                        videoUrl = media.url,
                                        title = media.title,
                                        artist = media.artist,
                                        durationMs = media.duration
                                    )
                                }
                            )
                        }
                    }
                }
            }
        }

        // Luxury Bottom Control Overlay
        AnimatedVisibility(
            visible = showControls && !isInPip,
            enter = fadeIn() + slideInVertically(initialOffsetY = { it }),
            exit = fadeOut() + slideOutVertically(targetOffsetY = { it }),
            modifier = Modifier.align(Alignment.BottomCenter)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color.Black.copy(alpha = 0.65f))
                    .navigationBarsPadding()
                    .padding(horizontal = 16.dp, vertical = 14.dp)
            ) {
                if (!isLocked) {
                    // Timeline Slider Row with Current and Remaining Duration Counters
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = formatVideoTime(currentPos),
                            color = Color.White,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Medium
                        )
                        PrecisionSlider(
                            currentValue = currentPos,
                            totalDuration = totalDuration,
                            bookmarks = bookmarks,
                            abPointA = abPointA,
                            abPointB = abPointB,
                            precisionSeekEnabled = precisionSeekEnabled,
                            onDragStart = {
                                isDraggingSeek = true
                                previewBitmap = null
                                lastInteractionTime = System.currentTimeMillis()
                            },
                            onDrag = { seekTime, isPrecisionActive, sensitivity ->
                                dragSeekTime = seekTime
                                isPrecisionActiveState = isPrecisionActive
                                currentSensitivityState = sensitivity
                                
                                exoPlayer.seekTo(seekTime)
                                currentPos = seekTime
                                
                                viewModel.getPreviewThumbnail(media.url, seekTime) { bitmap ->
                                    if (bitmap != null) {
                                        previewBitmap = bitmap
                                    }
                                }
                                lastInteractionTime = System.currentTimeMillis()
                            },
                            onDragEnd = { finalSeekTime ->
                                isDraggingSeek = false
                                exoPlayer.seekTo(finalSeekTime)
                                currentPos = finalSeekTime
                                lastInteractionTime = System.currentTimeMillis()
                            },
                            modifier = Modifier
                                .weight(1f)
                                .padding(horizontal = 14.dp)
                        )
                        val remaining = totalDuration - currentPos
                        Text(
                            text = "-${formatVideoTime(remaining)}",
                            color = Color.White.copy(alpha = 0.8f),
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Medium
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Buttons Control Panel
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            IconButton(onClick = {
                                showAudioTrackDialog = true
                                lastInteractionTime = System.currentTimeMillis()
                            }) {
                                Icon(
                                    Icons.Rounded.InterpreterMode,
                                    contentDescription = "Audio Tracks",
                                    tint = if (audioTracks.size > 1) ElectricBlue else Color.White
                                )
                            }

                            IconButton(onClick = {
                                showSubtitleDialog = true
                                lastInteractionTime = System.currentTimeMillis()
                            }) {
                                Icon(
                                    Icons.Rounded.Subtitles,
                                    contentDescription = "Subtitles Menu",
                                    tint = if (activeSubtitleTrackName != "None") ElectricBlue else Color.White
                                )
                            }

                            IconButton(onClick = {
                                showAspectDialog = true
                                lastInteractionTime = System.currentTimeMillis()
                            }) {
                                Icon(
                                    Icons.Rounded.AspectRatio,
                                    contentDescription = "Aspect Ratio",
                                    tint = Color.White
                                )
                            }

                            IconButton(onClick = {
                                showBookmarksDialog = true
                                lastInteractionTime = System.currentTimeMillis()
                            }) {
                                Icon(
                                    imageVector = if (bookmarks.isNotEmpty()) Icons.Rounded.Bookmark else Icons.Rounded.BookmarkBorder,
                                    contentDescription = "Bookmarks",
                                    tint = if (bookmarks.isNotEmpty()) ElectricBlue else Color.White
                                )
                            }

                            IconButton(onClick = {
                                showAbRepeatPanel = !showAbRepeatPanel
                                lastInteractionTime = System.currentTimeMillis()
                            }) {
                                Icon(
                                    imageVector = Icons.Rounded.Repeat,
                                    contentDescription = "A-B Repeat",
                                    tint = if (abRepeatActive) ElectricBlue else Color.White
                                )
                            }

                            IconButton(onClick = {
                                viewModel.setPrecisionSeekEnabled(!precisionSeekEnabled)
                                lastInteractionTime = System.currentTimeMillis()
                            }) {
                                Icon(
                                    imageVector = Icons.Rounded.Adjust,
                                    contentDescription = "Precision Seek Mode",
                                    tint = if (precisionSeekEnabled) ElectricBlue else Color.White
                                )
                            }

                            IconButton(onClick = {
                                showQueueSheet = true
                                lastInteractionTime = System.currentTimeMillis()
                            }) {
                                Icon(
                                    imageVector = Icons.Rounded.PlaylistPlay,
                                    contentDescription = "Up Next Queue & Playlists",
                                    tint = if (showQueueSheet) ElectricBlue else Color.White
                                )
                            }
                        }

                        // Central Playback Controls
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            IconButton(onClick = {
                                val target = (exoPlayer.currentPosition - 10000L).coerceAtLeast(0L)
                                exoPlayer.seekTo(target)
                                currentPos = target
                                lastInteractionTime = System.currentTimeMillis()
                            }) {
                                Icon(
                                    Icons.Rounded.Replay10,
                                    contentDescription = "Rewind 10 Seconds",
                                    tint = Color.White,
                                    modifier = Modifier.size(32.dp)
                                )
                            }

                            AnimatedVisibility(
                                visible = !isPlaying,
                                enter = fadeIn() + expandHorizontally(),
                                exit = fadeOut() + shrinkHorizontally()
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Spacer(modifier = Modifier.width(12.dp))
                                    IconButton(onClick = {
                                        exoPlayer.setSeekParameters(androidx.media3.exoplayer.SeekParameters.EXACT)
                                        val target = (exoPlayer.currentPosition - 33L).coerceAtLeast(0L)
                                        exoPlayer.seekTo(target)
                                        currentPos = target
                                        lastInteractionTime = System.currentTimeMillis()
                                    }) {
                                        Icon(
                                            Icons.Rounded.ChevronLeft,
                                            contentDescription = "Previous Frame",
                                            tint = ElectricBlue,
                                            modifier = Modifier.size(28.dp)
                                        )
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.width(16.dp))

                            IconButton(
                                onClick = {
                                    if (isPlaying) exoPlayer.pause() else exoPlayer.play()
                                    isPlaying = !isPlaying
                                    lastInteractionTime = System.currentTimeMillis()
                                },
                                modifier = Modifier
                                    .size(56.dp)
                                    .background(
                                        brush = androidx.compose.ui.graphics.Brush.linearGradient(
                                            colors = listOf(ElectricBlue, RoyalPurple)
                                        ),
                                        shape = CircleShape
                                    )
                                    .testTag("player_play_pause_btn")
                            ) {
                                Icon(
                                    imageVector = if (isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                                    contentDescription = "Play or Pause Video",
                                    tint = Color.White,
                                    modifier = Modifier.size(36.dp)
                                )
                            }

                            Spacer(modifier = Modifier.width(16.dp))

                            AnimatedVisibility(
                                visible = !isPlaying,
                                enter = fadeIn() + expandHorizontally(),
                                exit = fadeOut() + shrinkHorizontally()
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    IconButton(onClick = {
                                        exoPlayer.setSeekParameters(androidx.media3.exoplayer.SeekParameters.EXACT)
                                        val target = (exoPlayer.currentPosition + 33L).coerceAtMost(totalDuration)
                                        exoPlayer.seekTo(target)
                                        currentPos = target
                                        lastInteractionTime = System.currentTimeMillis()
                                    }) {
                                        Icon(
                                            Icons.Rounded.ChevronRight,
                                            contentDescription = "Next Frame",
                                            tint = ElectricBlue,
                                            modifier = Modifier.size(28.dp)
                                        )
                                    }
                                    Spacer(modifier = Modifier.width(12.dp))
                                }
                            }

                            IconButton(onClick = {
                                val target = (exoPlayer.currentPosition + 10000L).coerceAtMost(totalDuration)
                                exoPlayer.seekTo(target)
                                currentPos = target
                                lastInteractionTime = System.currentTimeMillis()
                            }) {
                                Icon(
                                    Icons.Rounded.Forward10,
                                    contentDescription = "Forward 10 Seconds",
                                    tint = Color.White,
                                    modifier = Modifier.size(32.dp)
                                )
                            }
                        }

                        // Rightside Controls
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(Color.White.copy(alpha = 0.14f))
                                    .clickable {
                                        showSpeedDialog = true
                                        lastInteractionTime = System.currentTimeMillis()
                                    }
                                    .padding(horizontal = 10.dp, vertical = 6.dp)
                            ) {
                                Text(
                                    text = "${currentSpeedSetting}x",
                                    color = Color.White,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }

                            Spacer(modifier = Modifier.width(10.dp))

                            IconButton(onClick = {
                                isLandscape = !isLandscape
                                lastInteractionTime = System.currentTimeMillis()
                            }) {
                                Icon(
                                    imageVector = if (isLandscape) Icons.Rounded.ScreenLockLandscape else Icons.Rounded.ScreenLockPortrait,
                                    contentDescription = "Toggle Orientation Lock",
                                    tint = Color.White
                                )
                            }

                            IconButton(onClick = {
                                isLocked = true
                                showControls = false
                                lastInteractionTime = System.currentTimeMillis()
                                Toast.makeText(context, "Controls locked. Double tap unlock to restore.", Toast.LENGTH_SHORT).show()
                            }) {
                                Icon(
                                    Icons.Rounded.LockOpen,
                                    contentDescription = "Lock controls",
                                    tint = Color.White
                                )
                            }
                        }
                    }
                } else {
                    Box(
                        modifier = Modifier.fillMaxWidth(),
                        contentAlignment = Alignment.Center
                    ) {
                        IconButton(
                            onClick = {
                                isLocked = false
                                showControls = true
                                lastInteractionTime = System.currentTimeMillis()
                                Toast.makeText(context, "Controls unlocked", Toast.LENGTH_SHORT).show()
                            },
                            modifier = Modifier
                                .background(Color.Black.copy(alpha = 0.85f), CircleShape)
                                .size(50.dp)
                        ) {
                            Icon(
                                Icons.Rounded.Lock,
                                contentDescription = "Unlock screen controls",
                                tint = ElectricBlue,
                                modifier = Modifier.size(28.dp)
                            )
                        }
                    }
                }
            }
        }

        // Subtitle customization sheet dialog
        if (showSubtitleDialog) {
            ModalBottomSheet(
                onDismissRequest = { showSubtitleDialog = false },
                containerColor = Color(0xFF161622),
                contentColor = Color.White,
                modifier = Modifier.fillMaxHeight(0.85f)
            ) {
                SubtitleManagerSheetContent(
                    media = media,
                    viewModel = viewModel,
                    activeSubtitleTrackName = activeSubtitleTrackName,
                    onSelectTrackName = { activeSubtitleTrackName = it },
                    subtitleTracks = subtitleTracks,
                    exoPlayer = exoPlayer,
                    onDismiss = { showSubtitleDialog = false }
                )
            }
        }

        // Audio track customization dialog
        if (showAudioTrackDialog) {
            Dialog(onDismissRequest = { showAudioTrackDialog = false }) {
                Card(
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF161622)),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(20.dp)
                    ) {
                        Text(
                            "Audio Track Selection",
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 18.sp
                        )
                        Spacer(modifier = Modifier.height(14.dp))

                        if (audioTracks.isEmpty()) {
                            Text("No alternative audio track found", color = Color.Gray, fontSize = 14.sp)
                        } else {
                            LazyColumn {
                                items(audioTracks) { track ->
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clickable {
                                                activeAudioTrackName = "${track.name} (${track.language})"
                                                val newParams = exoPlayer.trackSelectionParameters.buildUpon()
                                                    .clearOverridesOfType(C.TRACK_TYPE_AUDIO)
                                                    .addOverride(TrackSelectionOverride(track.group.mediaTrackGroup, track.trackIndex))
                                                    .build()
                                                exoPlayer.trackSelectionParameters = newParams
                                                showAudioTrackDialog = false
                                            }
                                            .padding(vertical = 10.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text("${track.name} [${track.language.uppercase()}]", color = Color.White, fontSize = 14.sp)
                                        if (activeAudioTrackName.contains(track.name)) {
                                            Icon(Icons.Rounded.Check, "Selected", tint = ElectricBlue)
                                        }
                                    }
                                }
                            }
                        }
                        Spacer(modifier = Modifier.height(14.dp))
                        Button(
                            onClick = { showAudioTrackDialog = false },
                            colors = ButtonDefaults.buttonColors(containerColor = ElectricBlue),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("Close", color = Color.Black, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        // Playback speed selection dialog
        if (showSpeedDialog) {
            Dialog(onDismissRequest = { showSpeedDialog = false }) {
                Card(
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF161622)),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(20.dp)
                    ) {
                        Text(
                            "Playback Speed Configuration",
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 18.sp
                        )
                        Spacer(modifier = Modifier.height(16.dp))

                        val speeds = listOf(0.25f, 0.5f, 0.75f, 1.0f, 1.25f, 1.5f, 1.75f, 2.0f)
                        LazyColumn {
                            items(speeds) { speed ->
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable {
                                            currentSpeedSetting = speed
                                            exoPlayer.setPlaybackSpeed(speed)
                                            viewModel.setPlaybackSpeed(speed)
                                            showSpeedDialog = false
                                        }
                                        .padding(vertical = 12.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text("${speed}x", color = Color.White, fontSize = 15.sp)
                                    if (currentSpeedSetting == speed) {
                                        Icon(Icons.Rounded.Check, "Selected", tint = ElectricBlue)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // Screen ratio aspect selection dialog
        if (showAspectDialog) {
            Dialog(onDismissRequest = { showAspectDialog = false }) {
                Card(
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF161622)),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(20.dp)
                    ) {
                        Text(
                            "Display Screen Aspect Mode",
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 18.sp
                        )
                        Spacer(modifier = Modifier.height(16.dp))

                        val modes = ScreenMode.values()
                        LazyColumn {
                            items(modes) { mode ->
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable {
                                            screenMode = mode
                                            showAspectDialog = false
                                        }
                                        .padding(vertical = 12.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(mode.label, color = Color.White, fontSize = 15.sp)
                                    if (screenMode == mode) {
                                        Icon(Icons.Rounded.Check, "Selected", tint = ElectricBlue)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // Elegant Dynamic Decoder Error/Issue overlay dialog screen
        if (playerErrorMsg != null) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.Black.copy(alpha = 0.95f))
                    .padding(32.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Icon(
                        Icons.Rounded.Warning,
                        contentDescription = "Decoder Warning",
                        tint = Color.Red,
                        modifier = Modifier.size(64.dp)
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    Text(
                        text = "Vidiopen Decoder Exception",
                        color = Color.White,
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = playerErrorMsg ?: "Decoder error",
                        color = Color.LightGray,
                        fontSize = 14.sp,
                        textAlign = TextAlign.Center
                    )
                    Spacer(modifier = Modifier.height(24.dp))
                    Row {
                        Button(
                            onClick = {
                                playerErrorMsg = null
                                exoPlayer.prepare()
                                exoPlayer.play()
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = ElectricBlue)
                        ) {
                            Text("Retry playback", color = Color.Black, fontWeight = FontWeight.Bold)
                        }
                        Spacer(modifier = Modifier.width(16.dp))
                        Button(
                            onClick = {
                                playerErrorMsg = null
                                // Force software fallback mode by preparing fresh
                                exoPlayer.prepare()
                                exoPlayer.play()
                                Toast.makeText(context, "Software Fallback decoding activated", Toast.LENGTH_SHORT).show()
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = RoyalPurple)
                        ) {
                            Text("Software Fallback", color = Color.White)
                        }
                    }
                    Spacer(modifier = Modifier.height(16.dp))
                    TextButton(onClick = { onClose(currentPos) }) {
                        Text("Exit Player", color = Color.White)
                    }
                }
            }
        }

        // Bookmarks dialog overlay
        if (showBookmarksDialog) {
            Dialog(onDismissRequest = { showBookmarksDialog = false }) {
                Card(
                    shape = RoundedCornerShape(24.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF161622)),
                    modifier = Modifier
                        .fillMaxWidth(if (isLandscape) 0.85f else 0.95f)
                        .fillMaxHeight(0.85f)
                        .padding(8.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(16.dp)
                    ) {
                        // Header with Close Button
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    Icons.Rounded.Bookmark,
                                    contentDescription = "Bookmarks",
                                    tint = ElectricBlue,
                                    modifier = Modifier.size(24.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    "Smart Video Bookmarks",
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 18.sp
                                )
                            }
                            IconButton(onClick = { showBookmarksDialog = false }) {
                                Icon(Icons.Rounded.Close, "Close", tint = Color.White)
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        // Quick Add Section at current playback time
                        Card(
                            colors = CardDefaults.cardColors(containerColor = Color.White.copy(alpha = 0.05f)),
                            shape = RoundedCornerShape(16.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(bottom = 12.dp)
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Text(
                                    text = "Add Bookmark at ${formatVideoTime(currentPos)}",
                                    color = ElectricBlue,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Spacer(modifier = Modifier.height(8.dp))
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    var newBookmarkName by remember { mutableStateOf("") }
                                    TextField(
                                        value = newBookmarkName,
                                        onValueChange = { newBookmarkName = it },
                                        placeholder = { Text("Bookmark name (optional)", color = Color.Gray, fontSize = 13.sp) },
                                        colors = TextFieldDefaults.colors(
                                            focusedContainerColor = Color.Transparent,
                                            unfocusedContainerColor = Color.Transparent,
                                            disabledContainerColor = Color.Transparent,
                                            cursorColor = ElectricBlue,
                                            focusedTextColor = Color.White,
                                            unfocusedTextColor = Color.White,
                                            focusedIndicatorColor = ElectricBlue,
                                            unfocusedIndicatorColor = Color.DarkGray
                                        ),
                                        singleLine = true,
                                        modifier = Modifier
                                            .weight(1f)
                                            .heightIn(max = 50.dp)
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Button(
                                        onClick = {
                                            val nameToUse = newBookmarkName.trim().ifEmpty { null }
                                            viewModel.addBookmark(
                                                videoId = media.id,
                                                videoName = media.title,
                                                timestampMs = currentPos,
                                                customName = nameToUse,
                                                videoUrl = media.url
                                            )
                                            newBookmarkName = ""
                                            Toast.makeText(context, "Bookmark saved at ${formatVideoTime(currentPos)}", Toast.LENGTH_SHORT).show()
                                        },
                                        colors = ButtonDefaults.buttonColors(containerColor = ElectricBlue),
                                        shape = RoundedCornerShape(12.dp),
                                        contentPadding = PaddingValues(horizontal = 14.dp, vertical = 8.dp)
                                    ) {
                                        Icon(Icons.Rounded.Add, contentDescription = "Add", tint = Color.Black)
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("Add", color = Color.Black, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                    }
                                }
                            }
                        }

                        // Sort & Actions header
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Saved (${bookmarks.size})",
                                color = Color.LightGray,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Medium
                            )

                            // Sort triggers
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text("Sort: ", color = Color.Gray, fontSize = 12.sp)
                                Spacer(modifier = Modifier.width(4.dp))
                                
                                // Sort by Time button
                                TextButton(
                                    onClick = {
                                        bookmarkSort = if (bookmarkSort == BookmarkSort.TIME_ASC) BookmarkSort.TIME_DESC else BookmarkSort.TIME_ASC
                                    },
                                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                                ) {
                                    Text(
                                        text = "Time " + if (bookmarkSort == BookmarkSort.TIME_ASC) "↑" else if (bookmarkSort == BookmarkSort.TIME_DESC) "↓" else "",
                                        color = if (bookmarkSort == BookmarkSort.TIME_ASC || bookmarkSort == BookmarkSort.TIME_DESC) ElectricBlue else Color.Gray,
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }

                                // Sort by Date button
                                TextButton(
                                    onClick = {
                                        bookmarkSort = if (bookmarkSort == BookmarkSort.DATE_DESC) BookmarkSort.DATE_ASC else BookmarkSort.DATE_DESC
                                    },
                                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                                ) {
                                    Text(
                                        text = "Date " + if (bookmarkSort == BookmarkSort.DATE_DESC) "↓" else if (bookmarkSort == BookmarkSort.DATE_ASC) "↑" else "",
                                        color = if (bookmarkSort == BookmarkSort.DATE_DESC || bookmarkSort == BookmarkSort.DATE_ASC) ElectricBlue else Color.Gray,
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(4.dp))

                        // Sorted Bookmarks List
                        val sortedBookmarks = remember(bookmarks, bookmarkSort) {
                            when (bookmarkSort) {
                                BookmarkSort.TIME_ASC -> bookmarks.sortedBy { it.timestampMs }
                                BookmarkSort.TIME_DESC -> bookmarks.sortedByDescending { it.timestampMs }
                                BookmarkSort.DATE_DESC -> bookmarks.sortedByDescending { it.dateCreated }
                                BookmarkSort.DATE_ASC -> bookmarks.sortedBy { it.dateCreated }
                            }
                        }

                        if (sortedBookmarks.isEmpty()) {
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .fillMaxWidth(),
                                contentAlignment = Alignment.Center
                            ) {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Icon(
                                        Icons.Rounded.BookmarkBorder,
                                        contentDescription = "Empty",
                                        tint = Color.DarkGray,
                                        modifier = Modifier.size(48.dp)
                                    )
                                    Spacer(modifier = Modifier.height(8.dp))
                                    Text(
                                        "No bookmarks yet for this video",
                                        color = Color.Gray,
                                        fontSize = 14.sp
                                    )
                                }
                            }
                        } else {
                            LazyColumn(
                                modifier = Modifier.weight(1f),
                                verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                items(sortedBookmarks) { bookmark ->
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clip(RoundedCornerShape(12.dp))
                                            .background(Color.White.copy(alpha = 0.03f))
                                            .clickable {
                                                exoPlayer.seekTo(bookmark.timestampMs)
                                                currentPos = bookmark.timestampMs
                                                showBookmarksDialog = false
                                                Toast.makeText(context, "Seeked to ${formatVideoTime(bookmark.timestampMs)}", Toast.LENGTH_SHORT).show()
                                            }
                                            .padding(8.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        // Thumbnail or Icon
                                        Box(
                                            modifier = Modifier
                                                .size(72.dp, 48.dp)
                                                .clip(RoundedCornerShape(8.dp))
                                                .background(Color.Black),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            if (bookmark.thumbnailPath != null) {
                                                AsyncImage(
                                                    model = bookmark.thumbnailPath,
                                                    contentDescription = "Bookmark frame",
                                                    modifier = Modifier.fillMaxSize(),
                                                    contentScale = androidx.compose.ui.layout.ContentScale.Crop
                                                )
                                            } else {
                                                // Fallback icon
                                                Icon(
                                                    Icons.Rounded.PlayCircleOutline,
                                                    contentDescription = "Play Frame",
                                                    tint = ElectricBlue,
                                                    modifier = Modifier.size(24.dp)
                                                )
                                            }
                                            
                                            // Timestamp overlay
                                            Box(
                                                modifier = Modifier
                                                    .fillMaxSize()
                                                    .padding(2.dp),
                                                contentAlignment = Alignment.BottomEnd
                                            ) {
                                                Text(
                                                    text = formatVideoTime(bookmark.timestampMs),
                                                    color = Color.White,
                                                    fontSize = 9.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    modifier = Modifier
                                                        .background(Color.Black.copy(alpha = 0.75f), RoundedCornerShape(2.dp))
                                                        .padding(horizontal = 3.dp, vertical = 1.dp)
                                                )
                                            }
                                        }

                                        Spacer(modifier = Modifier.width(12.dp))

                                        // Information
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(
                                                text = bookmark.bookmarkName ?: "Bookmark at ${formatVideoTime(bookmark.timestampMs)}",
                                                color = Color.White,
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 14.sp,
                                                maxLines = 1,
                                                overflow = TextOverflow.Ellipsis
                                            )
                                            val sdf = remember { SimpleDateFormat("MMM dd, yyyy HH:mm", Locale.getDefault()) }
                                            val dateStr = remember(bookmark.dateCreated) { sdf.format(Date(bookmark.dateCreated)) }
                                            Text(
                                                text = "Saved: $dateStr",
                                                color = Color.Gray,
                                                fontSize = 11.sp
                                            )
                                        }

                                        // Edit & Delete Actions
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            IconButton(
                                                onClick = {
                                                    bookmarkToRename = bookmark
                                                    renameValue = bookmark.bookmarkName ?: ""
                                                    showRenameDialog = true
                                                },
                                                modifier = Modifier.size(36.dp)
                                            ) {
                                                Icon(
                                                    Icons.Rounded.Edit,
                                                    contentDescription = "Rename",
                                                    tint = Color.LightGray,
                                                    modifier = Modifier.size(18.dp)
                                                )
                                            }
                                            IconButton(
                                                onClick = {
                                                    viewModel.deleteBookmark(bookmark.id)
                                                    Toast.makeText(context, "Bookmark deleted", Toast.LENGTH_SHORT).show()
                                                },
                                                modifier = Modifier.size(36.dp)
                                            ) {
                                                Icon(
                                                    Icons.Rounded.Delete,
                                                    contentDescription = "Delete",
                                                    tint = Color.Red.copy(alpha = 0.8f),
                                                    modifier = Modifier.size(18.dp)
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // Rename dialog overlay
        if (showRenameDialog && bookmarkToRename != null) {
            Dialog(onDismissRequest = { showRenameDialog = false }) {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF1F1F30)),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            "Rename Bookmark",
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        TextField(
                            value = renameValue,
                            onValueChange = { renameValue = it },
                            placeholder = { Text("Enter bookmark name", color = Color.Gray) },
                            colors = TextFieldDefaults.colors(
                                focusedContainerColor = Color.Transparent,
                                unfocusedContainerColor = Color.Transparent,
                                cursorColor = ElectricBlue,
                                focusedTextColor = Color.White,
                                unfocusedTextColor = Color.White,
                                focusedIndicatorColor = ElectricBlue,
                                unfocusedIndicatorColor = Color.DarkGray
                            ),
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.End
                        ) {
                            TextButton(onClick = { showRenameDialog = false }) {
                                Text("Cancel", color = Color.LightGray)
                            }
                            Spacer(modifier = Modifier.width(8.dp))
                            Button(
                                onClick = {
                                    viewModel.renameBookmark(bookmarkToRename!!.id, renameValue.trim())
                                    showRenameDialog = false
                                    bookmarkToRename = null
                                    Toast.makeText(context, "Bookmark renamed", Toast.LENGTH_SHORT).show()
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = ElectricBlue)
                            ) {
                                Text("Save", color = Color.Black, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }

        // 1. Frame Extraction Progress Dialog
        if (isExtractingFrame) {
            Dialog(onDismissRequest = { /* Prevent dismiss */ }) {
                Card(
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF161622)),
                    modifier = Modifier
                        .fillMaxWidth(0.85f)
                        .padding(16.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        CircularProgressIndicator(
                            color = ElectricBlue,
                            strokeWidth = 3.dp,
                            modifier = Modifier.size(48.dp)
                        )
                        Spacer(modifier = Modifier.height(20.dp))
                        Text(
                            text = "Extracting High-Res Frame...",
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "Processing background extraction...",
                            color = Color.Gray,
                            fontSize = 12.sp
                        )
                    }
                }
            }
        }

        // MP3 Conversion Dialogs
        val conversionState by viewModel.conversionState.collectAsState()

        when (val state = conversionState) {
            is MediaConversionState.Converting -> {
                Dialog(onDismissRequest = { /* Prevent dismiss during active conversion */ }) {
                    Card(
                        shape = RoundedCornerShape(20.dp),
                        colors = CardDefaults.cardColors(containerColor = Color(0xFF161622)),
                        modifier = Modifier
                            .fillMaxWidth(0.85f)
                            .padding(16.dp)
                            .border(1.dp, Color.White.copy(alpha = 0.1f), RoundedCornerShape(20.dp))
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(24.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Center
                        ) {
                            CircularProgressIndicator(
                                progress = { state.progress },
                                color = ElectricBlue,
                                strokeWidth = 4.dp,
                                modifier = Modifier.size(56.dp)
                            )
                            Spacer(modifier = Modifier.height(20.dp))
                            Text(
                                text = "Converting Video to MP3",
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                fontSize = 16.sp,
                                textAlign = TextAlign.Center
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = state.statusMessage,
                                color = Color.Gray,
                                fontSize = 13.sp,
                                textAlign = TextAlign.Center
                            )
                            Spacer(modifier = Modifier.height(12.dp))
                            Text(
                                text = "${(state.progress * 100).toInt()}%",
                                color = ElectricBlue,
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp
                            )
                        }
                    }
                }
            }
            is MediaConversionState.Success -> {
                AlertDialog(
                    onDismissRequest = { viewModel.resetConversionState() },
                    icon = {
                        Icon(
                            imageVector = Icons.Rounded.CheckCircle,
                            contentDescription = null,
                            tint = Color(0xFF00E676),
                            modifier = Modifier.size(48.dp)
                        )
                    },
                    title = {
                        Text(
                            text = "Conversion Complete!",
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            textAlign = TextAlign.Center
                        )
                    },
                    text = {
                        Column(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(
                                text = "Your MP3 song has been converted and downloaded successfully.",
                                color = Color.LightGray,
                                fontSize = 14.sp,
                                textAlign = TextAlign.Center
                            )
                            Spacer(modifier = Modifier.height(12.dp))
                            Card(
                                colors = CardDefaults.cardColors(containerColor = Color.White.copy(alpha = 0.05f)),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier.padding(12.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        imageVector = Icons.Rounded.MusicNote,
                                        contentDescription = null,
                                        tint = ElectricBlue,
                                        modifier = Modifier.size(24.dp)
                                    )
                                    Spacer(modifier = Modifier.width(12.dp))
                                    Text(
                                        text = state.fileName,
                                        color = Color.White,
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Medium,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                            }
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = "Saved in Music/Vidiopen folder",
                                color = Color.Gray,
                                fontSize = 11.sp
                            )
                        }
                    },
                    confirmButton = {
                        Button(
                            onClick = {
                                viewModel.resetConversionState()
                                onAudioConverted()
                                onClose(0L) // Close the video player
                                onNavigateToMusic()
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = ElectricBlue),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.fillMaxWidth().height(48.dp)
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.Center
                            ) {
                                Icon(Icons.Rounded.QueueMusic, contentDescription = null, tint = Color.Black)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "Go to Music Player",
                                    color = Color.Black,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    },
                    dismissButton = {
                        TextButton(
                            onClick = {
                                viewModel.resetConversionState()
                                onAudioConverted()
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("Stay Here", color = Color.Gray, fontWeight = FontWeight.Medium)
                        }
                    },
                    containerColor = Color(0xFF161622),
                    shape = RoundedCornerShape(24.dp)
                )
            }
            is MediaConversionState.Error -> {
                AlertDialog(
                    onDismissRequest = { viewModel.resetConversionState() },
                    icon = {
                        Icon(
                            imageVector = Icons.Rounded.Error,
                            contentDescription = null,
                            tint = Color.Red,
                            modifier = Modifier.size(48.dp)
                        )
                    },
                    title = {
                        Text(
                            text = "Conversion Failed",
                            color = Color.White,
                            fontWeight = FontWeight.Bold
                        )
                    },
                    text = {
                        Text(
                            text = state.errorMessage,
                            color = Color.LightGray,
                            textAlign = TextAlign.Center
                        )
                    },
                    confirmButton = {
                        Button(
                            onClick = { viewModel.resetConversionState() },
                            colors = ButtonDefaults.buttonColors(containerColor = ElectricBlue)
                        ) {
                            Text("OK", color = Color.Black, fontWeight = FontWeight.Bold)
                        }
                    },
                    containerColor = Color(0xFF161622),
                    shape = RoundedCornerShape(20.dp)
                )
            }
            MediaConversionState.Idle -> { /* Do nothing */ }
        }

        // 2. Extraction Error Dialog
        if (extractionError != null) {
            AlertDialog(
                onDismissRequest = { extractionError = null },
                title = { Text("Capture Failed", color = Color.White, fontWeight = FontWeight.Bold) },
                text = { Text(extractionError ?: "An unexpected error occurred.", color = Color.LightGray) },
                confirmButton = {
                    Button(
                        onClick = { extractionError = null },
                        colors = ButtonDefaults.buttonColors(containerColor = ElectricBlue)
                    ) {
                        Text("OK", color = Color.Black, fontWeight = FontWeight.Bold)
                    }
                },
                containerColor = Color(0xFF161622),
                shape = RoundedCornerShape(20.dp)
            )
        }

        // 3. Capture Settings Dialog
        if (showCaptureSettingsDialog && extractedBitmap != null) {
            val defaultName = remember(media.title, currentPos) {
                val cleanTitle = media.title.replace(Regex("[^a-zA-Z0-9_-]"), "_")
                val formattedTime = if (currentPos > 3600000) {
                    String.format("%02d_%02d_%02d_%03d", currentPos / 3600000, (currentPos % 3600000) / 60000, (currentPos % 60000) / 1000, currentPos % 1000)
                } else {
                    String.format("%02d_%02d_%03d", (currentPos % 3600000) / 60000, (currentPos % 60000) / 1000, currentPos % 1000)
                }
                "Vidiopen_${cleanTitle}_$formattedTime"
            }

            var fileNameInput by remember { mutableStateOf(defaultName) }
            var folderNameInput by remember { mutableStateOf("Vidiopen Captured Frames") }
            var formatSelected by remember { mutableStateOf("PNG") }
            var qualitySlider by remember { mutableStateOf(95f) }
            var isSavingInProgress by remember { mutableStateOf(false) }

            Dialog(onDismissRequest = { showCaptureSettingsDialog = false }) {
                Card(
                    shape = RoundedCornerShape(24.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF161622)),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp)
                        .border(1.dp, Color.White.copy(alpha = 0.1f), RoundedCornerShape(24.dp))
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(20.dp)
                    ) {
                        Text(
                            text = "Frame Capture Settings",
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 18.sp
                        )
                        Spacer(modifier = Modifier.height(16.dp))

                        // Preview of extracted bitmap
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(140.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(Color.Black),
                            contentAlignment = Alignment.Center
                        ) {
                            Image(
                                bitmap = extractedBitmap!!.asImageBitmap(),
                                contentDescription = "Frame Preview",
                                contentScale = ContentScale.Fit,
                                modifier = Modifier.fillMaxSize()
                            )
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        // File Name field
                        Text("File Name", color = Color.Gray, fontSize = 12.sp, fontWeight = FontWeight.Medium)
                        Spacer(modifier = Modifier.height(4.dp))
                        TextField(
                            value = fileNameInput,
                            onValueChange = { fileNameInput = it },
                            colors = TextFieldDefaults.colors(
                                focusedContainerColor = Color.White.copy(alpha = 0.05f),
                                unfocusedContainerColor = Color.White.copy(alpha = 0.05f),
                                focusedTextColor = Color.White,
                                unfocusedTextColor = Color.White,
                                cursorColor = ElectricBlue,
                                focusedIndicatorColor = ElectricBlue,
                                unfocusedIndicatorColor = Color.Transparent
                            ),
                            shape = RoundedCornerShape(8.dp),
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        // Save Folder field
                        Text("Save Folder", color = Color.Gray, fontSize = 12.sp, fontWeight = FontWeight.Medium)
                        Spacer(modifier = Modifier.height(4.dp))
                        TextField(
                            value = folderNameInput,
                            onValueChange = { folderNameInput = it },
                            colors = TextFieldDefaults.colors(
                                focusedContainerColor = Color.White.copy(alpha = 0.05f),
                                unfocusedContainerColor = Color.White.copy(alpha = 0.05f),
                                focusedTextColor = Color.White,
                                unfocusedTextColor = Color.White,
                                cursorColor = ElectricBlue,
                                focusedIndicatorColor = ElectricBlue,
                                unfocusedIndicatorColor = Color.Transparent
                            ),
                            shape = RoundedCornerShape(8.dp),
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        // Format selector
                        Text("Format", color = Color.Gray, fontSize = 12.sp, fontWeight = FontWeight.Medium)
                        Spacer(modifier = Modifier.height(4.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            listOf("PNG", "JPEG").forEach { format ->
                                val active = formatSelected == format
                                Box(
                                    modifier = Modifier
                                        .weight(1f)
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(if (active) ElectricBlue else Color.White.copy(alpha = 0.08f))
                                        .clickable { formatSelected = format }
                                        .padding(vertical = 10.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = format,
                                        color = if (active) Color.Black else Color.White,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 13.sp
                                    )
                                }
                            }
                        }

                        if (formatSelected == "JPEG") {
                            Spacer(modifier = Modifier.height(12.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("Quality", color = Color.Gray, fontSize = 12.sp, fontWeight = FontWeight.Medium)
                                Text("${qualitySlider.toInt()}%", color = ElectricBlue, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }
                            Slider(
                                value = qualitySlider,
                                onValueChange = { qualitySlider = it },
                                valueRange = 50f..100f,
                                colors = SliderDefaults.colors(
                                    thumbColor = ElectricBlue,
                                    activeTrackColor = ElectricBlue,
                                    inactiveTrackColor = Color.DarkGray
                                ),
                                modifier = Modifier.fillMaxWidth()
                            )
                        }

                        Spacer(modifier = Modifier.height(20.dp))

                        // Actions Row
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.End
                        ) {
                            TextButton(
                                onClick = { showCaptureSettingsDialog = false },
                                enabled = !isSavingInProgress
                            ) {
                                Text("Cancel", color = Color.LightGray)
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Button(
                                onClick = {
                                    isSavingInProgress = true
                                    viewModel.saveCapturedFrame(
                                        bitmap = extractedBitmap!!,
                                        fileName = fileNameInput.trim(),
                                        folderName = folderNameInput.trim(),
                                        format = formatSelected,
                                        quality = qualitySlider.toInt(),
                                        videoId = media.id,
                                        videoTitle = media.title,
                                        videoUrl = media.url,
                                        timestampMs = currentPos,
                                        onSuccess = { savedEntity ->
                                            isSavingInProgress = false
                                            savedFrameEntity = savedEntity
                                            showCaptureSettingsDialog = false
                                            showFrameSavedDialog = true
                                        },
                                        onError = { errorMsg ->
                                            isSavingInProgress = false
                                            Toast.makeText(context, errorMsg, Toast.LENGTH_LONG).show()
                                        }
                                    )
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = ElectricBlue),
                                enabled = !isSavingInProgress && fileNameInput.isNotBlank() && folderNameInput.isNotBlank(),
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                if (isSavingInProgress) {
                                    CircularProgressIndicator(
                                        color = Color.Black,
                                        strokeWidth = 2.dp,
                                        modifier = Modifier.size(18.dp)
                                    )
                                } else {
                                    Text("Save Frame", color = Color.Black, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }
            }
        }

        // 4. Frame Saved Preview/Confirmation Dialog
        if (showFrameSavedDialog && savedFrameEntity != null) {
            Dialog(onDismissRequest = { showFrameSavedDialog = false }) {
                Card(
                    shape = RoundedCornerShape(24.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF161622)),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp)
                        .border(1.dp, Color.White.copy(alpha = 0.1f), RoundedCornerShape(24.dp))
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(20.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.CheckCircle,
                            contentDescription = "Success",
                            tint = Color.Green,
                            modifier = Modifier.size(48.dp)
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "Frame Saved Successfully!",
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 18.sp
                        )
                        Spacer(modifier = Modifier.height(16.dp))

                        // Saved Image Preview
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(140.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(Color.Black),
                            contentAlignment = Alignment.Center
                        ) {
                            Image(
                                bitmap = extractedBitmap!!.asImageBitmap(),
                                contentDescription = "Saved Frame",
                                contentScale = ContentScale.Fit,
                                modifier = Modifier.fillMaxSize()
                            )
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        Text(
                            text = savedFrameEntity!!.fileName,
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp,
                            textAlign = TextAlign.Center,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            text = "Path: ${savedFrameEntity!!.filePath}",
                            color = Color.Gray,
                            fontSize = 11.sp,
                            textAlign = TextAlign.Center,
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis
                        )

                        Spacer(modifier = Modifier.height(20.dp))

                        // Action Grid
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            // Open
                            Button(
                                onClick = {
                                    try {
                                        val file = java.io.File(savedFrameEntity!!.filePath)
                                        val uri = androidx.core.content.FileProvider.getUriForFile(context, "com.example.fileprovider", file)
                                        val intent = android.content.Intent(android.content.Intent.ACTION_VIEW).apply {
                                            setDataAndType(uri, "image/*")
                                            addFlags(android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                        }
                                        context.startActivity(intent)
                                    } catch (e: Exception) {
                                        Toast.makeText(context, "No app found to open images: ${e.localizedMessage}", Toast.LENGTH_SHORT).show()
                                    }
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = Color.White.copy(alpha = 0.08f)),
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier.weight(1f)
                            ) {
                                Text("Open", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }

                            // Share
                            Button(
                                onClick = {
                                    try {
                                        val file = java.io.File(savedFrameEntity!!.filePath)
                                        val uri = androidx.core.content.FileProvider.getUriForFile(context, "com.example.fileprovider", file)
                                        val intent = android.content.Intent(android.content.Intent.ACTION_SEND).apply {
                                            type = "image/*"
                                            putExtra(android.content.Intent.EXTRA_STREAM, uri)
                                            addFlags(android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                        }
                                        context.startActivity(android.content.Intent.createChooser(intent, "Share Captured Frame"))
                                    } catch (e: Exception) {
                                        Toast.makeText(context, "Sharing failed: ${e.localizedMessage}", Toast.LENGTH_SHORT).show()
                                    }
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = Color.White.copy(alpha = 0.08f)),
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier.weight(1f)
                            ) {
                                Text("Share", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }

                            // Delete
                            Button(
                                onClick = {
                                    viewModel.deleteCapturedFrame(savedFrameEntity!!)
                                    showFrameSavedDialog = false
                                    Toast.makeText(context, "Deleted captured frame", Toast.LENGTH_SHORT).show()
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = Color.Red.copy(alpha = 0.15f)),
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier.weight(1f)
                            ) {
                                Text("Delete", color = Color.Red, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        TextButton(
                            onClick = { showFrameSavedDialog = false }
                        ) {
                            Text("Done", color = ElectricBlue, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        // Floating A-B Repeat indicator (visible when active, even when controls are hidden)
        if (abRepeatActive) {
            Box(
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .padding(top = 80.dp) // Render safely below status bar header
                    .clip(RoundedCornerShape(20.dp))
                    .background(Color.Black.copy(alpha = 0.65f))
                    .border(1.dp, ElectricBlue.copy(alpha = 0.3f), RoundedCornerShape(20.dp))
                    .padding(horizontal = 16.dp, vertical = 8.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Icon(
                        imageVector = Icons.Rounded.Repeat,
                        contentDescription = "Repeat Active",
                        tint = ElectricBlue,
                        modifier = Modifier.size(16.dp)
                    )
                    Text(
                        text = "A-B Repeat ON",
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp
                    )
                    Text(
                        text = "•",
                        color = Color.Gray,
                        fontSize = 12.sp
                    )
                    Text(
                        text = "Loop: $loopCount",
                        color = ElectricBlue,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp
                    )
                }
            }
        }

        // A-B Repeat Controls Panel (visible when controls are shown and showAbRepeatPanel is true)
        AnimatedVisibility(
            visible = showControls && showAbRepeatPanel && !isLocked && !isInPip,
            enter = fadeIn() + slideInVertically(initialOffsetY = { it / 2 }),
            exit = fadeOut() + slideOutVertically(targetOffsetY = { it / 2 }),
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(bottom = 120.dp) // Render above bottom control bar
                .padding(horizontal = 16.dp)
        ) {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF161622).copy(alpha = 0.95f)),
                border = BorderStroke(1.dp, Color.White.copy(alpha = 0.1f)),
                modifier = Modifier.fillMaxWidth(if (isLandscape) 0.6f else 0.95f)
            ) {
                Column(
                    modifier = Modifier.padding(12.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Rounded.Repeat,
                                contentDescription = "A-B Repeat Controls",
                                tint = ElectricBlue,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "A-B Looping Controller",
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp
                            )
                        }
                        IconButton(
                            onClick = { showAbRepeatPanel = false },
                            modifier = Modifier.size(24.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.Close,
                                contentDescription = "Close Panel",
                                tint = Color.Gray,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceEvenly,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Point A Control
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(
                                text = "Point A (Start)",
                                color = Color.Gray,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Medium
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = abPointA?.let { formatVideoTime(it) } ?: "--:--",
                                color = if (abPointA != null) ElectricBlue else Color.White,
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                Button(
                                    onClick = {
                                        viewModel.setAbPointA(currentPos)
                                        Toast.makeText(context, "A set at ${formatVideoTime(currentPos)}", Toast.LENGTH_SHORT).show()
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = ElectricBlue),
                                    shape = RoundedCornerShape(8.dp),
                                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                                    modifier = Modifier.height(30.dp)
                                ) {
                                    Text("Set A", color = Color.Black, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                                }
                                if (abPointA != null) {
                                    IconButton(
                                        onClick = {
                                            viewModel.resetAbPointA()
                                            Toast.makeText(context, "Point A cleared", Toast.LENGTH_SHORT).show()
                                        },
                                        modifier = Modifier.size(30.dp)
                                    ) {
                                        Icon(Icons.Rounded.Refresh, "Reset A", tint = Color.White, modifier = Modifier.size(16.dp))
                                    }
                                }
                            }
                        }

                        // Divider line
                        Box(
                            modifier = Modifier
                                .height(50.dp)
                                .width(1.dp)
                                .background(Color.White.copy(alpha = 0.1f))
                        )

                        // Point B Control
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(
                                text = "Point B (End)",
                                color = Color.Gray,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Medium
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = abPointB?.let { formatVideoTime(it) } ?: "--:--",
                                color = if (abPointB != null) RoyalPurple else Color.White,
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                Button(
                                    onClick = {
                                        if (abPointA == null) {
                                            Toast.makeText(context, "Please set Point A first", Toast.LENGTH_SHORT).show()
                                        } else if (currentPos <= abPointA!!) {
                                            Toast.makeText(context, "Point B must be after Point A", Toast.LENGTH_SHORT).show()
                                        } else {
                                            viewModel.setAbPointB(currentPos)
                                            Toast.makeText(context, "B set at ${formatVideoTime(currentPos)}", Toast.LENGTH_SHORT).show()
                                        }
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = RoyalPurple),
                                    shape = RoundedCornerShape(8.dp),
                                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                                    modifier = Modifier.height(30.dp)
                                ) {
                                    Text("Set B", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                                }
                                if (abPointB != null) {
                                    IconButton(
                                        onClick = {
                                            viewModel.resetAbPointB()
                                            Toast.makeText(context, "Point B cleared", Toast.LENGTH_SHORT).show()
                                        },
                                        modifier = Modifier.size(30.dp)
                                    ) {
                                        Icon(Icons.Rounded.Refresh, "Reset B", tint = Color.White, modifier = Modifier.size(16.dp))
                                    }
                                }
                            }
                        }
                    }

                    if (abRepeatActive) {
                        Spacer(modifier = Modifier.height(8.dp))
                        TextButton(
                            onClick = {
                                viewModel.disableAbRepeat()
                                Toast.makeText(context, "A-B Repeat disabled", Toast.LENGTH_SHORT).show()
                            },
                            contentPadding = PaddingValues(vertical = 4.dp)
                        ) {
                            Text("Disable Loop", color = Color.Red, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }
                    }
                }
            }
        }
    }

    if (showQueueSheet) {
        ModalBottomSheet(
            onDismissRequest = { showQueueSheet = false },
            containerColor = Color(0xFF1E1C24),
            contentColor = Color.White,
            modifier = Modifier.fillMaxHeight(0.85f)
        ) {
            QueueAndPlaylistSheetContent(
                media = media,
                viewModel = viewModel,
                onPlayMedia = { nextMedia ->
                    // Change play state if needed
                },
                onDismiss = { showQueueSheet = false }
            )
        }
    }

    // Release player resources properly when view disposables are called
    DisposableEffect(Unit) {
        onDispose {
            val isFloating = viewModel.isFloatingMode.value
            if (!isFloating) {
                // Stop the Background Playback Service!
                com.example.service.VideoPlaybackService.stop(context)
                onClose(currentPos)
            } else {
                viewModel.updatePlaybackPosition(media.id, currentPos)
            }

            // Restore default color mode when player is closed
            val activity = context as? Activity
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                activity?.window?.colorMode = ActivityInfo.COLOR_MODE_DEFAULT
            }
        }
    }
}

private fun formatVideoTime(ms: Long): String {
    val totalSeconds = ms / 1000
    val seconds = totalSeconds % 60
    val minutes = (totalSeconds / 60) % 60
    val hours = totalSeconds / 3600
    return if (hours > 0) {
        String.format("%02d:%02d:%02d", hours, minutes, seconds)
    } else {
        String.format("%02d:%02d", minutes, seconds)
    }
}

@Composable
fun PrecisionSlider(
    currentValue: Long,
    totalDuration: Long,
    bookmarks: List<VideoBookmarkEntity>,
    abPointA: Long?,
    abPointB: Long?,
    precisionSeekEnabled: Boolean,
    onDragStart: () -> Unit,
    onDrag: (seekTime: Long, isPrecisionModeActive: Boolean, sensitivity: Float) -> Unit,
    onDragEnd: (finalSeekTime: Long) -> Unit,
    modifier: Modifier = Modifier
) {
    val density = LocalDensity.current
    var isDragging by remember { mutableStateOf(false) }
    var dragTime by remember { mutableStateOf(currentValue) }
    
    var dragAccumulatedX by remember { mutableStateOf(0f) }
    var dragAccumulatedY by remember { mutableStateOf(0f) }
    
    LaunchedEffect(currentValue) {
        if (!isDragging) {
            dragTime = currentValue
        }
    }

    BoxWithConstraints(
        modifier = modifier
            .fillMaxWidth()
            .height(36.dp)
            .pointerInput(totalDuration, precisionSeekEnabled) {
                detectDragGestures(
                    onDragStart = { offset ->
                        isDragging = true
                        dragAccumulatedX = offset.x
                        dragAccumulatedY = 0f
                        
                        val fraction = (offset.x / size.width).coerceIn(0f, 1f)
                        dragTime = (fraction * totalDuration).toLong()
                        onDragStart()
                        onDrag(dragTime, false, 1f)
                    },
                    onDrag = { change, dragAmount ->
                        change.consume()
                        dragAccumulatedX += dragAmount.x
                        dragAccumulatedY += dragAmount.y
                        
                        val widthPx = size.width.toFloat()
                        val verticalOffsetDp = with(density) { abs(dragAccumulatedY).toDp().value }
                        
                        val sensitivity = if (precisionSeekEnabled) {
                            when {
                                verticalOffsetDp < 25f -> 1.0f
                                verticalOffsetDp < 60f -> 0.5f
                                verticalOffsetDp < 120f -> 0.2f
                                else -> 0.05f
                            }
                        } else {
                            1.0f
                        }
                        
                        val pxToMs = totalDuration.toFloat() / widthPx
                        val deltaMs = dragAmount.x * pxToMs * sensitivity
                        
                        val targetTime = (dragTime + deltaMs.toLong()).coerceIn(0L, totalDuration)
                        dragTime = targetTime
                        
                        val isPrecisionActive = precisionSeekEnabled && verticalOffsetDp >= 25f
                        onDrag(dragTime, isPrecisionActive, sensitivity)
                    },
                    onDragEnd = {
                        isDragging = false
                        onDragEnd(dragTime)
                    },
                    onDragCancel = {
                        isDragging = false
                        onDragEnd(dragTime)
                    }
                )
            },
        contentAlignment = Alignment.CenterStart
    ) {
        val displayValue = if (isDragging) dragTime else currentValue
        val progressFraction = if (totalDuration > 0) displayValue.toFloat() / totalDuration else 0f
        
        Canvas(modifier = Modifier.fillMaxWidth().height(16.dp)) {
            val trackY = size.height / 2f
            val trackHeight = 4.dp.toPx()
            
            // Inactive Track
            drawRoundRect(
                color = Color.DarkGray,
                topLeft = androidx.compose.ui.geometry.Offset(0f, trackY - trackHeight / 2),
                size = androidx.compose.ui.geometry.Size(size.width, trackHeight),
                cornerRadius = androidx.compose.ui.geometry.CornerRadius(2.dp.toPx(), 2.dp.toPx())
            )
            
            // Active Track
            drawRoundRect(
                color = ElectricBlue,
                topLeft = androidx.compose.ui.geometry.Offset(0f, trackY - trackHeight / 2),
                size = androidx.compose.ui.geometry.Size(size.width * progressFraction, trackHeight),
                cornerRadius = androidx.compose.ui.geometry.CornerRadius(2.dp.toPx(), 2.dp.toPx())
            )
            
            // Render Bookmark markers
            bookmarks.forEach { bookmark ->
                if (totalDuration > 0) {
                    val markerFraction = bookmark.timestampMs.toFloat() / totalDuration
                    val markerX = size.width * markerFraction
                    drawCircle(
                        color = Color(0xFFFFC107), // Amber/Gold for custom User Bookmarks
                        radius = 3.dp.toPx(),
                        center = androidx.compose.ui.geometry.Offset(markerX, trackY)
                    )
                }
            }
            
            // Render Point A marker
            if (totalDuration > 0 && abPointA != null) {
                val markerFraction = abPointA.toFloat() / totalDuration
                val markerX = size.width * markerFraction
                drawCircle(
                    color = ElectricBlue,
                    radius = 4.dp.toPx(),
                    center = androidx.compose.ui.geometry.Offset(markerX, trackY)
                )
            }
            
            // Render Point B marker
            if (totalDuration > 0 && abPointB != null) {
                val markerFraction = abPointB.toFloat() / totalDuration
                val markerX = size.width * markerFraction
                drawCircle(
                    color = RoyalPurple,
                    radius = 4.dp.toPx(),
                    center = androidx.compose.ui.geometry.Offset(markerX, trackY)
                )
            }
            
            // Draw thumb
            val thumbX = size.width * progressFraction
            drawCircle(
                color = if (isDragging) ElectricBlue else Color.White,
                radius = if (isDragging) 8.dp.toPx() else 6.dp.toPx(),
                center = androidx.compose.ui.geometry.Offset(thumbX, trackY)
            )
        }
    }
}

@kotlin.OptIn(ExperimentalMaterial3Api::class)
@Composable
fun QueueAndPlaylistSheetContent(
    media: MediaEntity,
    viewModel: MediaViewModel,
    onPlayMedia: (MediaEntity) -> Unit,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    var selectedTab by remember { mutableStateOf(0) } // 0 = Smart Queue, 1 = My Playlists

    // Preferences states
    val autoPlay by viewModel.autoPlayEnabled.collectAsState()
    val repeatPlaylist by viewModel.repeatPlaylistEnabled.collectAsState()
    val shufflePlaylist by viewModel.shufflePlaylistEnabled.collectAsState()

    // Playlist/Queue states
    val queue by viewModel.queueVideos.collectAsState()
    val playlists by viewModel.allPlaylists.collectAsState()
    val allMediaList by viewModel.allMedia.collectAsState()

    // Sub-dialog states
    var showCreateDialog by remember { mutableStateOf(false) }
    var createName by remember { mutableStateOf("") }

    var showRenameDialogId by remember { mutableStateOf<Long?>(null) }
    var renameName by remember { mutableStateOf("") }

    var activePlaylistIdForAdd by remember { mutableStateOf<Long?>(null) }
    var playlistAddSearchQuery by remember { mutableStateOf("") }

    // Selected expanded playlist ID (to view/edit its videos)
    var expandedPlaylistId by remember { mutableStateOf<Long?>(null) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF141218))
            .padding(16.dp)
    ) {
        // Tab Headers
        TabRow(
            selectedTabIndex = selectedTab,
            containerColor = Color(0xFF141218),
            contentColor = Color.White
        ) {
            Tab(
                selected = selectedTab == 0,
                onClick = { selectedTab = 0 },
                text = { Text("Smart Queue (${queue.size})", fontWeight = FontWeight.Bold) }
            )
            Tab(
                selected = selectedTab == 1,
                onClick = { selectedTab = 1 },
                text = { Text("My Playlists (${playlists.size})", fontWeight = FontWeight.Bold) }
            )
        }

        Spacer(modifier = Modifier.height(16.dp))

        if (selectedTab == 0) {
            // Smart Queue tab
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Up Next",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )

                if (queue.isNotEmpty()) {
                    TextButton(onClick = { viewModel.clearQueue() }) {
                        Icon(Icons.Rounded.DeleteSweep, contentDescription = "Clear Queue", tint = Color.Red)
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Clear Queue", color = Color.Red)
                    }
                }
            }

            // Queue Control Switches (Auto Play, Repeat, Shuffle)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                // Auto Play
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(
                        checked = autoPlay,
                        onCheckedChange = { viewModel.setAutoPlayEnabled(it) }
                    )
                    Text("Auto Play", color = Color.White, fontSize = 12.sp)
                }

                // Repeat
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(
                        checked = repeatPlaylist,
                        onCheckedChange = { viewModel.setRepeatPlaylistEnabled(it) }
                    )
                    Text("Repeat List", color = Color.White, fontSize = 12.sp)
                }

                // Shuffle
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(
                        checked = shufflePlaylist,
                        onCheckedChange = { viewModel.setShufflePlaylistEnabled(it) }
                    )
                    Text("Shuffle", color = Color.White, fontSize = 12.sp)
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            if (queue.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(
                            imageVector = Icons.Rounded.QueueMusic,
                            contentDescription = "Queue empty",
                            tint = Color.Gray,
                            modifier = Modifier.size(64.dp)
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text("Your Queue is Empty", color = Color.Gray)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text("Click 'Add to Queue' on any video below to begin", color = Color.Gray, fontSize = 12.sp)
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                ) {
                    items(queue.size) { index ->
                        val item = queue[index]
                        val isCurrent = media.id == item.videoId
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (isCurrent) Color(0xFF2C243B) else Color(0xFF1E1C24))
                                .clickable {
                                    val m = MediaEntity(
                                        id = item.videoId,
                                        title = item.title,
                                        url = item.url,
                                        duration = item.duration,
                                        artist = null,
                                        thumbnailUrl = item.thumbnailUrl,
                                        category = "Movies"
                                    )
                                    viewModel.playMedia(m)
                                    onPlayMedia(m)
                                }
                                .padding(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            // Video Icon/Thumbnail
                            Box(
                                modifier = Modifier
                                    .size(50.dp, 40.dp)
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(Color.Black),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(Icons.Rounded.PlayArrow, contentDescription = null, tint = ElectricBlue)
                            }

                            Spacer(modifier = Modifier.width(8.dp))

                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = item.title,
                                    color = if (isCurrent) ElectricBlue else Color.White,
                                    fontWeight = if (isCurrent) FontWeight.Bold else FontWeight.Normal,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                    fontSize = 14.sp
                                )
                                Text(
                                    text = formatVideoTime(item.duration),
                                    color = Color.Gray,
                                    fontSize = 12.sp
                                )
                            }

                            // Reordering buttons (Up / Down)
                            IconButton(
                                onClick = {
                                    if (index > 0) {
                                        val newList = queue.toMutableList()
                                        val temp = newList[index]
                                        newList[index] = newList[index - 1]
                                        newList[index - 1] = temp
                                        viewModel.reorderQueue(newList)
                                    }
                                },
                                enabled = index > 0
                            ) {
                                Icon(Icons.Rounded.ArrowUpward, contentDescription = "Move Up", tint = if (index > 0) Color.White else Color.DarkGray)
                            }

                            IconButton(
                                onClick = {
                                    if (index < queue.size - 1) {
                                        val newList = queue.toMutableList()
                                        val temp = newList[index]
                                        newList[index] = newList[index + 1]
                                        newList[index + 1] = temp
                                        viewModel.reorderQueue(newList)
                                    }
                                },
                                enabled = index < queue.size - 1
                            ) {
                                Icon(Icons.Rounded.ArrowDownward, contentDescription = "Move Down", tint = if (index < queue.size - 1) Color.White else Color.DarkGray)
                            }

                            // Remove button
                            IconButton(onClick = { viewModel.removeFromQueue(item.id) }) {
                                Icon(Icons.Rounded.Close, contentDescription = "Remove", tint = Color.LightGray)
                            }
                        }
                    }
                }
            }

            // Quick add section from scanned videos list
            Spacer(modifier = Modifier.height(12.dp))
            Text("Add Available Videos to Queue:", color = Color.LightGray, style = MaterialTheme.typography.titleSmall)
            Spacer(modifier = Modifier.height(4.dp))
            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(100.dp)
            ) {
                val nonInQueue = allMediaList.filter { m -> queue.none { q -> q.videoId == m.id } }
                if (nonInQueue.isEmpty()) {
                    item {
                        Text("All videos already in queue or no videos found.", color = Color.Gray, fontSize = 12.sp, modifier = Modifier.padding(8.dp))
                    }
                } else {
                    items(nonInQueue) { video ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 2.dp)
                                .clip(RoundedCornerShape(6.dp))
                                .background(Color(0xFF1E1C24))
                                .clickable {
                                    viewModel.addToQueue(video)
                                    Toast.makeText(context, "Added to queue", Toast.LENGTH_SHORT).show()
                                }
                                .padding(8.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(video.title, color = Color.White, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                TextButton(onClick = {
                                    viewModel.playNext(video)
                                    Toast.makeText(context, "Will play next", Toast.LENGTH_SHORT).show()
                                }) {
                                    Text("Play Next", color = ElectricBlue, fontSize = 11.sp)
                                }
                                Icon(Icons.Rounded.Add, contentDescription = "Add", tint = ElectricBlue, modifier = Modifier.size(16.dp))
                            }
                        }
                    }
                }
            }

        } else {
            // Playlists tab
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "My Playlists",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )

                Button(
                    onClick = {
                        createName = ""
                        showCreateDialog = true
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = ElectricBlue)
                ) {
                    Icon(Icons.Rounded.Add, contentDescription = "Create Playlist")
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Create")
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            if (playlists.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    contentAlignment = Alignment.Center
                ) {
                    Text("No playlists created yet.", color = Color.Gray)
                }
            } else {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                ) {
                    items(playlists) { playlist ->
                        val isExpanded = expandedPlaylistId == playlist.id
                        val playlistVideosFlow = remember(playlist.id) { viewModel.getVideosForPlaylist(playlist.id) }
                        val playlistVideos by playlistVideosFlow.collectAsState(initial = emptyList())

                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp),
                            colors = CardDefaults.cardColors(containerColor = Color(0xFF1E1C24))
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(
                                        modifier = Modifier
                                            .weight(1f)
                                            .clickable {
                                                expandedPlaylistId = if (isExpanded) null else playlist.id
                                            }
                                    ) {
                                        Text(
                                            text = playlist.name,
                                            fontWeight = FontWeight.Bold,
                                            color = Color.White,
                                            fontSize = 16.sp
                                        )
                                        Text(
                                            text = "${playlistVideos.size} videos",
                                            color = Color.Gray,
                                            fontSize = 12.sp
                                        )
                                    }

                                    Row {
                                        IconButton(onClick = {
                                            activePlaylistIdForAdd = playlist.id
                                            playlistAddSearchQuery = ""
                                        }) {
                                            Icon(Icons.Rounded.VideoCall, contentDescription = "Add Videos", tint = ElectricBlue)
                                        }

                                        IconButton(onClick = {
                                            renameName = playlist.name
                                            showRenameDialogId = playlist.id
                                        }) {
                                            Icon(Icons.Rounded.Edit, contentDescription = "Rename", tint = Color.LightGray)
                                        }

                                        IconButton(onClick = { viewModel.deletePlaylist(playlist.id) }) {
                                            Icon(Icons.Rounded.Delete, contentDescription = "Delete", tint = Color.Red)
                                        }
                                    }
                                }

                                if (isExpanded) {
                                    Divider(color = Color.DarkGray, modifier = Modifier.padding(vertical = 8.dp))

                                    if (playlistVideos.isEmpty()) {
                                        Text("This playlist is empty. Click the video icon above to add videos.", color = Color.Gray, fontSize = 12.sp, modifier = Modifier.padding(vertical = 8.dp))
                                    } else {
                                        playlistVideos.forEachIndexed { vIndex, vItem ->
                                            val isVidCurrent = media.id == vItem.videoId
                                            Row(
                                                modifier = Modifier
                                                    .fillMaxWidth()
                                                    .padding(vertical = 2.dp)
                                                    .clip(RoundedCornerShape(6.dp))
                                                    .background(if (isVidCurrent) Color(0xFF2C243B) else Color(0xFF141218))
                                                    .clickable {
                                                        val m = MediaEntity(
                                                            id = vItem.videoId,
                                                            title = vItem.title,
                                                            url = vItem.url,
                                                            duration = vItem.duration,
                                                            artist = null,
                                                            thumbnailUrl = vItem.thumbnailUrl,
                                                            category = "Movies"
                                                        )
                                                        viewModel.setCurrentPlayingPlaylist(playlist.id, playlistVideos)
                                                        viewModel.playMedia(m)
                                                        onPlayMedia(m)
                                                    }
                                                    .padding(8.dp),
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                Icon(Icons.Rounded.PlayArrow, contentDescription = null, tint = ElectricBlue, modifier = Modifier.size(16.dp))
                                                Spacer(modifier = Modifier.width(6.dp))
                                                Text(
                                                    text = vItem.title,
                                                    color = if (isVidCurrent) ElectricBlue else Color.White,
                                                    fontSize = 13.sp,
                                                    maxLines = 1,
                                                    overflow = TextOverflow.Ellipsis,
                                                    modifier = Modifier.weight(1f)
                                                )

                                                // Up/Down arrows to reorder
                                                IconButton(
                                                    onClick = {
                                                        if (vIndex > 0) {
                                                            val newList = playlistVideos.toMutableList()
                                                            val temp = newList[vIndex]
                                                            newList[vIndex] = newList[vIndex - 1]
                                                            newList[vIndex - 1] = temp
                                                            viewModel.reorderPlaylistVideos(playlist.id, newList)
                                                        }
                                                    },
                                                    enabled = vIndex > 0,
                                                    modifier = Modifier.size(24.dp)
                                                ) {
                                                    Icon(Icons.Rounded.ArrowUpward, contentDescription = "Move Up", tint = if (vIndex > 0) Color.White else Color.DarkGray, modifier = Modifier.size(16.dp))
                                                }

                                                IconButton(
                                                    onClick = {
                                                        if (vIndex < playlistVideos.size - 1) {
                                                            val newList = playlistVideos.toMutableList()
                                                            val temp = newList[vIndex]
                                                            newList[vIndex] = newList[vIndex + 1]
                                                            newList[vIndex + 1] = temp
                                                            viewModel.reorderPlaylistVideos(playlist.id, newList)
                                                        }
                                                    },
                                                    enabled = vIndex < playlistVideos.size - 1,
                                                    modifier = Modifier.size(24.dp)
                                                ) {
                                                    Icon(Icons.Rounded.ArrowDownward, contentDescription = "Move Down", tint = if (vIndex < playlistVideos.size - 1) Color.White else Color.DarkGray, modifier = Modifier.size(16.dp))
                                                }

                                                IconButton(
                                                    onClick = { viewModel.removeVideoFromPlaylist(playlist.id, vItem.id) },
                                                    modifier = Modifier.size(24.dp)
                                                ) {
                                                    Icon(Icons.Rounded.Delete, contentDescription = "Remove", tint = Color.Red, modifier = Modifier.size(16.dp))
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // 1. Create Playlist Dialog
    if (showCreateDialog) {
        AlertDialog(
            onDismissRequest = { showCreateDialog = false },
            title = { Text("Create Playlist", color = Color.White) },
            text = {
                OutlinedTextField(
                    value = createName,
                    onValueChange = { createName = it },
                    label = { Text("Playlist Name") },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White,
                        focusedLabelColor = ElectricBlue,
                        unfocusedLabelColor = Color.Gray,
                        focusedBorderColor = ElectricBlue,
                        unfocusedBorderColor = Color.Gray
                    ),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (createName.isNotBlank()) {
                            viewModel.createPlaylist(createName.trim())
                            showCreateDialog = false
                        } else {
                            Toast.makeText(context, "Name cannot be empty", Toast.LENGTH_SHORT).show()
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = ElectricBlue)
                ) {
                    Text("Create")
                }
            },
            dismissButton = {
                TextButton(onClick = { showCreateDialog = false }) {
                    Text("Cancel", color = Color.White)
                }
            },
            containerColor = Color(0xFF1E1C24)
        )
    }

    // 2. Rename Playlist Dialog
    showRenameDialogId?.let { playlistId ->
        AlertDialog(
            onDismissRequest = { showRenameDialogId = null },
            title = { Text("Rename Playlist", color = Color.White) },
            text = {
                OutlinedTextField(
                    value = renameName,
                    onValueChange = { renameName = it },
                    label = { Text("New Name") },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White,
                        focusedLabelColor = ElectricBlue,
                        unfocusedLabelColor = Color.Gray,
                        focusedBorderColor = ElectricBlue,
                        unfocusedBorderColor = Color.Gray
                    ),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (renameName.isNotBlank()) {
                            viewModel.renamePlaylist(playlistId, renameName.trim())
                            showRenameDialogId = null
                        } else {
                            Toast.makeText(context, "Name cannot be empty", Toast.LENGTH_SHORT).show()
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = ElectricBlue)
                ) {
                    Text("Rename")
                }
            },
            dismissButton = {
                TextButton(onClick = { showRenameDialogId = null }) {
                    Text("Cancel", color = Color.White)
                }
            },
            containerColor = Color(0xFF1E1C24)
        )
    }

    // 3. Add Video to Playlist Dialog (Selection Picker)
    activePlaylistIdForAdd?.let { playlistId ->
        val playlistVideosFlow = remember(playlistId) { viewModel.getVideosForPlaylist(playlistId) }
        val currentPlaylistVideos by playlistVideosFlow.collectAsState(initial = emptyList())

        AlertDialog(
            onDismissRequest = { activePlaylistIdForAdd = null },
            title = { Text("Add Videos", color = Color.White) },
            text = {
                Column {
                    OutlinedTextField(
                        value = playlistAddSearchQuery,
                        onValueChange = { playlistAddSearchQuery = it },
                        placeholder = { Text("Search videos...") },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White,
                            focusedBorderColor = ElectricBlue,
                            unfocusedBorderColor = Color.Gray
                        ),
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 8.dp)
                    )

                    val filteredVideos = allMediaList.filter {
                        it.title.contains(playlistAddSearchQuery, ignoreCase = true)
                    }

                    LazyColumn(modifier = Modifier.height(250.dp)) {
                        items(filteredVideos) { video ->
                            val alreadyIn = currentPlaylistVideos.any { it.videoId == video.id }
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp)
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(Color(0xFF141218))
                                    .padding(8.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(video.title, color = Color.White, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
                                if (alreadyIn) {
                                    Icon(Icons.Rounded.Check, contentDescription = "Added", tint = ElectricBlue)
                                } else {
                                    IconButton(
                                        onClick = {
                                            viewModel.addVideoToPlaylist(playlistId, video)
                                            Toast.makeText(context, "Added to playlist", Toast.LENGTH_SHORT).show()
                                        },
                                        modifier = Modifier.size(24.dp)
                                    ) {
                                        Icon(Icons.Rounded.Add, contentDescription = "Add", tint = ElectricBlue)
                                    }
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = { activePlaylistIdForAdd = null },
                    colors = ButtonDefaults.buttonColors(containerColor = ElectricBlue)
                ) {
                    Text("Done")
                }
            },
            containerColor = Color(0xFF1E1C24)
        )
    }
}
