package com.example.ui.viewmodel

import android.app.Application
import android.database.ContentObserver
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.model.MediaEntity
import com.example.data.model.ScannedVideo
import com.example.data.model.VideoFolder
import com.example.data.repository.MediaStoreRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.io.File

private val android.content.Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "media_settings")

enum class VideoSortOrder {
    NEWEST,
    OLDEST,
    NAME_A_Z,
    NAME_Z_A,
    SIZE_LARGEST,
    SIZE_SMALLEST,
    DURATION_LONGEST,
    DURATION_SHORTEST
}

enum class VideoFilterType {
    ALL,
    HD,
    FULL_HD,
    FOUR_K,
    SHORT,
    LONG
}

class MediaStoreViewModel(
    application: Application,
    private val repository: MediaStoreRepository
) : AndroidViewModel(application) {

    private val SORT_ORDER_KEY = stringPreferencesKey("video_sort_order")
    private val FILTER_TYPE_KEY = stringPreferencesKey("video_filter_type")

    private val _scannedVideos = MutableStateFlow<List<ScannedVideo>>(emptyList())
    val scannedVideos: StateFlow<List<ScannedVideo>> = _scannedVideos.asStateFlow()

    private val _scannedFolders = MutableStateFlow<List<VideoFolder>>(emptyList())
    val scannedFolders: StateFlow<List<VideoFolder>> = _scannedFolders.asStateFlow()

    private val _isScanning = MutableStateFlow(false)
    val isScanning: StateFlow<Boolean> = _isScanning.asStateFlow()

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _sortOrder = MutableStateFlow(VideoSortOrder.NEWEST)
    val sortOrder: StateFlow<VideoSortOrder> = _sortOrder.asStateFlow()

    private val _filterType = MutableStateFlow(VideoFilterType.ALL)
    val filterType: StateFlow<VideoFilterType> = _filterType.asStateFlow()

    // Real-time Search, Sort and Filter combined for smooth 10k+ video scrolling
    val filteredVideos: StateFlow<List<ScannedVideo>> = combine(
        _scannedVideos,
        _searchQuery,
        _sortOrder,
        _filterType
    ) { videos, query, sort, filter ->
        var result = videos

        // 1. Filter by Search Query
        if (query.isNotEmpty()) {
            result = result.filter { video ->
                video.title.contains(query, ignoreCase = true) ||
                File(video.path).parentFile?.name?.contains(query, ignoreCase = true) == true
            }
        }

        // 2. Filter by Category Specs
        result = when (filter) {
            VideoFilterType.ALL -> result
            VideoFilterType.HD -> result.filter { maxOf(it.width, it.height) >= 1280 }
            VideoFilterType.FULL_HD -> result.filter { maxOf(it.width, it.height) >= 1920 }
            VideoFilterType.FOUR_K -> result.filter { maxOf(it.width, it.height) >= 3840 }
            VideoFilterType.SHORT -> result.filter { it.duration < 5 * 60 * 1000 }
            VideoFilterType.LONG -> result.filter { it.duration > 20 * 60 * 1000 }
        }

        // 3. Sort Order
        result = when (sort) {
            VideoSortOrder.NEWEST -> result.sortedByDescending { it.dateAdded }
            VideoSortOrder.OLDEST -> result.sortedBy { it.dateAdded }
            VideoSortOrder.NAME_A_Z -> result.sortedWith(compareBy(String.CASE_INSENSITIVE_ORDER) { it.title })
            VideoSortOrder.NAME_Z_A -> result.sortedWith(compareByDescending(String.CASE_INSENSITIVE_ORDER) { it.title })
            VideoSortOrder.SIZE_LARGEST -> result.sortedByDescending { it.size }
            VideoSortOrder.SIZE_SMALLEST -> result.sortedBy { it.size }
            VideoSortOrder.DURATION_LONGEST -> result.sortedByDescending { it.duration }
            VideoSortOrder.DURATION_SHORTEST -> result.sortedBy { it.duration }
        }

        result
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Real-time combined folders based on Search and Sort
    val filteredFolders: StateFlow<List<VideoFolder>> = combine(
        _scannedFolders,
        _searchQuery,
        _sortOrder
    ) { folders, query, sort ->
        var result = folders

        // Filter folders by name or containing video name
        if (query.isNotEmpty()) {
            result = result.filter { folder ->
                folder.name.contains(query, ignoreCase = true) ||
                folder.videos.any { it.title.contains(query, ignoreCase = true) }
            }
        }

        // Sort folders based on selected sort order
        result = when (sort) {
            VideoSortOrder.NEWEST -> result.sortedByDescending { it.latestVideoDateAdded }
            VideoSortOrder.OLDEST -> result.sortedBy { it.latestVideoDateAdded }
            VideoSortOrder.NAME_A_Z -> result.sortedWith(compareBy(String.CASE_INSENSITIVE_ORDER) { it.name })
            VideoSortOrder.NAME_Z_A -> result.sortedWith(compareByDescending(String.CASE_INSENSITIVE_ORDER) { it.name })
            VideoSortOrder.SIZE_LARGEST -> result.sortedByDescending { it.totalSize }
            VideoSortOrder.SIZE_SMALLEST -> result.sortedBy { it.totalSize }
            VideoSortOrder.DURATION_LONGEST -> result.sortedByDescending { folder -> folder.videos.maxOfOrNull { it.duration } ?: 0L }
            VideoSortOrder.DURATION_SHORTEST -> result.sortedBy { folder -> folder.videos.minOfOrNull { it.duration } ?: 0L }
        }

        result
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private var scanJob: kotlinx.coroutines.Job? = null

    private val contentObserver = object : ContentObserver(Handler(Looper.getMainLooper())) {
        override fun onChange(selfChange: Boolean) {
            super.onChange(selfChange)
            scanVideos()
        }
    }

    init {
        // Load Sort and Filter preferences from DataStore
        viewModelScope.launch {
            try {
                application.dataStore.data.collect { preferences ->
                    val savedSort = preferences[SORT_ORDER_KEY]
                    if (savedSort != null) {
                        try {
                            _sortOrder.value = VideoSortOrder.valueOf(savedSort)
                        } catch (e: Exception) {
                            // ignore
                        }
                    }
                    val savedFilter = preferences[FILTER_TYPE_KEY]
                    if (savedFilter != null) {
                        try {
                            _filterType.value = VideoFilterType.valueOf(savedFilter)
                        } catch (e: Exception) {
                            // ignore
                        }
                    }
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }

        try {
            application.contentResolver.registerContentObserver(
                MediaStore.Video.Media.EXTERNAL_CONTENT_URI,
                true,
                contentObserver
            )
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    override fun onCleared() {
        super.onCleared()
        try {
            getApplication<Application>().contentResolver.unregisterContentObserver(contentObserver)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun scanVideos() {
        scanJob?.cancel()
        scanJob = viewModelScope.launch {
            _isScanning.value = true
            try {
                val videos = repository.scanVideos()
                _scannedVideos.value = videos
                _scannedFolders.value = groupVideosIntoFolders(videos)
            } catch (e: Exception) {
                e.printStackTrace()
            } finally {
                _isScanning.value = false
            }
        }
    }

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun setSortOrder(order: VideoSortOrder) {
        _sortOrder.value = order
        viewModelScope.launch {
            try {
                getApplication<Application>().dataStore.edit { preferences ->
                    preferences[SORT_ORDER_KEY] = order.name
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    fun setFilterType(type: VideoFilterType) {
        _filterType.value = type
        viewModelScope.launch {
            try {
                getApplication<Application>().dataStore.edit { preferences ->
                    preferences[FILTER_TYPE_KEY] = type.name
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    private fun groupVideosIntoFolders(videos: List<ScannedVideo>): List<VideoFolder> {
        return videos.groupBy { video ->
            val file = File(video.path)
            val parentFile = file.parentFile
            parentFile?.absolutePath ?: "Unknown"
        }.map { (folderPath, folderVideos) ->
            val folderName = File(folderPath).name.ifEmpty { "Root" }
            val latestVideo = folderVideos.firstOrNull()
            val totalSize = folderVideos.sumOf { it.size }
            VideoFolder(
                path = folderPath,
                name = folderName,
                videoCount = folderVideos.size,
                totalSize = totalSize,
                latestVideoThumbnail = latestVideo?.thumbnailUrl,
                latestVideoDateAdded = latestVideo?.dateAdded ?: 0L,
                videos = folderVideos
            )
        }.sortedByDescending { it.latestVideoDateAdded }
    }

    companion object {
        fun formatSize(sizeInBytes: Long): String {
            if (sizeInBytes <= 0) return "0 B"
            val units = arrayOf("B", "KB", "MB", "GB", "TB")
            val digitGroups = (Math.log10(sizeInBytes.toDouble()) / Math.log10(1024.0)).toInt()
            return String.format("%.2f %s", sizeInBytes / Math.pow(1024.0, digitGroups.toDouble()), units[digitGroups])
        }

        fun ScannedVideo.toMediaEntity(): MediaEntity {
            return MediaEntity(
                id = "scanned_$id",
                title = title,
                url = uriString,
                duration = duration,
                artist = formatSize(size),
                thumbnailUrl = thumbnailUrl,
                category = "Movies"
            )
        }
    }
}

class MediaStoreViewModelFactory(
    private val application: Application,
    private val repository: MediaStoreRepository
) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(MediaStoreViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return MediaStoreViewModel(application, repository) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
