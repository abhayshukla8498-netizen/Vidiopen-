package com.example.ui.viewmodel

import android.app.Application
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.Uri
import android.provider.OpenableColumns
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.model.VaultEntity
import com.example.data.repository.MediaRepository
import com.example.utils.CryptoManager
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import timber.log.Timber
import java.io.File
import java.io.FileOutputStream
import java.security.MessageDigest
import java.util.UUID

class VaultViewModel(
    application: Application,
    private val repository: MediaRepository
) : AndroidViewModel(application) {

    private val context = application.applicationContext

    // Unlock Preferred Method: "PIN", "PATTERN", "PASSWORD"
    private val _unlockMethod = MutableStateFlow("PIN")
    val unlockMethod: StateFlow<String> = _unlockMethod.asStateFlow()

    // Unlock Status
    private val _isUnlocked = MutableStateFlow(false)
    val isUnlocked: StateFlow<Boolean> = _isUnlocked.asStateFlow()

    // KeyStore Hashed Credentials
    private val _vaultPinHash = MutableStateFlow<String?>(null)
    private val _vaultPatternHash = MutableStateFlow<String?>(null)
    private val _vaultPasswordHash = MutableStateFlow<String?>(null)

    // Public getters for credentials existence
    private val _hasPin = MutableStateFlow(false)
    val hasPin: StateFlow<Boolean> = _hasPin.asStateFlow()

    private val _hasPattern = MutableStateFlow(false)
    val hasPattern: StateFlow<Boolean> = _hasPattern.asStateFlow()

    private val _hasPassword = MutableStateFlow(false)
    val hasPassword: StateFlow<Boolean> = _hasPassword.asStateFlow()

    // Biometric Preferences
    private val _isBiometricEnabled = MutableStateFlow(false)
    val isBiometricEnabled: StateFlow<Boolean> = _isBiometricEnabled.asStateFlow()

    // Auto-Lock Timeout Preference (in seconds: 0 = immediate, 15, 30, 60, 300)
    private val _autoLockTimeout = MutableStateFlow(0)
    val autoLockTimeout: StateFlow<Int> = _autoLockTimeout.asStateFlow()

    // Active Section: "HOME", "VIDEOS", "PHOTOS", "AUDIO", "DOCUMENTS", "FAVORITES", "RECENT"
    private val _activeSection = MutableStateFlow("HOME")
    val activeSection: StateFlow<String> = _activeSection.asStateFlow()

    // Current playing/viewing decrypted temporary media
    private val _activeDecryptedFile = MutableStateFlow<File?>(null)
    val activeDecryptedFile: StateFlow<File?> = _activeDecryptedFile.asStateFlow()

    private val _activeDecryptedItem = MutableStateFlow<VaultEntity?>(null)
    val activeDecryptedItem: StateFlow<VaultEntity?> = _activeDecryptedItem.asStateFlow()

    // All items from local Room Database
    val vaultItems: StateFlow<List<VaultEntity>> = repository.vaultItems
        .stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

    // Filtered lists for Vault Home Sections
    val videos: StateFlow<List<VaultEntity>> = combine(vaultItems) { items ->
        items[0].filter { it.type == "VIDEO" }
    }.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    val photos: StateFlow<List<VaultEntity>> = combine(vaultItems) { items ->
        items[0].filter { it.type == "PHOTO" }
    }.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    val audio: StateFlow<List<VaultEntity>> = combine(vaultItems) { items ->
        items[0].filter { it.type == "AUDIO" }
    }.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    val documents: StateFlow<List<VaultEntity>> = combine(vaultItems) { items ->
        items[0].filter { it.type == "DOCUMENT" }
    }.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    val favorites: StateFlow<List<VaultEntity>> = combine(vaultItems) { items ->
        items[0].filter { it.isFavorite }
    }.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    val recentlyAdded: StateFlow<List<VaultEntity>> = combine(vaultItems) { items ->
        items[0].sortedByDescending { it.addedDate }.take(10)
    }.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    // Tracks background/foreground times for timeout lock
    private var backgroundTimestamp: Long = 0L

    // Screen-off BroadcastReceiver
    private val screenOffReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent?.action == Intent.ACTION_SCREEN_OFF) {
                Timber.d("VaultViewModel: Screen off detected, locking vault.")
                lock()
            }
        }
    }

    init {
        loadSettings()
        registerScreenOffReceiver()
    }

    private fun loadSettings() {
        viewModelScope.launch {
            _unlockMethod.value = repository.getConfig("vault_unlock_method") ?: "PIN"
            _vaultPinHash.value = repository.getConfig("vault_pin_hash")
            _vaultPatternHash.value = repository.getConfig("vault_pattern_hash")
            _vaultPasswordHash.value = repository.getConfig("vault_password_hash")
            _isBiometricEnabled.value = (repository.getConfig("vault_biometric_enabled") ?: "false").toBoolean()
            _autoLockTimeout.value = (repository.getConfig("vault_auto_lock_timeout") ?: "0").toInt()

            _hasPin.value = !_vaultPinHash.value.isNullOrEmpty()
            _hasPattern.value = !_vaultPatternHash.value.isNullOrEmpty()
            _hasPassword.value = !_vaultPasswordHash.value.isNullOrEmpty()

            Timber.d("VaultViewModel: Loaded secure settings. Method: %s, Biometric: %s, Timeout: %d", 
                _unlockMethod.value, _isBiometricEnabled.value, _autoLockTimeout.value)
        }
    }

    private fun registerScreenOffReceiver() {
        try {
            val filter = IntentFilter(Intent.ACTION_SCREEN_OFF)
            context.registerReceiver(screenOffReceiver, filter)
        } catch (e: Exception) {
            Timber.e(e, "VaultViewModel: Failed to register screen off receiver")
        }
    }

    override fun onCleared() {
        super.onCleared()
        try {
            context.unregisterReceiver(screenOffReceiver)
        } catch (e: Exception) {
            // Already unregistered
        }
        cleanUpDecryptedTempFiles()
    }

    // --- Preferred Method Actions ---
    fun setUnlockMethod(method: String) {
        viewModelScope.launch {
            repository.setConfig("vault_unlock_method", method)
            _unlockMethod.value = method
        }
    }

    fun setBiometricEnabled(enabled: Boolean) {
        viewModelScope.launch {
            repository.setConfig("vault_biometric_enabled", enabled.toString())
            _isBiometricEnabled.value = enabled
        }
    }

    fun setAutoLockTimeout(timeoutSeconds: Int) {
        viewModelScope.launch {
            repository.setConfig("vault_auto_lock_timeout", timeoutSeconds.toString())
            _autoLockTimeout.value = timeoutSeconds
        }
    }

    // --- Hash Helper (SHA-256 for credentials verification) ---
    private fun hashCredential(value: String): String {
        return try {
            val digest = MessageDigest.getInstance("SHA-256")
            val hash = digest.digest(value.toByteArray(Charsets.UTF_8))
            hash.joinToString("") { "%02x".format(it) }
        } catch (e: Exception) {
            Timber.e(e, "VaultViewModel: SHA-256 hashing failed")
            value // Fallback (should never happen)
        }
    }

    fun savePin(pin: String) {
        viewModelScope.launch {
            val hashed = hashCredential(pin)
            repository.setConfig("vault_pin_hash", hashed)
            _vaultPinHash.value = hashed
            _hasPin.value = true
            _isUnlocked.value = true
        }
    }

    fun savePattern(pattern: String) {
        viewModelScope.launch {
            val hashed = hashCredential(pattern)
            repository.setConfig("vault_pattern_hash", hashed)
            _vaultPatternHash.value = hashed
            _hasPattern.value = true
            _isUnlocked.value = true
        }
    }

    fun savePassword(password: String) {
        viewModelScope.launch {
            val hashed = hashCredential(password)
            repository.setConfig("vault_password_hash", hashed)
            _vaultPasswordHash.value = hashed
            _hasPassword.value = true
            _isUnlocked.value = true
        }
    }

    fun resetPin() {
        viewModelScope.launch {
            repository.setConfig("vault_pin_hash", "")
            _vaultPinHash.value = ""
            _hasPin.value = false
            _isUnlocked.value = false
        }
    }

    // --- Credentials Verification ---
    fun verifyUnlock(attempt: String): Boolean {
        val expectedHash = when (_unlockMethod.value) {
            "PIN" -> _vaultPinHash.value
            "PATTERN" -> _vaultPatternHash.value
            "PASSWORD" -> _vaultPasswordHash.value
            else -> null
        }
        val attemptHash = hashCredential(attempt)
        val matches = expectedHash != null && expectedHash == attemptHash
        if (matches) {
            _isUnlocked.value = true
            Timber.d("VaultViewModel: Unlock verification succeeded using %s", _unlockMethod.value)
        } else {
            Timber.d("VaultViewModel: Unlock verification failed")
        }
        return matches
    }

    fun verifyBiometricSuccess() {
        _isUnlocked.value = true
        Timber.d("VaultViewModel: Unlock verification succeeded via Biometrics")
    }

    // --- Lock and Auto-Lock LifeCycle Hooks ---
    fun lock() {
        _isUnlocked.value = false
        _activeDecryptedFile.value = null
        _activeDecryptedItem.value = null
        cleanUpDecryptedTempFiles()
        Timber.d("VaultViewModel: Vault has been locked.")
    }

    fun unlockDirectly() {
        _isUnlocked.value = true
    }

    fun onAppGoToBackground() {
        backgroundTimestamp = System.currentTimeMillis()
        if (_autoLockTimeout.value == 0) {
            Timber.d("VaultViewModel: App going to background with immediate lock timeout.")
            lock()
        }
    }

    fun onAppReturnToForeground() {
        if (!_isUnlocked.value) return // Already locked, nothing to do
        val elapsedSeconds = (System.currentTimeMillis() - backgroundTimestamp) / 1000
        if (_autoLockTimeout.value > 0 && elapsedSeconds >= _autoLockTimeout.value) {
            Timber.d("VaultViewModel: Background timeout of %d seconds exceeded (%d seconds elapsed). Locking vault.", 
                _autoLockTimeout.value, elapsedSeconds)
            lock()
        }
    }

    // --- Section Nav ---
    fun setActiveSection(section: String) {
        _activeSection.value = section
    }

    // --- Encryption / Decryption Vault File Imports ---
    fun importFileFromUri(
        uri: Uri,
        type: String, // "VIDEO", "PHOTO", "AUDIO", "DOCUMENT"
        customTitle: String? = null,
        onKeepOriginalChecked: (File) -> Unit, // Callback to confirm delete original
        onError: (String) -> Unit
    ) {
        viewModelScope.launch {
            try {
                val contentResolver = context.contentResolver
                var fileName = "imported_file_${System.currentTimeMillis()}"
                var fileSize = 0L

                // Retrieve file metadata
                contentResolver.query(uri, null, null, null, null)?.use { cursor ->
                    if (cursor.moveToFirst()) {
                        val nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                        val sizeIndex = cursor.getColumnIndex(OpenableColumns.SIZE)
                        if (nameIndex != -1) fileName = cursor.getString(nameIndex)
                        if (sizeIndex != -1) fileSize = cursor.getLong(sizeIndex)
                    }
                }

                val finalTitle = customTitle ?: fileName

                // Copy input stream to a temp file first
                val tempSourceFile = File(context.cacheDir, "temp_import_${UUID.randomUUID()}")
                contentResolver.openInputStream(uri)?.use { inputStream ->
                    FileOutputStream(tempSourceFile).use { outputStream ->
                        inputStream.copyTo(outputStream)
                    }
                }

                if (!tempSourceFile.exists() || tempSourceFile.length() == 0L) {
                    onError("Failed to read selected file contents.")
                    return@launch
                }

                if (fileSize == 0L) {
                    fileSize = tempSourceFile.length()
                }

                // Destination secure file in vault folder
                val vaultDir = File(context.filesDir, "nova_vault")
                if (!vaultDir.exists()) vaultDir.mkdirs()

                val secureFileName = "enc_${UUID.randomUUID()}"
                val secureDestFile = File(vaultDir, secureFileName)

                // Encrypt Keystore AES-GCM
                val success = CryptoManager.encryptFile(tempSourceFile, secureDestFile)
                if (success) {
                    val newItem = VaultEntity(
                        title = finalTitle,
                        path = secureDestFile.absolutePath,
                        type = type,
                        size = fileSize,
                        isFavorite = false,
                        addedDate = System.currentTimeMillis()
                    )
                    repository.insertVaultItem(newItem)

                    // Callback containing the original source temporary file so caller can handle user decision
                    onKeepOriginalChecked(tempSourceFile)
                    Timber.d("VaultViewModel: Successfully imported %s securely to %s", fileName, secureDestFile.absolutePath)
                } else {
                    tempSourceFile.delete()
                    onError("Failed to encrypt and secure file.")
                }
            } catch (e: Exception) {
                Timber.e(e, "VaultViewModel: File import failed")
                onError(e.localizedMessage ?: "Unknown file import error.")
            }
        }
    }

    // --- Play / View directly inside Vault ---
    fun selectItemForPlaybackOrView(item: VaultEntity, onError: (String) -> Unit) {
        viewModelScope.launch {
            try {
                cleanUpDecryptedTempFiles()

                val encryptedFile = File(item.path)
                if (!encryptedFile.exists()) {
                    onError("Encrypted vault source file not found.")
                    return@launch
                }

                val playDir = File(context.cacheDir, "temp_vault_play")
                if (!playDir.exists()) playDir.mkdirs()

                // Create a secure temporary file in app's cache (e.g., with original extension)
                val ext = item.title.substringAfterLast(".", "")
                val tempPlayFileName = "play_${UUID.randomUUID()}" + if (ext.isNotEmpty()) ".$ext" else ""
                val tempPlayFile = File(playDir, tempPlayFileName)

                // Decrypt
                val success = CryptoManager.decryptFile(encryptedFile, tempPlayFile)
                if (success) {
                    _activeDecryptedFile.value = tempPlayFile
                    _activeDecryptedItem.value = item
                    Timber.d("VaultViewModel: Decrypted item for immediate play/view: %s", tempPlayFile.absolutePath)
                } else {
                    onError("Failed to decrypt and process vault file.")
                }
            } catch (e: Exception) {
                Timber.e(e, "VaultViewModel: Playback preparation failed")
                onError(e.localizedMessage ?: "Unknown decryption error.")
            }
        }
    }

    fun dismissActiveViewer() {
        _activeDecryptedFile.value = null
        _activeDecryptedItem.value = null
        cleanUpDecryptedTempFiles()
    }

    private fun cleanUpDecryptedTempFiles() {
        try {
            val playDir = File(context.cacheDir, "temp_vault_play")
            if (playDir.exists()) {
                playDir.listFiles()?.forEach { file ->
                    file.delete()
                }
            }
        } catch (e: Exception) {
            Timber.e(e, "VaultViewModel: Failed to clean up temp decrypted cache")
        }
    }

    // --- Toggle Favorite ---
    fun toggleVaultFavorite(item: VaultEntity) {
        viewModelScope.launch {
            repository.toggleVaultFavorite(item.id, !item.isFavorite)
        }
    }

    // --- Delete Vault Item ---
    fun deleteVaultItem(item: VaultEntity) {
        viewModelScope.launch {
            try {
                val file = File(item.path)
                if (file.exists()) {
                    file.delete()
                }
                repository.deleteVaultItem(item.id)
                Timber.d("VaultViewModel: Deleted vault item and its encrypted file: %s", item.title)
            } catch (e: Exception) {
                Timber.e(e, "VaultViewModel: Failed to delete vault item %s", item.title)
            }
        }
    }

    // --- Export Vault Item back to public storage / standard cache ---
    fun exportVaultItem(item: VaultEntity, exportDir: File, onSuccess: (String) -> Unit, onError: (String) -> Unit) {
        viewModelScope.launch {
            try {
                if (!exportDir.exists()) exportDir.mkdirs()
                val destFile = File(exportDir, item.title)
                val sourceFile = File(item.path)

                val success = CryptoManager.decryptFile(sourceFile, destFile)
                if (success) {
                    onSuccess("Successfully exported to: ${destFile.absolutePath}")
                    Timber.d("VaultViewModel: Successfully decrypted and exported %s", destFile.absolutePath)
                } else {
                    onError("Failed to decrypt and export file.")
                }
            } catch (e: Exception) {
                Timber.e(e, "VaultViewModel: Export failed")
                onError(e.localizedMessage ?: "Unknown export error.")
            }
        }
    }
}

class VaultViewModelFactory(
    private val application: Application,
    private val repository: MediaRepository
) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(VaultViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return VaultViewModel(application, repository) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
