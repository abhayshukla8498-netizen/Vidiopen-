package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.model.ScannedSong
import com.example.data.repository.MusicRepository
import com.example.data.repository.MusicThemeRepository
import com.example.player.MusicPlayerManager
import com.example.player.PlayerState
import com.example.ui.theme.MusicTheme
import com.example.ui.theme.MusicThemeRegistry
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.launch
import java.io.File

class MusicViewModel(
    application: Application,
    private val musicRepository: MusicRepository,
    private val musicPlayerManager: MusicPlayerManager,
    private val musicThemeRepository: MusicThemeRepository
) : AndroidViewModel(application) {

    // Themes logic
    val selectedThemeId: StateFlow<String> = musicThemeRepository.selectedThemeId
        .stateIn(viewModelScope, SharingStarted.Eagerly, "nova_black")

    val customThemeImageUri: StateFlow<String?> = musicThemeRepository.customThemeImageUri
        .stateIn(viewModelScope, SharingStarted.Eagerly, null)

    val currentTheme: StateFlow<MusicTheme> = combine(
        selectedThemeId,
        customThemeImageUri
    ) { themeId, imageUri ->
        MusicThemeRegistry.getThemeById(themeId, imageUri)
    }.stateIn(viewModelScope, SharingStarted.Eagerly, MusicThemeRegistry.BuiltInThemes.first())

    fun selectTheme(themeId: String) {
        viewModelScope.launch {
            musicThemeRepository.saveSelectedThemeId(themeId)
        }
    }

    fun setCustomThemeImage(uriString: String?) {
        viewModelScope.launch {
            musicThemeRepository.saveCustomThemeImageUri(uriString)
            if (uriString != null) {
                musicThemeRepository.saveSelectedThemeId("custom_image")
            } else {
                musicThemeRepository.saveSelectedThemeId("nova_black")
            }
        }
    }

    private val _isScanning = MutableStateFlow(false)
    val isScanning: StateFlow<Boolean> = _isScanning

    private val _songs = MutableStateFlow<List<ScannedSong>>(emptyList())
    val songs: StateFlow<List<ScannedSong>> = _songs

    // Playback state flows delegated from MusicPlayerManager
    val currentPlayingSong: StateFlow<ScannedSong?> = musicPlayerManager.currentPlayingSong
    val isPlaying: StateFlow<Boolean> = musicPlayerManager.isPlaying
    val playerState: StateFlow<PlayerState> = musicPlayerManager.playerState
    val currentPosition: StateFlow<Long> = musicPlayerManager.currentPosition
    val duration: StateFlow<Long> = musicPlayerManager.duration
    val queue: StateFlow<List<ScannedSong>> = musicPlayerManager.queue
    val repeatMode: StateFlow<Int> = musicPlayerManager.repeatMode
    val shuffleModeEnabled: StateFlow<Boolean> = musicPlayerManager.shuffleModeEnabled
    val playbackSpeed: StateFlow<Float> = musicPlayerManager.playbackSpeed

    // Premium Audio Effects and Equalizer states
    val eqEnabled = MutableStateFlow(musicPlayerManager.audioEffectsManager.eqEnabled)
    val selectedPreset = MutableStateFlow(musicPlayerManager.audioEffectsManager.selectedPreset)
    val eqBands = MutableStateFlow(musicPlayerManager.audioEffectsManager.eqBands.clone())

    val bassBoostEnabled = MutableStateFlow(musicPlayerManager.audioEffectsManager.bassBoostEnabled)
    val bassBoostStrength = MutableStateFlow(musicPlayerManager.audioEffectsManager.bassBoostStrength)

    val virtualizerEnabled = MutableStateFlow(musicPlayerManager.audioEffectsManager.virtualizerEnabled)
    val virtualizerStrength = MutableStateFlow(musicPlayerManager.audioEffectsManager.virtualizerStrength)

    val loudnessEnabled = MutableStateFlow(musicPlayerManager.audioEffectsManager.loudnessEnabled)
    val loudnessGain = MutableStateFlow(musicPlayerManager.audioEffectsManager.loudnessGain)

    val balance = MutableStateFlow(musicPlayerManager.getBalance())

    // Premium Sleep Timer and Fading states
    val sleepTimerRemaining = musicPlayerManager.sleepTimerRemaining
    val sleepTimerMode = musicPlayerManager.sleepTimerMode

    val fadeInEnabled = musicPlayerManager.fadeInEnabled
    val fadeInDurationMs = musicPlayerManager.fadeInDurationMs
    val fadeOutEnabled = musicPlayerManager.fadeOutEnabled
    val fadeOutDurationMs = musicPlayerManager.fadeOutDurationMs

    // Categories
    val allSongs: StateFlow<List<ScannedSong>> = _songs

    val albums: StateFlow<List<AlbumItem>> = _songs.map { songList ->
        songList.groupBy { it.album ?: "Unknown Album" }
            .map { (albumName, songs) ->
                AlbumItem(
                    name = albumName,
                    artist = songs.firstOrNull()?.artist ?: "Unknown Artist",
                    artworkUri = songs.firstOrNull()?.artworkUri,
                    songs = songs,
                    totalSize = songs.sumOf { it.size },
                    totalDuration = songs.sumOf { it.duration }
                )
            }.sortedBy { it.name }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val artists: StateFlow<List<ArtistItem>> = _songs.map { songList ->
        songList.groupBy { it.artist ?: "Unknown Artist" }
            .map { (artistName, songs) ->
                ArtistItem(
                    name = artistName,
                    songs = songs,
                    totalSize = songs.sumOf { it.size },
                    totalDuration = songs.sumOf { it.duration },
                    artworkUri = songs.firstOrNull()?.artworkUri
                )
            }.sortedBy { it.name }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val folders: StateFlow<List<FolderItem>> = _songs.map { songList ->
        songList.groupBy { 
            val file = File(it.path)
            file.parentFile?.absolutePath ?: "Unknown"
        }.map { (folderPath, songs) ->
            FolderItem(
                name = File(folderPath).name,
                path = folderPath,
                songs = songs,
                totalSize = songs.sumOf { it.size },
                totalDuration = songs.sumOf { it.duration }
            )
        }.sortedBy { it.name }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val recentlyAdded: StateFlow<List<ScannedSong>> = _songs.map { songList ->
        songList.sortedByDescending { it.dateAdded }.take(50)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    init {
        scanMusicFiles()
    }

    fun scanMusicFiles() {
        viewModelScope.launch {
            _isScanning.value = true
            try {
                val scanned = musicRepository.scanAudio()
                _songs.value = scanned
                musicPlayerManager.syncScannedSongs(scanned)
            } catch (e: Exception) {
                e.printStackTrace()
            } finally {
                _isScanning.value = false
            }
        }
    }

    // Playback Control Delegates
    fun playSong(song: ScannedSong, contextList: List<ScannedSong>) {
        musicPlayerManager.playSong(song, contextList)
    }

    fun play() = musicPlayerManager.play()
    fun pause() = musicPlayerManager.pause()
    fun next() = musicPlayerManager.next()
    fun previous() = musicPlayerManager.previous()
    fun stop() = musicPlayerManager.stop()
    fun seekTo(positionMs: Long) = musicPlayerManager.seekTo(positionMs)
    fun fastSeekForward() = musicPlayerManager.fastSeekForward()
    fun fastSeekBackward() = musicPlayerManager.fastSeekBackward()
    fun replay() = musicPlayerManager.replay()

    // Queue Control Delegates
    fun playNext(song: ScannedSong) = musicPlayerManager.playNext(song)
    fun addToQueue(song: ScannedSong) = musicPlayerManager.addToQueue(song)
    fun removeFromQueue(songId: Long) = musicPlayerManager.removeFromQueue(songId)
    fun clearQueue() = musicPlayerManager.clearQueue()
    fun reorderQueue(fromIndex: Int, toIndex: Int) = musicPlayerManager.reorderQueue(fromIndex, toIndex)

    // Play Mode Delegates
    fun setRepeatMode(mode: Int) = musicPlayerManager.setRepeatMode(mode)
    fun setShuffleMode(enabled: Boolean) = musicPlayerManager.setShuffleMode(enabled)
    fun setPlaybackSpeed(speed: Float) = musicPlayerManager.setPlaybackSpeed(speed)

    // Premium Equalizer and Audio Effects Actions
    fun setEqEnabled(enabled: Boolean) {
        musicPlayerManager.audioEffectsManager.eqEnabled = enabled
        eqEnabled.value = enabled
    }

    fun setEqBand(bandIndex: Int, gainDb: Int) {
        musicPlayerManager.audioEffectsManager.setEqBand(bandIndex, gainDb)
        eqBands.value = musicPlayerManager.audioEffectsManager.eqBands.clone()
    }

    fun selectPreset(presetName: String) {
        musicPlayerManager.audioEffectsManager.selectedPreset = presetName
        selectedPreset.value = presetName
        eqBands.value = musicPlayerManager.audioEffectsManager.eqBands.clone()
    }

    fun saveCustomPreset(name: String, bands: IntArray) {
        musicPlayerManager.audioEffectsManager.saveCustomPreset(name, bands)
    }

    fun getCustomPresetNames(): Set<String> {
        return musicPlayerManager.audioEffectsManager.getCustomPresetNames()
    }

    fun deleteCustomPreset(name: String) {
        musicPlayerManager.audioEffectsManager.deleteCustomPreset(name)
    }

    fun setBassBoostEnabled(enabled: Boolean) {
        musicPlayerManager.audioEffectsManager.bassBoostEnabled = enabled
        bassBoostEnabled.value = enabled
    }

    fun setBassBoostStrength(strength: Int) {
        musicPlayerManager.audioEffectsManager.bassBoostStrength = strength
        bassBoostStrength.value = strength
    }

    fun setVirtualizerEnabled(enabled: Boolean) {
        musicPlayerManager.audioEffectsManager.virtualizerEnabled = enabled
        virtualizerEnabled.value = enabled
    }

    fun setVirtualizerStrength(strength: Int) {
        musicPlayerManager.audioEffectsManager.virtualizerStrength = strength
        virtualizerStrength.value = strength
    }

    fun setLoudnessEnabled(enabled: Boolean) {
        musicPlayerManager.audioEffectsManager.loudnessEnabled = enabled
        loudnessEnabled.value = enabled
    }

    fun setLoudnessGain(gainDb: Float) {
        musicPlayerManager.audioEffectsManager.loudnessGain = gainDb
        loudnessGain.value = gainDb
    }

    fun setBalance(bal: Float) {
        musicPlayerManager.setBalance(bal)
        balance.value = bal
    }

    fun setSleepTimer(minutes: Int?) {
        musicPlayerManager.setSleepTimer(minutes)
    }

    fun setSleepTimerEndOfSong() {
        musicPlayerManager.setSleepTimerEndOfSong()
    }

    fun setFadeInEnabled(enabled: Boolean) {
        musicPlayerManager.setFadeInEnabled(enabled)
    }

    fun setFadeInDuration(ms: Long) {
        musicPlayerManager.setFadeInDuration(ms)
    }

    fun setFadeOutEnabled(enabled: Boolean) {
        musicPlayerManager.setFadeOutEnabled(enabled)
    }

    fun setFadeOutDuration(ms: Long) {
        musicPlayerManager.setFadeOutDuration(ms)
    }
}

// Grouping classes representing nested structures
data class AlbumItem(
    val name: String,
    val artist: String,
    val artworkUri: String?,
    val songs: List<ScannedSong>,
    val totalSize: Long,
    val totalDuration: Long
)

data class ArtistItem(
    val name: String,
    val songs: List<ScannedSong>,
    val totalSize: Long,
    val totalDuration: Long,
    val artworkUri: String? = null
)

data class FolderItem(
    val name: String,
    val path: String,
    val songs: List<ScannedSong>,
    val totalSize: Long,
    val totalDuration: Long
)

class MusicViewModelFactory(
    private val application: Application,
    private val musicRepository: MusicRepository,
    private val musicPlayerManager: MusicPlayerManager,
    private val musicThemeRepository: MusicThemeRepository
) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(MusicViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return MusicViewModel(application, musicRepository, musicPlayerManager, musicThemeRepository) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
