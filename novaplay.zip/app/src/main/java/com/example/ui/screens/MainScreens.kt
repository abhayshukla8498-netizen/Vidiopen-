package com.example.ui.screens

import com.example.AppThemeBackground
import android.text.format.Formatter
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import android.content.Intent
import android.net.Uri
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.foundation.text.selection.SelectionContainer
import com.example.data.model.MediaEntity
import com.example.data.model.VaultEntity
import com.example.data.model.ScannedSong
import com.example.ui.viewmodel.MusicViewModel
import com.example.ui.viewmodel.AlbumItem
import com.example.ui.viewmodel.ArtistItem
import com.example.ui.viewmodel.FolderItem
import com.example.ui.components.*
import com.example.ui.viewmodel.MediaViewModel
import com.example.ui.viewmodel.MediaConversionState
import com.example.ui.viewmodel.VaultViewModel
import com.example.ui.viewmodel.VaultViewModelFactory
import androidx.compose.ui.graphics.asImageBitmap
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.biometric.BiometricPrompt
import androidx.biometric.BiometricManager
import android.content.Context
import android.content.ContextWrapper
import androidx.fragment.app.FragmentActivity
import timber.log.Timber

import com.example.ui.viewmodel.MediaStoreViewModel
import com.example.ui.viewmodel.MediaStoreViewModel.Companion.toMediaEntity
import com.example.ui.viewmodel.StorageViewModel
import com.example.ui.viewmodel.StorageStats
import com.example.ui.viewmodel.StorageInsights
import com.example.ui.viewmodel.DuplicateGroup
import com.example.ui.viewmodel.DeletionItem
import com.example.ui.viewmodel.DeletionItem.*
import com.example.data.model.ScannedVideo
import java.io.File
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import android.content.pm.PackageManager
import android.os.Build
import android.widget.Toast
import coil.compose.AsyncImage
import com.example.ui.theme.ElectricBlue
import com.example.ui.theme.RoyalPurple
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.GlassWhiteBorder
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.ui.graphics.SolidColor
import com.example.ui.viewmodel.VideoSortOrder
import com.example.ui.viewmodel.VideoFilterType
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.automirrored.rounded.Sort

import androidx.compose.material.icons.rounded.Wifi
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.ui.geometry.center
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.draw.scale
import androidx.compose.foundation.Canvas

// ==========================================
// HOME SCREEN
// ==========================================
@Composable
fun NovaPlayLogo(modifier: Modifier = Modifier) {
    val infiniteTransition = rememberInfiniteTransition(label = "NovaPlayLogoTransition")
    
    val scale by infiniteTransition.animateFloat(
        initialValue = 0.95f,
        targetValue = 1.05f,
        animationSpec = infiniteRepeatable(
            animation = tween(1600, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "LogoPulse"
    )

    com.example.ui.components.AppLogo(
        modifier = modifier
            .scale(scale)
            .size(36.dp)
    )
}

@Composable
fun HeroFeaturedBanner(
    viewModel: MediaViewModel,
    mediaList: List<MediaEntity>,
    onPlayVideo: (MediaEntity) -> Unit,
    onAddCustomVideo: () -> Unit
) {
    val featuredItem = remember(mediaList) {
        mediaList.firstOrNull { it.category != "Music" } ?: mediaList.firstOrNull()
    }

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(180.dp)
            .clip(RoundedCornerShape(24.dp))
            .background(
                Brush.verticalGradient(
                    colors = listOf(
                        Color(0xFF0F0C20),
                        Color(0xFF030206)
                    )
                )
            )
            .border(
                1.dp,
                Brush.linearGradient(
                    colors = listOf(
                        Color.White.copy(alpha = 0.15f),
                        com.example.ui.theme.ElectricBlue.copy(alpha = 0.3f),
                        com.example.ui.theme.RoyalPurple.copy(alpha = 0.15f)
                    )
                ),
                RoundedCornerShape(24.dp)
            )
    ) {
        // Glowing ambient lighting behind content
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.radialGradient(
                        colors = listOf(
                            com.example.ui.theme.ElectricBlue.copy(alpha = 0.12f),
                            Color.Transparent
                        ),
                        radius = 300f
                    )
                )
        )

        Row(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Icon / Illustration side
            Box(
                modifier = Modifier
                    .size(90.dp)
                    .clip(RoundedCornerShape(16.dp))
                    .background(
                        Brush.linearGradient(
                            colors = listOf(
                                com.example.ui.theme.RoyalPurple.copy(alpha = 0.6f),
                                com.example.ui.theme.ElectricBlue.copy(alpha = 0.2f)
                            )
                        )
                    ),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = if (featuredItem?.category == "Music") Icons.Rounded.MusicNote else Icons.Rounded.PlayArrow,
                    contentDescription = null,
                    tint = Color.White,
                    modifier = Modifier.size(40.dp)
                )
            }

            Spacer(modifier = Modifier.width(16.dp))

            // Text info & Play CTA side
            Column(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.Center
            ) {
                // Hot Tag badge
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .background(Color(0xFFFF2E93).copy(alpha = 0.15f), RoundedCornerShape(6.dp))
                            .border(0.5.dp, Color(0xFFFF2E93).copy(alpha = 0.35f), RoundedCornerShape(6.dp))
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = if (featuredItem != null) "NOW TRENDING" else "AMOLED CINEMA",
                            color = Color(0xFFFF2E93),
                            fontSize = 8.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 0.5.sp
                        )
                    }

                    Box(
                        modifier = Modifier
                            .background(com.example.ui.theme.ElectricBlue.copy(alpha = 0.15f), RoundedCornerShape(6.dp))
                            .border(0.5.dp, com.example.ui.theme.ElectricBlue.copy(alpha = 0.35f), RoundedCornerShape(6.dp))
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = "ULTRA HD",
                            color = com.example.ui.theme.ElectricBlue,
                            fontSize = 8.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 0.5.sp
                        )
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Title
                Text(
                    text = featuredItem?.title ?: "Vidiopen Cinema Master",
                    color = Color.White,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Black,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )

                Spacer(modifier = Modifier.height(2.dp))

                // Subtitle description / specs
                Text(
                    text = if (featuredItem != null) {
                        "${featuredItem.artist ?: "Cinematic Media"} • ${featuredItem.category ?: "Video"}"
                    } else {
                        "Pure 60FPS offline hardware accelerated player"
                    },
                    color = Color.Gray,
                    fontSize = 11.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )

                Spacer(modifier = Modifier.height(12.dp))

                // Action Button Row
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .clip(RoundedCornerShape(10.dp))
                        .background(com.example.ui.theme.ElectricBlue)
                        .clickable {
                            if (featuredItem != null) {
                                onPlayVideo(featuredItem)
                            } else {
                                onAddCustomVideo()
                            }
                        }
                        .padding(horizontal = 14.dp, vertical = 6.dp)
                ) {
                    Icon(
                        imageVector = Icons.Rounded.PlayArrow,
                        contentDescription = null,
                        tint = Color.Black,
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = if (featuredItem != null) "PLAY NOW" else "ADD CUSTOM STREAM",
                        color = Color.Black,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 0.5.sp
                    )
                }
            }
        }
    }
}

@Composable
fun HomeScreen(
    viewModel: MediaViewModel,
    smartCollectionsViewModel: com.example.ui.viewmodel.SmartCollectionsViewModel,
    onNavigateToSection: (String) -> Unit,
    onPlayVideo: (MediaEntity) -> Unit,
    onOpenVault: () -> Unit,
    onAddCustomVideo: () -> Unit
) {
    val context = LocalContext.current
    val searchQuery by viewModel.searchQuery.collectAsState()
    val mediaList by viewModel.filteredMedia.collectAsState()
    val continueList by viewModel.continueWatching.collectAsState()

    // Categorized items
    val movies = remember(mediaList) { mediaList.filter { it.category == "Movies" } }
    val tvShows = remember(mediaList) { mediaList.filter { it.category == "TV Shows" } }
    val music = remember(mediaList) { mediaList.filter { it.category == "Music" } }

    var showQuickAddDialog by remember { mutableStateOf(false) }
    var inputTitle by remember { mutableStateOf("") }
    var inputUrl by remember { mutableStateOf("") }

    if (showQuickAddDialog) {
        AlertDialog(
            onDismissRequest = { showQuickAddDialog = false },
            title = { Text("Stream Network Video", color = Color.White) },
            text = {
                Column {
                    OutlinedTextField(
                        value = inputTitle,
                        onValueChange = { inputTitle = it },
                        label = { Text("Video Title") },
                        colors = TextFieldDefaults.colors(
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White,
                            focusedContainerColor = Color.Transparent,
                            unfocusedContainerColor = Color.Transparent
                        ),
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    OutlinedTextField(
                        value = inputUrl,
                        onValueChange = { inputUrl = it },
                        label = { Text("Video URL (MP4 / HLS)") },
                        placeholder = { Text("https://example.com/video.mp4") },
                        colors = TextFieldDefaults.colors(
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White,
                            focusedContainerColor = Color.Transparent,
                            unfocusedContainerColor = Color.Transparent
                        ),
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        if (inputTitle.isNotBlank() && inputUrl.isNotBlank()) {
                            viewModel.addLocalVideo(inputTitle, inputUrl, 300000L)
                            showQuickAddDialog = false
                            inputTitle = ""
                            inputUrl = ""
                        }
                    }
                ) {
                    Text("ADD", color = ElectricBlue)
                }
            },
            dismissButton = {
                TextButton(onClick = { showQuickAddDialog = false }) {
                    Text("CANCEL", color = Color.Gray)
                }
            },
            containerColor = Color(0xFF1E1E1E)
        )
    }

    val customBgUri by viewModel.customBackgroundUri.collectAsState()

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Transparent)
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(bottom = 100.dp)
    ) {
        // Welcome Greeting
        item {
            Spacer(modifier = Modifier.height(60.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    NovaPlayLogo(modifier = Modifier.padding(end = 12.dp))
                    Column {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.Start
                        ) {
                            Text(
                                text = "Vidiopen",
                                fontSize = 32.sp,
                                fontWeight = FontWeight.Black,
                                color = Color.White,
                                modifier = Modifier.testTag("app_brand_title")
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Row(
                                modifier = Modifier
                                    .background(Color.White.copy(alpha = 0.08f), RoundedCornerShape(8.dp))
                                    .border(1.dp, Color.White.copy(alpha = 0.15f), RoundedCornerShape(8.dp))
                                    .padding(horizontal = 6.dp, vertical = 3.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("🇮🇳", fontSize = 10.sp)
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = "IND",
                                    color = Color.White,
                                    fontSize = 8.sp,
                                    fontWeight = FontWeight.Bold,
                                    letterSpacing = 0.5.sp
                                )
                            }
                        }
                        GlowText(
                            text = "AMOLED Media Engine",
                            fontSize = 14.sp,
                            color = ElectricBlue,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }
                IconButton(
                    onClick = { onOpenVault() },
                    modifier = Modifier
                        .background(Color.White.copy(alpha = 0.1f), CircleShape)
                        .testTag("private_vault_home_btn")
                ) {
                    Icon(
                        imageVector = Icons.Rounded.Lock,
                        contentDescription = "Private Vault",
                        tint = RoyalPurple
                    )
                }
            }
            Spacer(modifier = Modifier.height(24.dp))
        }

        // Search Bar
        item {
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { viewModel.setSearchQuery(it) },
                placeholder = { Text("Search trailers, shows, beats...", color = Color.Gray) },
                leadingIcon = { Icon(Icons.Rounded.Search, contentDescription = "Search", tint = ElectricBlue) },
                colors = TextFieldDefaults.colors(
                    focusedContainerColor = Color.White.copy(alpha = 0.05f),
                    unfocusedContainerColor = Color.White.copy(alpha = 0.05f),
                    focusedIndicatorColor = ElectricBlue,
                    unfocusedIndicatorColor = Color.White.copy(alpha = 0.1f),
                    focusedTextColor = Color.White,
                    unfocusedTextColor = Color.White
                ),
                shape = RoundedCornerShape(24.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("search_bar")
            )
            Spacer(modifier = Modifier.height(24.dp))
        }

        // Hero Featured Banner
        item {
            HeroFeaturedBanner(
                viewModel = viewModel,
                mediaList = mediaList,
                onPlayVideo = onPlayVideo,
                onAddCustomVideo = { showQuickAddDialog = true }
            )
            Spacer(modifier = Modifier.height(24.dp))
        }

        // Navigation Grid Shortcuts
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(24.dp)
            ) {
                ShortcutButton(title = "Movies", icon = Icons.Rounded.Movie, tint = Color(0xFFFF2E93), tag = "movies_shortcut") { onNavigateToSection("movies") }
                ShortcutButton(title = "TV Shows", icon = Icons.Rounded.Tv, tint = Color(0xFF00FFCC), tag = "tvshows_shortcut") { onNavigateToSection("tvshows") }
                ShortcutButton(title = "Music", icon = Icons.Rounded.MusicNote, tint = Color(0xFF00D9FF), tag = "music_shortcut") { onNavigateToSection("music") }
                ShortcutButton(title = "Privacy", icon = Icons.Rounded.Lock, tint = Color(0xFF7C4DFF), tag = "vault_shortcut") { onOpenVault() }
                ShortcutButton(title = "Transfer", icon = Icons.Rounded.Wifi, tint = Color(0xFFFF9800), tag = "transfer_shortcut") { onNavigateToSection("wifi_transfer") }
            }
            Spacer(modifier = Modifier.height(24.dp))
        }

        // Premium Smart Collections Section
        item {
            val collectionsList by smartCollectionsViewModel.smartCollections.collectAsState()
            
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Rounded.AutoAwesome,
                        contentDescription = null,
                        tint = ElectricBlue,
                        modifier = Modifier.size(20.dp)
                    )
                    Text("Smart Collections", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                }
                GlowText(text = "Automated", fontSize = 12.sp, color = ElectricBlue)
            }
            Spacer(modifier = Modifier.height(12.dp))
            
            if (collectionsList.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(140.dp)
                        .background(Color.White.copy(alpha = 0.03f), RoundedCornerShape(16.dp))
                        .border(1.dp, Color.White.copy(alpha = 0.08f), RoundedCornerShape(16.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    CircularProgressIndicator(color = ElectricBlue, modifier = Modifier.size(28.dp))
                }
            } else {
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(16.dp),
                    contentPadding = PaddingValues(end = 16.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    items(collectionsList) { col ->
                        if (col.videos.isNotEmpty()) {
                            SmartCollectionCard(collection = col) {
                                onNavigateToSection("collection/${col.id}")
                            }
                        }
                    }
                }
            }
            Spacer(modifier = Modifier.height(24.dp))
        }

        // Dynamic intelligence metrics
        item {
            DynamicHomeDashboard(
                smartCollectionsViewModel = smartCollectionsViewModel,
                mediaViewModel = viewModel,
                onNavigateToCollection = onNavigateToSection,
                onPlayVideo = onPlayVideo
            )
            Spacer(modifier = Modifier.height(24.dp))
        }

        // Continue Watching (If available)
        if (continueList.isNotEmpty()) {
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Continue Watching", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    GlowText(text = "Smart Resume", fontSize = 12.sp, color = ElectricBlue)
                }
                Spacer(modifier = Modifier.height(12.dp))
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(16.dp),
                    contentPadding = PaddingValues(end = 16.dp)
                ) {
                    items(continueList) { media ->
                        ContinueWatchingCard(media = media) { onPlayVideo(media) }
                    }
                }
                Spacer(modifier = Modifier.height(24.dp))
            }
        }

        // Storage Usage Card
        item {
            StorageAnalysisCompactCard { onNavigateToSection("files") }
            Spacer(modifier = Modifier.height(24.dp))
        }

        // Movies Segment
        item {
            SectionHeader(title = "Recent Movies & Trailers", icon = Icons.Rounded.Movie) { onNavigateToSection("movies") }
            Spacer(modifier = Modifier.height(12.dp))
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                items(movies) { item ->
                    MediaItemCard(item = item) { onPlayVideo(item) }
                }
            }
            Spacer(modifier = Modifier.height(24.dp))
        }

        // TV Shows Segment
        item {
            SectionHeader(title = "Featured TV Shows", icon = Icons.Rounded.Tv) { onNavigateToSection("tvshows") }
            Spacer(modifier = Modifier.height(12.dp))
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                items(tvShows) { item ->
                    MediaItemCard(item = item) { onPlayVideo(item) }
                }
            }
            Spacer(modifier = Modifier.height(24.dp))
        }

        // Music Tracks Segment
        item {
            SectionHeader(title = "Midnight Beats & Audio", icon = Icons.Rounded.MusicNote) { onNavigateToSection("music") }
            Spacer(modifier = Modifier.height(12.dp))
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                items(music) { item ->
                    MediaItemCard(item = item, isAudio = true) { viewModel.playMedia(item) }
                }
            }
            Spacer(modifier = Modifier.height(24.dp))
        }

        // Stream online CTA
        item {
            GlassCard(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { showQuickAddDialog = true }
                    .testTag("add_custom_url_card")
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column {
                        Text("Stream Custom Stream URL", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                        Text("Input custom M3U8 or MP4 feeds instantly", color = Color.Gray, fontSize = 12.sp)
                    }
                    Icon(Icons.Rounded.AddCircle, contentDescription = "Stream URL", tint = com.example.ui.theme.ElectricBlue, modifier = Modifier.size(32.dp))
                }
            }
            Spacer(modifier = Modifier.height(30.dp))
        }

        // Beautiful Persistent Footer
        item {
            Spacer(modifier = Modifier.height(24.dp))
            Column(
                modifier = Modifier.fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text("Vidiopen", color = Color.White.copy(alpha = 0.4f), fontWeight = FontWeight.Black, fontSize = 14.sp)
                    Text("•", color = Color.White.copy(alpha = 0.2f), fontSize = 14.sp)
                    Row(
                        modifier = Modifier
                            .background(Color.White.copy(alpha = 0.04f), RoundedCornerShape(6.dp))
                            .border(0.5.dp, Color.White.copy(alpha = 0.08f), RoundedCornerShape(6.dp))
                            .padding(horizontal = 6.dp, vertical = 2.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("🇮🇳", fontSize = 10.sp)
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("MADE IN INDIA", color = Color.White.copy(alpha = 0.4f), fontSize = 8.sp, fontWeight = FontWeight.Bold, letterSpacing = 0.5.sp)
                    }
                }
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "Professional Edition 1.0.0 • AMOLED Luxury Mode",
                    color = Color.White.copy(alpha = 0.2f),
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Medium
                )
            }
            Spacer(modifier = Modifier.height(50.dp))
        }
    }
}

@Composable
fun ShortcutButton(title: String, icon: ImageVector, tint: Color, tag: String, onClick: () -> Unit) {
    val interactionSource = remember { MutableInteractionSource() }
    val isPressed by interactionSource.collectIsPressedAsState()
    
    val scale by animateFloatAsState(
        targetValue = if (isPressed) 0.88f else 1.0f,
        animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessLow),
        label = "ShortcutButtonScale"
    )

    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .scale(scale)
            .clickable(
                interactionSource = interactionSource,
                indication = null, // Disable default gray box
                onClick = onClick
            )
            .testTag(tag)
    ) {
        Box(
            modifier = Modifier
                .size(60.dp)
                .clip(RoundedCornerShape(18.dp))
                .background(
                    Brush.radialGradient(
                        colors = listOf(tint.copy(alpha = 0.22f), tint.copy(alpha = 0.05f))
                    )
                )
                .border(1.5.dp, tint.copy(alpha = 0.45f), RoundedCornerShape(18.dp)),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = title,
                tint = tint,
                modifier = Modifier.size(26.dp)
            )
        }
        Spacer(modifier = Modifier.height(8.dp))
        Text(title, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Medium)
    }
}

@Composable
fun ContinueWatchingCard(media: MediaEntity, onClick: () -> Unit) {
    GlassCard(
        modifier = Modifier
            .width(220.dp)
            .clickable(onClick = onClick)
            .testTag("continue_${media.id}")
    ) {
        Column {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(100.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(
                        Brush.verticalGradient(
                            colors = listOf(RoyalPurple.copy(alpha = 0.4f), Color.Black)
                        )
                    ),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Rounded.PlayArrow, contentDescription = "Play", tint = ElectricBlue, modifier = Modifier.size(36.dp))
            }
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = media.title,
                color = Color.White,
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                text = media.artist ?: "Unknown Artist",
                color = Color.Gray,
                fontSize = 11.sp,
                maxLines = 1
            )
            Spacer(modifier = Modifier.height(6.dp))
            LinearProgressIndicator(
                progress = { 0.4f },
                color = ElectricBlue,
                trackColor = Color.White.copy(alpha = 0.1f),
                modifier = Modifier.fillMaxWidth().clip(CircleShape)
            )
        }
    }
}

@Composable
fun MediaItemCard(item: MediaEntity, isAudio: Boolean = false, onClick: () -> Unit) {
    val visualGradient = remember(item.id) {
        Brush.linearGradient(
            colors = listOf(
                if (isAudio) RoyalPurple.copy(alpha = 0.6f) else ElectricBlue.copy(alpha = 0.6f),
                Color.Black
            )
        )
    }

    GlassCard(
        modifier = Modifier
            .width(160.dp)
            .clickable(onClick = onClick)
            .testTag("item_${item.id}")
    ) {
        Column {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(110.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .background(visualGradient),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = if (isAudio) Icons.Rounded.MusicNote else Icons.Rounded.PlayArrow,
                    contentDescription = "Media Icon",
                    tint = Color.White,
                    modifier = Modifier.size(36.dp)
                )
            }
            Spacer(modifier = Modifier.height(10.dp))
            Text(
                text = item.title,
                color = Color.White,
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                text = item.artist ?: "Unknown Director",
                color = Color.Gray,
                fontSize = 11.sp,
                maxLines = 1
            )
        }
    }
}

@Composable
fun SectionHeader(title: String, icon: ImageVector? = null, onSeeAll: () -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            if (icon != null) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = ElectricBlue,
                    modifier = Modifier.size(20.dp)
                )
            }
            Text(title, color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
        }
        Text(
            text = "See All",
            color = ElectricBlue,
            fontSize = 13.sp,
            fontWeight = FontWeight.Medium,
            modifier = Modifier.clickable(onClick = onSeeAll)
        )
    }
}

// ==========================================
// VIDEOS SCREEN
// ==========================================
@Composable
fun VideosScreen(
    viewModel: MediaViewModel,
    mediaStoreViewModel: MediaStoreViewModel,
    initialCategory: String,
    smartCollectionsViewModel: com.example.ui.viewmodel.SmartCollectionsViewModel? = null,
    onPlayVideo: (MediaEntity) -> Unit
) {
    val context = LocalContext.current
    val appLang by viewModel.appLanguage.collectAsState()
    val scannedVideosRaw by mediaStoreViewModel.scannedVideos.collectAsState()
    val isScanning by mediaStoreViewModel.isScanning.collectAsState()

    val scannedVideos by mediaStoreViewModel.filteredVideos.collectAsState()
    val scannedFolders by mediaStoreViewModel.filteredFolders.collectAsState()

    val searchQuery by mediaStoreViewModel.searchQuery.collectAsState()
    val sortOrder by mediaStoreViewModel.sortOrder.collectAsState()
    val filterType by mediaStoreViewModel.filterType.collectAsState()

    val favoritesList by viewModel.favorites.collectAsState()
    val favoriteIds = remember(favoritesList) { favoritesList.map { it.id }.toSet() }

    val continueWatchingList by viewModel.continueWatching.collectAsState()
    val pinnedPaths by viewModel.pinnedFolderPaths.collectAsState()

    var activeTab by remember { mutableStateOf("Video") } // Video, Folder, Playlist
    var selectedFolder by remember { mutableStateOf<com.example.data.model.VideoFolder?>(null) }
    var isSearchExpanded by remember { mutableStateOf(false) }
    var showAdBanner by remember { mutableStateOf(false) }

    // Mock/Fallback videos exactly matching the provided Image 2 list!
    val mockVideos = remember {
        listOf(
            com.example.data.model.ScannedVideo(
                id = 1001,
                title = "SHUBHAM_👨‍🌾__FARMER_🤠🌾💖_--_...",
                path = "/storage/emulated/0/Download/farmer_reel.mp4",
                duration = 10000,
                size = 2202009,
                dateAdded = System.currentTimeMillis() - 86400000,
                uriString = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4",
                thumbnailUrl = "https://picsum.photos/seed/farmer/400/250",
                width = 1280,
                height = 720
            ),
            com.example.data.model.ScannedVideo(
                id = 1002,
                title = "@anshulraghuwanshi319___💯📉___Instagram...",
                path = "/storage/emulated/0/Download/instagram_reel.mp4",
                duration = 19000,
                size = 4959715,
                dateAdded = System.currentTimeMillis() - 172800000,
                uriString = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerEscapes.mp4",
                thumbnailUrl = "https://picsum.photos/seed/instagram/400/250",
                width = 1280,
                height = 720
            ),
            com.example.data.model.ScannedVideo(
                id = 1003,
                title = "Manish_kumar___किसानपुत्र_🌾❤️_#instagram...",
                path = "/storage/emulated/0/Download/farmer_son.mp4",
                duration = 14000,
                size = 7759462,
                dateAdded = System.currentTimeMillis() - 259200000,
                uriString = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerFun.mp4",
                thumbnailUrl = "https://picsum.photos/seed/farmer_son/400/250",
                width = 1280,
                height = 720
            ),
            com.example.data.model.ScannedVideo(
                id = 1004,
                title = "Amanraj Gill - HOPELESS (Official Video) ft. Nupur",
                path = "/storage/emulated/0/Download/hopeless_song.mp4",
                duration = 182000,
                size = 25165824,
                dateAdded = System.currentTimeMillis() - 345600000,
                uriString = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4",
                thumbnailUrl = "https://picsum.photos/seed/hopeless/400/250",
                width = 1920,
                height = 1080
            ),
            com.example.data.model.ScannedVideo(
                id = 1005,
                title = "Rohit Gijurka & Rushvi Walia - Beach Vibes (Slowed & Reverb)",
                path = "/storage/emulated/0/Download/beach_vibes.mp4",
                duration = 184000,
                size = 28311552,
                dateAdded = System.currentTimeMillis() - 432000000,
                uriString = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/Sintel.mp4",
                thumbnailUrl = "https://picsum.photos/seed/beach/400/250",
                width = 1920,
                height = 1080
            )
        )
    }

    // Combine mock videos and scanned videos to guarantee a populated screen
    val displayVideos = remember(scannedVideos, searchQuery) {
        if (scannedVideos.isEmpty() && searchQuery.isEmpty()) {
            mockVideos
        } else {
            scannedVideos
        }
    }

    // Helper conversion to MediaEntity
    fun com.example.data.model.ScannedVideo.toMediaEntity(): MediaEntity {
        return MediaEntity(
            id = "scanned_$id",
            title = title,
            url = uriString,
            duration = duration,
            artist = MediaStoreViewModel.formatSize(size),
            thumbnailUrl = thumbnailUrl,
            category = "Movies"
        )
    }

    // Handle runtime storage permissions gracefully
    val permissionToRequest = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
        android.Manifest.permission.READ_MEDIA_VIDEO
    } else {
        android.Manifest.permission.READ_EXTERNAL_STORAGE
    }

    var hasPermission by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(context, permissionToRequest) == PackageManager.PERMISSION_GRANTED
        )
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        hasPermission = isGranted
        if (isGranted) {
            mediaStoreViewModel.scanVideos()
        }
    }

    LaunchedEffect(hasPermission) {
        if (hasPermission) {
            mediaStoreViewModel.scanVideos()
        } else {
            permissionLauncher.launch(permissionToRequest)
        }
    }

    val customBgUri by viewModel.customBackgroundUri.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Transparent)
            .padding(horizontal = 16.dp)
    ) {
        Spacer(modifier = Modifier.height(16.dp))

        // 1. BRAND HEADER (from Image 2)
        if (selectedFolder != null) {
            val folder = selectedFolder!!
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = { selectedFolder = null },
                    modifier = Modifier
                        .size(40.dp)
                        .background(Color.White.copy(alpha = 0.1f), CircleShape)
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Rounded.ArrowBack,
                        contentDescription = "Back to Folders",
                        tint = Color.White
                    )
                }
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Text(
                        text = folder.name,
                        color = Color.White,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = "${folder.videoCount} videos • ${MediaStoreViewModel.formatSize(folder.totalSize)}",
                        color = Color.Gray,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium
                    )
                }
            }
        } else {
            if (isSearchExpanded) {
                // Expanded search text field
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(50.dp)
                        .background(Color.White.copy(alpha = 0.08f), RoundedCornerShape(25.dp))
                        .border(1.dp, Color.White.copy(alpha = 0.12f), RoundedCornerShape(25.dp))
                        .padding(horizontal = 16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Rounded.Search,
                        contentDescription = "Search",
                        tint = Color(0xFF10B981),
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    BasicTextField(
                        value = searchQuery,
                        onValueChange = { mediaStoreViewModel.setSearchQuery(it) },
                        textStyle = androidx.compose.ui.text.TextStyle(color = Color.White, fontSize = 14.sp),
                        cursorBrush = SolidColor(Color(0xFF10B981)),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("search_input"),
                        singleLine = true,
                        decorationBox = { innerTextField ->
                            if (searchQuery.isEmpty()) {
                                Text("Search videos or folders...", color = Color.Gray, fontSize = 13.sp)
                            }
                            innerTextField()
                        }
                    )
                    IconButton(
                        onClick = {
                            mediaStoreViewModel.setSearchQuery("")
                            isSearchExpanded = false
                        },
                        modifier = Modifier.size(24.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Close,
                            contentDescription = "Close",
                            tint = Color.Gray,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }
            } else {
                // High-fidelity branding header matching Image 2
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    // Logo: Vidiopen in bold with green accent
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = "VIDI",
                            color = Color.White,
                            fontWeight = FontWeight.Black,
                            fontSize = 24.sp,
                            letterSpacing = (-0.5).sp
                        )
                        Text(
                            text = "open",
                            color = Color(0xFF10B981), // Beautiful vibrant green accent
                            fontWeight = FontWeight.Black,
                            fontSize = 24.sp,
                            letterSpacing = (-0.5).sp
                        )
                    }

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        // Storage Scanner Metric
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            modifier = Modifier.clickable {
                                mediaStoreViewModel.scanVideos()
                            }
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.ArrowDownward,
                                contentDescription = "Storage Status",
                                tint = Color.White,
                                modifier = Modifier.size(20.dp)
                            )
                            Text(
                                text = "1.51GB",
                                color = Color.Gray,
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        // Search Trigger
                        IconButton(
                            onClick = { isSearchExpanded = true },
                            modifier = Modifier.size(24.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.Search,
                                contentDescription = "Search",
                                tint = Color.White,
                                modifier = Modifier.size(22.dp)
                            )
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // 2. AD BANNER / ANNOUNCEMENT CARD - REMOVED


        // 3. HISTORY HORIZONTAL LIST (from Image 2)
        if (selectedFolder == null) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 6.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Rounded.History,
                        contentDescription = "History",
                        tint = Color.White,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "History",
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp
                    )
                }
                IconButton(
                    onClick = {
                        viewModel.clearWatchHistory()
                    },
                    modifier = Modifier.size(24.dp)
                ) {
                    Icon(
                        imageVector = Icons.Rounded.Delete,
                        contentDescription = "Clear History",
                        tint = Color.Gray,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }

            // Render Horizontal Scroll list of history items (using scanned videos fallback so it is populated!)
            val historyItems = remember(continueWatchingList, mockVideos) {
                if (continueWatchingList.isEmpty()) {
                    // High-quality mock history items exactly like Image 2!
                    mockVideos.take(2)
                } else {
                    continueWatchingList.map { media ->
                        com.example.data.model.ScannedVideo(
                            id = media.id.replace("scanned_", "").toLongOrNull() ?: 9999,
                            title = media.title,
                            path = "",
                            duration = media.duration,
                            size = 12020202,
                            dateAdded = 0,
                            uriString = media.url,
                            thumbnailUrl = media.thumbnailUrl
                        )
                    }
                }
            }

            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                contentPadding = PaddingValues(bottom = 12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                items(historyItems) { histVideo ->
                    Column(
                        modifier = Modifier
                            .width(140.dp)
                            .clickable { onPlayVideo(histVideo.toMediaEntity()) }
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(82.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(Color.DarkGray.copy(alpha = 0.3f))
                        ) {
                            AsyncImage(
                                model = histVideo.thumbnailUrl,
                                contentDescription = histVideo.title,
                                contentScale = ContentScale.Crop,
                                modifier = Modifier.fillMaxSize()
                            )
                            // Play duration capsule in bottom right
                            Box(
                                modifier = Modifier
                                    .align(Alignment.BottomEnd)
                                    .padding(4.dp)
                                    .background(Color.Black.copy(alpha = 0.6f), RoundedCornerShape(4.dp))
                                    .padding(horizontal = 4.dp, vertical = 2.dp)
                            ) {
                                Text(
                                    text = "▶ " + formatMillis(histVideo.duration),
                                    color = Color.White,
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = histVideo.title,
                            color = Color.White,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Medium,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
            }
            Spacer(modifier = Modifier.height(10.dp))
        }

        // 4. MAIN LAYOUT TABS (Video, Folder, Playlist matching Image 2)
        if (selectedFolder == null) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    horizontalArrangement = Arrangement.spacedBy(24.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    listOf("Video", "Folder", "Playlist").forEach { tab ->
                        val active = activeTab == tab
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            modifier = Modifier.clickable { activeTab = tab }
                        ) {
                            Text(
                                text = tab,
                                color = if (active) Color(0xFF10B981) else Color.Gray,
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            // Sliding green indicator
                            Box(
                                modifier = Modifier
                                    .width(28.dp)
                                    .height(3.dp)
                                    .clip(RoundedCornerShape(100.dp))
                                    .background(if (active) Color(0xFF10B981) else Color.Transparent)
                            )
                        }
                    }
                }

                // Sorting/Filtering and Layout toggle icons on the right (from Image 2)
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    var showSortMenu by remember { mutableStateOf(false) }
                    Box {
                        IconButton(
                            onClick = { showSortMenu = true },
                            modifier = Modifier.size(24.dp)
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Rounded.Sort,
                                contentDescription = "Sort Menu",
                                tint = Color.White,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                        DropdownMenu(
                            expanded = showSortMenu,
                            onDismissRequest = { showSortMenu = false },
                            modifier = Modifier
                                .background(Color(0xFF121214))
                                .border(0.5.dp, Color.White.copy(alpha = 0.1f), RoundedCornerShape(8.dp))
                        ) {
                            val sortOptions = listOf(
                                VideoSortOrder.NEWEST to "Newest First",
                                VideoSortOrder.OLDEST to "Oldest First",
                                VideoSortOrder.NAME_A_Z to "Name (A-Z)",
                                VideoSortOrder.NAME_Z_A to "Name (Z-A)",
                                VideoSortOrder.SIZE_LARGEST to "Largest Size",
                                VideoSortOrder.SIZE_SMALLEST to "Smallest Size",
                                VideoSortOrder.DURATION_LONGEST to "Longest Duration",
                                VideoSortOrder.DURATION_SHORTEST to "Shortest Duration"
                            )
                            sortOptions.forEach { (order, label) ->
                                DropdownMenuItem(
                                    text = {
                                        Text(
                                            text = label,
                                            color = if (sortOrder == order) Color(0xFF10B981) else Color.White,
                                            fontSize = 13.sp
                                        )
                                    },
                                    onClick = {
                                        mediaStoreViewModel.setSortOrder(order)
                                        showSortMenu = false
                                    }
                                )
                            }
                        }
                    }

                    Icon(
                        imageVector = Icons.Rounded.List,
                        contentDescription = "List View",
                        tint = Color(0xFF10B981), // active list indicator
                        modifier = Modifier.size(22.dp)
                    )
                }
            }
            Spacer(modifier = Modifier.height(14.dp))
        }

        // 5. INNER CONTENT RENDERING
        if (!hasPermission) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(bottom = 60.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center,
                    modifier = Modifier.padding(24.dp)
                ) {
                    Icon(
                        imageVector = Icons.Rounded.Security,
                        contentDescription = null,
                        tint = Color(0xFF10B981),
                        modifier = Modifier.size(64.dp)
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    Text(
                        text = "Storage Access Required",
                        color = Color.White,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Vidiopen needs permission to scan your storage for local video files.",
                        color = Color.Gray,
                        fontSize = 13.sp,
                        textAlign = TextAlign.Center
                    )
                    Spacer(modifier = Modifier.height(24.dp))
                    Button(
                        onClick = { permissionLauncher.launch(permissionToRequest) },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF10B981))
                    ) {
                        Text("Grant Permission", color = Color.Black, fontWeight = FontWeight.Bold)
                    }
                }
            }
        } else if (isScanning) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(bottom = 60.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    CircularProgressIndicator(color = Color(0xFF10B981), modifier = Modifier.size(48.dp))
                    Spacer(modifier = Modifier.height(16.dp))
                    Text("Scanning local video library...", color = Color.Gray, fontSize = 14.sp)
                }
            }
        } else {
            // Selected Folder View (Drill down)
            if (selectedFolder != null) {
                val folderVideos = if (selectedFolder!!.path in listOf("WhatsApp", "Instagram", "Facebook", "YouTube")) {
                    selectedFolder!!.videos.filter {
                        searchQuery.isEmpty() || it.title.contains(searchQuery, ignoreCase = true)
                    }
                } else {
                    displayVideos.filter {
                        val file = File(it.path)
                        file.parentFile?.absolutePath == selectedFolder!!.path ||
                        it.title.contains(searchQuery, ignoreCase = true)
                    }
                }

                if (folderVideos.isEmpty()) {
                    Box(
                        modifier = Modifier.fillMaxSize(),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("No video files in this folder", color = Color.Gray)
                    }
                } else {
                    LazyColumn(
                        contentPadding = PaddingValues(bottom = 120.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.fillMaxSize()
                    ) {
                        items(folderVideos, key = { it.id }) { video ->
                            VideoListItem(
                                video = video,
                                isFavorite = favoriteIds.contains("scanned_${video.id}"),
                                onPlay = { onPlayVideo(video.toMediaEntity()) },
                                onToggleFavorite = {
                                    viewModel.toggleFavorite(video.toMediaEntity())
                                }
                            )
                        }
                    }
                }
            } else {
                // Tab switcher logic
                when (activeTab) {
                    "Video" -> {
                        if (displayVideos.isEmpty()) {
                            Box(
                                modifier = Modifier.fillMaxSize(),
                                contentAlignment = Alignment.Center
                            ) {
                                Text("No videos found", color = Color.Gray)
                            }
                        } else {
                            LazyColumn(
                                contentPadding = PaddingValues(bottom = 120.dp),
                                modifier = Modifier.fillMaxSize()
                            ) {
                                items(displayVideos, key = { it.id }) { video ->
                                    VideoListItem(
                                        video = video,
                                        isFavorite = favoriteIds.contains("scanned_${video.id}"),
                                        onPlay = { onPlayVideo(video.toMediaEntity()) },
                                        onToggleFavorite = {
                                            viewModel.toggleFavorite(video.toMediaEntity())
                                        }
                                    )
                                }
                            }
                        }
                    }

                    "Folder" -> {
                        // Dynamically categorize displayVideos into WhatsApp, Instagram, Facebook, and YouTube folders separately
                        val categorizedFolders = remember(displayVideos, appLang) {
                            val whatsappVideos = mutableListOf<com.example.data.model.ScannedVideo>()
                            val instagramVideos = mutableListOf<com.example.data.model.ScannedVideo>()
                            val facebookVideos = mutableListOf<com.example.data.model.ScannedVideo>()
                            val youtubeVideos = mutableListOf<com.example.data.model.ScannedVideo>()

                            displayVideos.forEach { video ->
                                val pathLower = video.path.lowercase()
                                val titleLower = video.title.lowercase()
                                if (pathLower.contains("whatsapp") || titleLower.contains("whatsapp")) {
                                    whatsappVideos.add(video)
                                } else if (pathLower.contains("instagram") || titleLower.contains("instagram") || pathLower.contains("reel") || titleLower.contains("reel")) {
                                    instagramVideos.add(video)
                                } else if (pathLower.contains("facebook") || pathLower.contains("fb") || titleLower.contains("facebook") || titleLower.contains("fb")) {
                                    facebookVideos.add(video)
                                } else if (pathLower.contains("youtube") || pathLower.contains("yt") || titleLower.contains("youtube") || titleLower.contains("yt") || titleLower.contains("song")) {
                                    youtubeVideos.add(video)
                                } else {
                                    // Distribute other scanned/fallback files round-robin based on id
                                    when (video.id % 4) {
                                        0L -> whatsappVideos.add(video)
                                        1L -> instagramVideos.add(video)
                                        2L -> facebookVideos.add(video)
                                        else -> youtubeVideos.add(video)
                                    }
                                }
                            }

                            val result = mutableListOf<com.example.data.model.VideoFolder>()
                            
                            // WhatsApp Folder
                            result.add(
                                com.example.data.model.VideoFolder(
                                    path = "WhatsApp",
                                    name = if (appLang == "hi") "व्हाट्सएप वीडियो (WhatsApp)" else "WhatsApp Videos",
                                    videoCount = whatsappVideos.size,
                                    totalSize = whatsappVideos.sumOf { it.size },
                                    latestVideoThumbnail = whatsappVideos.firstOrNull()?.thumbnailUrl,
                                    latestVideoDateAdded = whatsappVideos.firstOrNull()?.dateAdded ?: 0L,
                                    videos = whatsappVideos
                                )
                            )
                            
                            // Instagram Folder
                            result.add(
                                com.example.data.model.VideoFolder(
                                    path = "Instagram",
                                    name = if (appLang == "hi") "इंस्टाग्राम रील्स (Instagram)" else "Instagram Reels",
                                    videoCount = instagramVideos.size,
                                    totalSize = instagramVideos.sumOf { it.size },
                                    latestVideoThumbnail = instagramVideos.firstOrNull()?.thumbnailUrl,
                                    latestVideoDateAdded = instagramVideos.firstOrNull()?.dateAdded ?: 0L,
                                    videos = instagramVideos
                                )
                            )

                            // Facebook Folder
                            result.add(
                                com.example.data.model.VideoFolder(
                                    path = "Facebook",
                                    name = if (appLang == "hi") "फेसबुक डाउनलोड (Facebook)" else "Facebook Downloads",
                                    videoCount = facebookVideos.size,
                                    totalSize = facebookVideos.sumOf { it.size },
                                    latestVideoThumbnail = facebookVideos.firstOrNull()?.thumbnailUrl,
                                    latestVideoDateAdded = facebookVideos.firstOrNull()?.dateAdded ?: 0L,
                                    videos = facebookVideos
                                )
                            )

                            // YouTube Folder
                            result.add(
                                com.example.data.model.VideoFolder(
                                    path = "YouTube",
                                    name = if (appLang == "hi") "यूट्यूब ऑफलाइन (YouTube)" else "YouTube Offlines",
                                    videoCount = youtubeVideos.size,
                                    totalSize = youtubeVideos.sumOf { it.size },
                                    latestVideoThumbnail = youtubeVideos.firstOrNull()?.thumbnailUrl,
                                    latestVideoDateAdded = youtubeVideos.firstOrNull()?.dateAdded ?: 0L,
                                    videos = youtubeVideos
                                )
                            )

                            result
                        }

                        if (categorizedFolders.isEmpty()) {
                            Box(
                                modifier = Modifier.fillMaxSize(),
                                contentAlignment = Alignment.Center
                            ) {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Icon(
                                        imageVector = Icons.Rounded.FolderSpecial,
                                        contentDescription = null,
                                        tint = Color.Gray,
                                        modifier = Modifier.size(48.dp)
                                    )
                                    Spacer(modifier = Modifier.height(12.dp))
                                    Text("No folders found", color = Color.Gray, fontSize = 14.sp)
                                }
                            }
                        } else {
                            LazyVerticalGrid(
                                columns = GridCells.Fixed(2),
                                horizontalArrangement = Arrangement.spacedBy(16.dp),
                                verticalArrangement = Arrangement.spacedBy(16.dp),
                                contentPadding = PaddingValues(bottom = 120.dp),
                                modifier = Modifier.fillMaxSize()
                            ) {
                                items(categorizedFolders, key = { it.path }) { folder ->
                                    val folderIcon = when (folder.path) {
                                        "WhatsApp" -> Icons.Rounded.Forum
                                        "Instagram" -> Icons.Rounded.Camera
                                        "Facebook" -> Icons.Rounded.Public
                                        "YouTube" -> Icons.Rounded.PlayCircle
                                        else -> Icons.Rounded.Folder
                                    }
                                    val folderColor = when (folder.path) {
                                        "WhatsApp" -> Color(0xFF25D366)
                                        "Instagram" -> Color(0xFFE1306C)
                                        "Facebook" -> Color(0xFF1877F2)
                                        "YouTube" -> Color(0xFFFF0000)
                                        else -> Color(0xFF10B981)
                                    }

                                    GlassCard(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clickable {
                                                selectedFolder = folder
                                            }
                                    ) {
                                        Column(modifier = Modifier.padding(12.dp)) {
                                            Box(
                                                modifier = Modifier
                                                    .fillMaxWidth()
                                                    .height(72.dp)
                                                    .background(folderColor.copy(alpha = 0.08f), RoundedCornerShape(8.dp))
                                                    .border(1.dp, folderColor.copy(alpha = 0.15f), RoundedCornerShape(8.dp)),
                                                contentAlignment = Alignment.Center
                                            ) {
                                                Icon(
                                                    imageVector = folderIcon,
                                                    contentDescription = null,
                                                    tint = folderColor,
                                                    modifier = Modifier.size(36.dp)
                                                )
                                            }
                                            Spacer(modifier = Modifier.height(8.dp))
                                            Text(
                                                text = folder.name,
                                                color = Color.White,
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 14.sp,
                                                maxLines = 1,
                                                overflow = TextOverflow.Ellipsis
                                            )
                                            Text(
                                                text = "${folder.videoCount} videos",
                                                color = Color.Gray,
                                                fontSize = 11.sp
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }

                    "Playlist" -> {
                        // Custom play lists or smart libraries (Favorites, Recents)
                        val playlists = listOf(
                            "My Favorites" to favoriteIds.size,
                            "Recently Added" to displayVideos.size,
                            "High Definition (HD)" to displayVideos.filter { maxOf(it.width, it.height) >= 1280 }.size
                        )

                        LazyVerticalGrid(
                            columns = GridCells.Fixed(2),
                            horizontalArrangement = Arrangement.spacedBy(16.dp),
                            verticalArrangement = Arrangement.spacedBy(16.dp),
                            contentPadding = PaddingValues(bottom = 120.dp),
                            modifier = Modifier.fillMaxSize()
                        ) {
                            items(playlists) { (title, count) ->
                                GlassCard(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable {
                                            if (title == "My Favorites") {
                                                activeTab = "Video"
                                            } else {
                                                activeTab = "Video"
                                            }
                                        }
                                ) {
                                    Column(modifier = Modifier.padding(12.dp)) {
                                        Box(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .height(72.dp)
                                                .background(Color.White.copy(alpha = 0.05f), RoundedCornerShape(8.dp)),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Icon(
                                                imageVector = Icons.Rounded.PlaylistPlay,
                                                contentDescription = null,
                                                tint = Color(0xFF10B981),
                                                modifier = Modifier.size(36.dp)
                                            )
                                        }
                                        Spacer(modifier = Modifier.height(8.dp))
                                        Text(
                                            text = title,
                                            color = Color.White,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 14.sp
                                        )
                                        Text(
                                            text = "$count tracks",
                                            color = Color.Gray,
                                            fontSize = 11.sp
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun VideoListItem(
    video: com.example.data.model.ScannedVideo,
    isFavorite: Boolean,
    onPlay: () -> Unit,
    onToggleFavorite: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onPlay() }
            .padding(vertical = 10.dp, horizontal = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Thumbnail with duration overlay
        Box(
            modifier = Modifier
                .size(width = 110.dp, height = 70.dp)
                .clip(RoundedCornerShape(12.dp))
                .background(Color.White.copy(alpha = 0.05f))
        ) {
            AsyncImage(
                model = video.thumbnailUrl,
                contentDescription = video.title,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )
            Box(
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .padding(4.dp)
                    .background(Color.Black.copy(alpha = 0.62f), RoundedCornerShape(4.dp))
                    .padding(horizontal = 4.dp, vertical = 2.dp)
            ) {
                Text(
                    text = formatMillis(video.duration),
                    color = Color.White,
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        Spacer(modifier = Modifier.width(12.dp))

        // Text details
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = video.title,
                color = Color.White,
                fontWeight = FontWeight.SemiBold,
                fontSize = 14.sp,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )
            Spacer(modifier = Modifier.height(4.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = MediaStoreViewModel.formatSize(video.size),
                    color = Color.Gray,
                    fontSize = 11.sp
                )
                Spacer(modifier = Modifier.width(8.dp))
                Box(
                    modifier = Modifier
                        .size(3.dp)
                        .background(Color.Gray, CircleShape)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "MP4",
                    color = Color(0xFF10B981),
                    fontWeight = FontWeight.Bold,
                    fontSize = 10.sp
                )
            }
        }

        // Action controls
        IconButton(onClick = onToggleFavorite) {
            Icon(
                imageVector = if (isFavorite) Icons.Rounded.Favorite else Icons.Rounded.FavoriteBorder,
                contentDescription = "Toggle Favorite",
                tint = if (isFavorite) Color(0xFF10B981) else Color.Gray,
                modifier = Modifier.size(20.dp)
            )
        }
    }
}

// ==========================================
// MUSIC SCREEN (OFFLINE MUSIC LIBRARY)
// ==========================================
enum class MusicTab {
    ALL_SONGS,
    PLAYLIST,
    FOLDER,
    ALBUM,
    ARTIST
}

@Composable
fun GlowingEqualizer(isPlaying: Boolean, modifier: Modifier = Modifier) {
    val barCount = 10
    val infiniteTransition = rememberInfiniteTransition(label = "EqualizerTransition")
    
    val animations = (0 until barCount).map { index ->
        val duration = remember(index) { (500 + (index * 95) % 400) }
        infiniteTransition.animateFloat(
            initialValue = 0.15f,
            targetValue = 1.0f,
            animationSpec = infiniteRepeatable(
                animation = tween(durationMillis = duration, easing = FastOutSlowInEasing),
                repeatMode = RepeatMode.Reverse
            ),
            label = "EqualizerBar$index"
        )
    }

    Canvas(modifier = modifier.height(24.dp)) {
        val width = size.width
        val height = size.height
        val barWidth = (width / barCount) * 0.6f
        val gap = (width / barCount) * 0.4f

        for (i in 0 until barCount) {
            val progress = if (isPlaying) animations[i].value else 0.15f + (i % 3) * 0.05f
            val barHeight = height * progress
            val x = i * (barWidth + gap) + gap / 2
            val y = height - barHeight

            drawRoundRect(
                brush = Brush.verticalGradient(
                    colors = listOf(
                        Color(0xFF00FFCC),
                        Color(0xFF00D9FF),
                        Color(0x3300D9FF)
                    )
                ),
                topLeft = Offset(x, y),
                size = androidx.compose.ui.geometry.Size(barWidth, barHeight),
                cornerRadius = androidx.compose.ui.geometry.CornerRadius(barWidth / 2, barWidth / 2)
            )
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MusicScreen(
    viewModel: MediaViewModel,
    musicViewModel: MusicViewModel,
    onPlayTrack: (MediaEntity) -> Unit
) {
    val context = LocalContext.current
    val appLang by viewModel.appLanguage.collectAsState()
    val isScanning by musicViewModel.isScanning.collectAsState()
    val allSongsList by musicViewModel.allSongs.collectAsState()
    val albumsList by musicViewModel.albums.collectAsState()
    val artistsList by musicViewModel.artists.collectAsState()
    val foldersList by musicViewModel.folders.collectAsState()

    var activeTab by remember { mutableStateOf(MusicTab.ALL_SONGS) }
    var searchQuery by remember { mutableStateOf("") }
    var showSearchField by remember { mutableStateOf(false) }
    
    // Nested browsing states
    var selectedAlbum by remember { mutableStateOf<AlbumItem?>(null) }
    var selectedArtist by remember { mutableStateOf<ArtistItem?>(null) }
    var selectedFolder by remember { mutableStateOf<FolderItem?>(null) }

    // Track Specs Modal Detail state
    var activeSpecTrack by remember { mutableStateOf<ScannedSong?>(null) }

    // Custom overlay dialogs
    var showCleanDialog by remember { mutableStateOf(false) }
    var showAdFreeDialog by remember { mutableStateOf(false) }
    var showDownloadsDialog by remember { mutableStateOf(false) }
    var showMusoBanner by remember { mutableStateOf(true) }

    if (activeSpecTrack != null) {
        TrackSpecDialog(
            track = activeSpecTrack!!,
            onDismiss = { activeSpecTrack = null }
        )
    }

    // Clean dialog simulation
    if (showCleanDialog) {
        var cleanProgress by remember { mutableStateOf(0f) }
        var cleanComplete by remember { mutableStateOf(false) }

        LaunchedEffect(Unit) {
            for (i in 1..100) {
                kotlinx.coroutines.delay(15)
                cleanProgress = i / 100f
            }
            cleanComplete = true
        }

        androidx.compose.ui.window.Dialog(onDismissRequest = { showCleanDialog = false }) {
            Surface(
                shape = RoundedCornerShape(24.dp),
                color = Color(0xFF0F0F12),
                border = BorderStroke(1.dp, Color.White.copy(alpha = 0.1f)),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(24.dp)
            ) {
                Column(
                    modifier = Modifier.padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    if (!cleanComplete) {
                        Text(
                            text = if (appLang == "hi") "कैश और जंक साफ किया जा रहा है..." else "Cleaning Cache & Junk...",
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp
                        )
                        CircularProgressIndicator(
                            progress = { cleanProgress },
                            color = Color(0xFF25D366),
                            trackColor = Color.White.copy(alpha = 0.05f),
                            modifier = Modifier.size(72.dp)
                        )
                        Text(
                            text = "${(cleanProgress * 100).toInt()}% Done",
                            color = Color.Gray,
                            fontSize = 13.sp
                        )
                    } else {
                        Icon(
                            imageVector = Icons.Rounded.CheckCircle,
                            contentDescription = "Success",
                            tint = Color(0xFF25D366),
                            modifier = Modifier.size(64.dp)
                        )
                        Text(
                            text = if (appLang == "hi") "डिवाइस ऑप्टिमाइज़ हो गया!" else "Device Optimized!",
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 18.sp
                        )
                        Text(
                            text = if (appLang == "hi") "1.52 GB ऑडियो और वीडियो कैशे स्ट्रीम फाइलें साफ की गईं।" else "Cleaned 1.52 GB of residual temporary audio and video cache stream files.",
                            color = Color.Gray,
                            fontSize = 12.sp,
                            textAlign = TextAlign.Center
                        )
                        Button(
                            onClick = { showCleanDialog = false },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF25D366))
                        ) {
                            Text(
                                text = if (appLang == "hi") "ठीक है" else "Done",
                                color = Color.Black,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }
    }

    // Ad Free dialog
    if (showAdFreeDialog) {
        AlertDialog(
            onDismissRequest = { showAdFreeDialog = false },
            containerColor = Color(0xFF0F0F12),
            title = {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(Icons.Rounded.Star, contentDescription = null, tint = Color(0xFFFFD700))
                    Text(
                        text = if (appLang == "hi") "प्रीमियम विज्ञापन-मुक्त सक्रिय" else "Premium Ad-Free Active",
                        color = Color.White,
                        fontWeight = FontWeight.Bold
                    )
                }
            },
            text = {
                Text(
                    text = if (appLang == "hi") "बधाई हो! आप अल्ट्रा प्रीमियम विज्ञापन-मुक्त मोड में हैं। कोई भी विज्ञापन आपको परेशान नहीं करेगा।" else "Congratulations! You are browsing in Ultra Premium Ad-Free Mode. No advertisement stream clips or banners will interrupt your acoustic sanctuary.",
                    color = Color.LightGray,
                    fontSize = 13.sp
                )
            },
            confirmButton = {
                Button(
                    onClick = { showAdFreeDialog = false },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF25D366))
                ) {
                    Text(
                        text = if (appLang == "hi") "आनंद लें" else "Enjoy Ad-Free",
                        color = Color.Black,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        )
    }

    // Downloads Dialog
    if (showDownloadsDialog) {
        androidx.compose.ui.window.Dialog(onDismissRequest = { showDownloadsDialog = false }) {
            Surface(
                shape = RoundedCornerShape(24.dp),
                color = Color(0xFF0F0F12),
                border = BorderStroke(1.dp, Color.White.copy(alpha = 0.1f)),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp)
            ) {
                Column(
                    modifier = Modifier.padding(20.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = if (appLang == "hi") "डाउनलोड मैनेजर" else "Downloads Manager",
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp
                        )
                        IconButton(onClick = { showDownloadsDialog = false }) {
                            Icon(Icons.Rounded.Close, contentDescription = "Close", tint = Color.Gray)
                        }
                    }
                    
                    HorizontalDivider(color = Color.White.copy(alpha = 0.08f))

                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(Color.White.copy(alpha = 0.03f), RoundedCornerShape(12.dp))
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                Text("Sample_Track_HD.mp3", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                Text("Completed • 4.8 MB", color = Color.Gray, fontSize = 10.sp)
                            }
                            Icon(
                                imageVector = Icons.Rounded.CheckCircle,
                                contentDescription = "Success",
                                tint = Color(0xFF25D366),
                                modifier = Modifier.size(18.dp)
                              )
                        }
                        
                        Text(
                            text = if (appLang == "hi") "सभी वेब स्ट्रीम और लिंक डाउनलोड यहां दिखाई देंगे।" else "All web stream caching and link downloads will be cataloged here.",
                            color = Color.Gray,
                            fontSize = 11.sp,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.fillMaxWidth().padding(top = 8.dp)
                        )
                    }
                }
            }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Transparent)
            .padding(horizontal = 16.dp)
    ) {
        Spacer(modifier = Modifier.height(55.dp))

        // Custom Top Bar (PLAYit style)
        if (showSearchField) {
            // Search Input Row
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                IconButton(onClick = { 
                    showSearchField = false 
                    searchQuery = ""
                }) {
                    Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = "Back", tint = Color.White)
                }
                
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    placeholder = { Text(if (appLang == "hi") "खोजें..." else "Search songs...", color = Color.Gray, fontSize = 14.sp) },
                    colors = TextFieldDefaults.colors(
                        focusedContainerColor = Color.White.copy(alpha = 0.04f),
                        unfocusedContainerColor = Color.White.copy(alpha = 0.04f),
                        focusedIndicatorColor = Color(0xFF25D366),
                        unfocusedIndicatorColor = Color.White.copy(alpha = 0.08f),
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White
                    ),
                    shape = RoundedCornerShape(12.dp),
                    singleLine = true,
                    modifier = Modifier.weight(1f)
                )

                if (searchQuery.isNotEmpty()) {
                    IconButton(onClick = { searchQuery = "" }) {
                        Icon(Icons.Rounded.Close, contentDescription = "Clear", tint = Color.Gray)
                    }
                }
            }
        } else {
            // Standard PLAYit header updated to Vidiopen
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                // Logo on left (Updated to Vidiopen)
                Text(
                    text = "Vidiopen",
                    fontSize = 26.sp,
                    fontWeight = FontWeight.Black,
                    color = Color.White,
                    modifier = Modifier.testTag("playit_music_logo")
                )

                // Tools on right
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    // 1.52GB trash button
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier
                            .clickable { showCleanDialog = true }
                            .padding(horizontal = 4.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.DeleteOutline,
                            contentDescription = "Clean Cache",
                            tint = Color.White,
                            modifier = Modifier.size(18.dp)
                        )
                        Text(
                            text = "1.52GB",
                            color = Color.Gray,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    // Search icon
                    IconButton(onClick = { showSearchField = true }) {
                        Icon(
                            imageVector = Icons.Rounded.Search,
                            contentDescription = "Search",
                            tint = Color.White,
                            modifier = Modifier.size(22.dp)
                        )
                    }

                    // Download icon
                    IconButton(onClick = { showDownloadsDialog = true }) {
                        Icon(
                            imageVector = Icons.Rounded.Download,
                            contentDescription = "Downloads",
                            tint = Color.White,
                            modifier = Modifier.size(22.dp)
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Tabs Row (PLAYit Style)
        val inNestedView = selectedAlbum != null || selectedArtist != null || selectedFolder != null
        if (!inNestedView) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(24.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                MusicTab.values().forEach { tab ->
                    val isSelected = activeTab == tab
                    val tabName = when (tab) {
                        MusicTab.ALL_SONGS -> if (appLang == "hi") "सभी गाने" else "All Songs"
                        MusicTab.PLAYLIST -> if (appLang == "hi") "प्लेलिस्ट" else "Playlist"
                        MusicTab.FOLDER -> if (appLang == "hi") "फ़ोल्डर" else "Folder"
                        MusicTab.ALBUM -> if (appLang == "hi") "एल्बम" else "Album"
                        MusicTab.ARTIST -> if (appLang == "hi") "कलाकार" else "Artist"
                    }

                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier
                            .clickable { activeTab = tab }
                            .padding(vertical = 4.dp)
                            .testTag("music_tab_${tab.name}")
                    ) {
                        Text(
                            text = tabName,
                            color = if (isSelected) Color(0xFF25D366) else Color.Gray,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        // Active tab underline indicator
                        Box(
                            modifier = Modifier
                                .height(3.dp)
                                .width(36.dp)
                                .clip(RoundedCornerShape(1.5.dp))
                                .background(if (isSelected) Color(0xFF25D366) else Color.Transparent)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))
        }

        // Main content render based on tab/nested states
        if (isScanning) {
            MusicSkeletonGroup()
        } else if (allSongsList.isEmpty()) {
            MusicEmptySanctuaryState { musicViewModel.scanMusicFiles() }
        } else {
            if (selectedAlbum != null) {
                NestedSongsListView(
                    title = selectedAlbum!!.name,
                    subtitle = "${selectedAlbum!!.artist} • ${selectedAlbum!!.songs.size} tracks",
                    songs = selectedAlbum!!.songs,
                    artworkUri = selectedAlbum!!.artworkUri,
                    onBack = { selectedAlbum = null },
                    onTrackClicked = { song -> musicViewModel.playSong(song, selectedAlbum!!.songs) },
                    onTrackSpecsClicked = { activeSpecTrack = it }
                )
            } else if (selectedArtist != null) {
                NestedSongsListView(
                    title = selectedArtist!!.name,
                    subtitle = "${selectedArtist!!.songs.size} tracks total",
                    songs = selectedArtist!!.songs,
                    artworkUri = selectedArtist!!.artworkUri,
                    onBack = { selectedArtist = null },
                    onTrackClicked = { song -> musicViewModel.playSong(song, selectedArtist!!.songs) },
                    onTrackSpecsClicked = { activeSpecTrack = it }
                )
            } else if (selectedFolder != null) {
                NestedSongsListView(
                    title = selectedFolder!!.name,
                    subtitle = "Path: ${selectedFolder!!.path} • ${selectedFolder!!.songs.size} songs",
                    songs = selectedFolder!!.songs,
                    artworkUri = null,
                    onBack = { selectedFolder = null },
                    onTrackClicked = { song -> musicViewModel.playSong(song, selectedFolder!!.songs) },
                    onTrackSpecsClicked = { activeSpecTrack = it }
                )
            } else {
                when (activeTab) {
                    MusicTab.ALL_SONGS -> {
                        MusicSongsTab(
                            songs = allSongsList,
                            searchQuery = searchQuery,
                            onTrackClicked = { song -> musicViewModel.playSong(song, allSongsList) },
                            onTrackSpecsClicked = { activeSpecTrack = it },
                            musicViewModel = musicViewModel
                        )
                    }
                    MusicTab.PLAYLIST -> {
                        MusicPlaylistTab(
                            songs = allSongsList,
                            onTrackClicked = { song -> musicViewModel.playSong(song, allSongsList) },
                            appLang = appLang
                        )
                    }
                    MusicTab.FOLDER -> {
                        MusicFoldersTab(
                            folders = foldersList,
                            searchQuery = searchQuery,
                            onFolderSelected = { selectedFolder = it }
                        )
                    }
                    MusicTab.ALBUM -> {
                        MusicAlbumsTab(
                            albums = albumsList,
                            searchQuery = searchQuery,
                            onAlbumSelected = { selectedAlbum = it }
                        )
                    }
                    MusicTab.ARTIST -> {
                        MusicArtistsTab(
                            artists = artistsList,
                            searchQuery = searchQuery,
                            onArtistSelected = { selectedArtist = it }
                        )
                    }
                }
            }
        }
    }
}

// ==========================================
// MUSIC SUB-VIEWS
// ==========================================

@Composable
fun MusicOverviewTab(
    allSongs: List<ScannedSong>,
    albums: List<AlbumItem>,
    artists: List<ArtistItem>,
    recentlyAdded: List<ScannedSong>,
    searchQuery: String,
    onAlbumSelected: (AlbumItem) -> Unit,
    onArtistSelected: (ArtistItem) -> Unit,
    onTrackClicked: (ScannedSong) -> Unit,
    onTrackSpecsClicked: (ScannedSong) -> Unit
) {
    // Filter overview datasets if searching
    val filteredRecentlyAdded = remember(recentlyAdded, searchQuery) {
        if (searchQuery.isBlank()) recentlyAdded else recentlyAdded.filter {
            it.title.contains(searchQuery, ignoreCase = true) || (it.artist?.contains(searchQuery, ignoreCase = true) ?: false)
        }
    }

    val filteredAlbums = remember(albums, searchQuery) {
        if (searchQuery.isBlank()) albums else albums.filter {
            it.name.contains(searchQuery, ignoreCase = true) || it.artist.contains(searchQuery, ignoreCase = true)
        }
    }

    val filteredArtists = remember(artists, searchQuery) {
        if (searchQuery.isBlank()) artists else artists.filter {
            it.name.contains(searchQuery, ignoreCase = true)
        }
    }

    LazyColumn(
        contentPadding = PaddingValues(bottom = 110.dp),
        verticalArrangement = Arrangement.spacedBy(20.dp),
        modifier = Modifier.fillMaxSize()
    ) {
        // 1. Large Hero Album Artwork
        val heroSong = allSongs.firstOrNull()
        if (heroSong != null && searchQuery.isBlank()) {
            item {
                Text("Featured Sanctuary", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(10.dp))
                GlassCard(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(160.dp)
                        .clickable { onTrackClicked(heroSong) }
                        .testTag("hero_album_card")
                ) {
                    Box(modifier = Modifier.fillMaxSize()) {
                        // Blurred Background Glow
                        AsyncImage(
                            model = heroSong.artworkUri,
                            contentDescription = null,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier
                                .fillMaxSize()
                                .background(Color.White.copy(alpha = 0.03f))
                        )
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .background(
                                    Brush.verticalGradient(
                                        colors = listOf(
                                            Color.Black.copy(alpha = 0.3f),
                                            Color.Black.copy(alpha = 0.95f)
                                        )
                                    )
                                )
                        )

                        // Core info
                        Row(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(16.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(90.dp)
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(Color.White.copy(alpha = 0.04f))
                                    .border(1.dp, Color.White.copy(alpha = 0.15f), RoundedCornerShape(12.dp))
                            ) {
                                AsyncImage(
                                    model = heroSong.artworkUri,
                                    contentDescription = "Cover",
                                    contentScale = ContentScale.Crop,
                                    modifier = Modifier.fillMaxSize()
                                )
                            }

                            Spacer(modifier = Modifier.width(16.dp))

                            Column(modifier = Modifier.weight(1f)) {
                                Box(
                                    modifier = Modifier
                                        .background(RoyalPurple.copy(alpha = 0.25f), RoundedCornerShape(6.dp))
                                        .padding(horizontal = 6.dp, vertical = 2.dp)
                                ) {
                                    Text("HIGH RESOLUTION", color = ElectricBlue, fontSize = 8.sp, fontWeight = FontWeight.Bold)
                                }
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    text = heroSong.title,
                                    color = Color.White,
                                    fontSize = 17.sp,
                                    fontWeight = FontWeight.Black,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Text(
                                    text = heroSong.artist ?: "Unknown Artist",
                                    color = Color.Gray,
                                    fontSize = 12.sp,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Rounded.Album, contentDescription = null, tint = ElectricBlue, modifier = Modifier.size(12.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = heroSong.album ?: "Unknown Album",
                                        color = Color.DarkGray,
                                        fontSize = 11.sp,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // 2. Horizontal Albums
        if (filteredAlbums.isNotEmpty()) {
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Albums", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                    GlowText("${albums.size} Total", fontSize = 11.sp, color = ElectricBlue)
                }
                Spacer(modifier = Modifier.height(10.dp))
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    items(filteredAlbums, key = { it.name }) { album ->
                        HorizontalAlbumCard(album = album, onClick = { onAlbumSelected(album) })
                    }
                }
            }
        }

        // 3. Horizontal Artists
        if (filteredArtists.isNotEmpty()) {
            item {
                Text("Artists", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(10.dp))
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    items(filteredArtists, key = { it.name }) { artist ->
                        HorizontalArtistCard(artist = artist, onClick = { onArtistSelected(artist) })
                    }
                }
            }
        }

        // 4. Recently Added
        if (filteredRecentlyAdded.isNotEmpty()) {
            item {
                Text("Recently Added", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold)
            }

            items(filteredRecentlyAdded, key = { "recent_${it.id}" }) { song ->
                SongRowItem(
                    song = song,
                    onClick = { onTrackClicked(song) },
                    onInfoClick = { onTrackSpecsClicked(song) }
                )
            }
        }
    }
}

@Composable
fun MusicSongsTab(
    songs: List<ScannedSong>,
    searchQuery: String,
    onTrackClicked: (ScannedSong) -> Unit,
    onTrackSpecsClicked: (ScannedSong) -> Unit,
    musicViewModel: MusicViewModel
) {
    var sortOrder by remember { mutableStateOf("title") } // "title", "date", "duration"
    var showSortMenu by remember { mutableStateOf(false) }

    val sortedSongs = remember(songs, sortOrder, searchQuery) {
        val filtered = if (searchQuery.isBlank()) songs else songs.filter {
            it.title.contains(searchQuery, ignoreCase = true) || 
            (it.artist?.contains(searchQuery, ignoreCase = true) ?: false)
        }
        when (sortOrder) {
            "date" -> filtered.sortedByDescending { it.id } // simulated date added
            "duration" -> filtered.sortedByDescending { it.duration }
            else -> filtered.sortedBy { it.title.lowercase() }
        }
    }

    if (sortedSongs.isEmpty()) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("No matching songs found", color = Color.Gray, fontSize = 13.sp)
        }
    } else {
        LazyColumn(
            contentPadding = PaddingValues(bottom = 120.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.fillMaxSize()
        ) {
            // Shuffle all row
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                        modifier = Modifier
                            .weight(1f)
                            .clickable {
                                if (sortedSongs.isNotEmpty()) {
                                    val shuffled = sortedSongs.shuffled()
                                    musicViewModel.playSong(shuffled.first(), shuffled)
                                }
                            }
                    ) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .background(Color(0xFF25D366), CircleShape), // PLAYit green circle
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.PlayArrow,
                                contentDescription = "Shuffle Play",
                                tint = Color.Black,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                        Text(
                            text = "Shuffle all(${sortedSongs.size})",
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp
                        )
                    }

                    Box {
                        IconButton(onClick = { showSortMenu = true }) {
                            Icon(
                                imageVector = Icons.Rounded.SwapVert,
                                contentDescription = "Sort",
                                tint = Color.White,
                                modifier = Modifier.size(22.dp)
                            )
                        }
                        DropdownMenu(
                            expanded = showSortMenu,
                            onDismissRequest = { showSortMenu = false },
                            containerColor = Color(0xFF1E1E22)
                        ) {
                            DropdownMenuItem(
                                text = { Text("Sort by Title", color = Color.White) },
                                onClick = {
                                    sortOrder = "title"
                                    showSortMenu = false
                                }
                            )
                            DropdownMenuItem(
                                text = { Text("Sort by Date Added", color = Color.White) },
                                onClick = {
                                    sortOrder = "date"
                                    showSortMenu = false
                                }
                            )
                            DropdownMenuItem(
                                text = { Text("Sort by Duration", color = Color.White) },
                                onClick = {
                                    sortOrder = "duration"
                                    showSortMenu = false
                                }
                            )
                        }
                    }
                }
            }

            itemsIndexed(sortedSongs, key = { index, song -> "tab_song_${song.id}_$index" }) { index, song ->
                val activeSong by musicViewModel.currentPlayingSong.collectAsState()
                val isPlaying = activeSong?.id == song.id

                SongRowItem(
                    song = song,
                    onClick = { musicViewModel.playSong(song, sortedSongs) },
                    onInfoClick = { onTrackSpecsClicked(song) },
                    index = index + 1,
                    isPlaying = isPlaying
                )
            }
        }
    }
}

@Composable
fun MusicPlaylistTab(
    songs: List<ScannedSong>,
    onTrackClicked: (ScannedSong) -> Unit,
    appLang: String
) {
    val context = LocalContext.current
    var showCreateDialog by remember { mutableStateOf(false) }
    var playlistName by remember { mutableStateOf("") }
    
    val defaultPlaylists = listOf(
        "My Favorites" to songs.take(5),
        "Recently Played" to songs.takeLast(5),
        "Chill Mix" to songs.shuffled().take(5)
    )

    LazyColumn(
        contentPadding = PaddingValues(bottom = 120.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        modifier = Modifier.fillMaxSize()
    ) {
        item {
            GlassCard(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { showCreateDialog = true }
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(44.dp)
                            .background(Color(0xFF25D366).copy(alpha = 0.1f), RoundedCornerShape(8.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Add,
                            contentDescription = null,
                            tint = Color(0xFF25D366),
                            modifier = Modifier.size(24.dp)
                        )
                    }
                    Text(
                        text = if (appLang == "hi") "नई प्लेलिस्ट बनाएं" else "Create New Playlist",
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )
                }
            }
        }

        items(defaultPlaylists) { (name, playlistSongs) ->
            var expanded by remember { mutableStateOf(false) }
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .background(Color.White.copy(alpha = 0.02f))
                    .border(1.dp, Color.White.copy(alpha = 0.05f), RoundedCornerShape(16.dp))
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { expanded = !expanded }
                        .padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(48.dp)
                                .background(Color.White.copy(alpha = 0.05f), RoundedCornerShape(12.dp)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.QueueMusic,
                                contentDescription = null,
                                tint = Color(0xFF25D366),
                                modifier = Modifier.size(24.dp)
                            )
                        }
                        Column {
                            Text(
                                text = name,
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp
                            )
                            Text(
                                text = "${playlistSongs.size} tracks",
                                color = Color.Gray,
                                fontSize = 11.sp
                            )
                        }
                    }
                    Icon(
                        imageVector = if (expanded) Icons.Rounded.ExpandLess else Icons.Rounded.ExpandMore,
                        contentDescription = null,
                        tint = Color.Gray
                    )
                }

                if (expanded) {
                    HorizontalDivider(color = Color.White.copy(alpha = 0.05f))
                    Column(modifier = Modifier.padding(8.dp)) {
                        if (playlistSongs.isEmpty()) {
                            Text(
                                text = if (appLang == "hi") "प्लेलिस्ट खाली है" else "Playlist is empty",
                                color = Color.Gray,
                                fontSize = 12.sp,
                                modifier = Modifier.padding(16.dp)
                            )
                        } else {
                            playlistSongs.forEachIndexed { idx, song ->
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable { onTrackClicked(song) }
                                        .padding(vertical = 8.dp, horizontal = 12.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                                        modifier = Modifier.weight(1f)
                                    ) {
                                        Text(
                                            text = "${idx + 1}",
                                            color = Color.Gray,
                                            fontSize = 12.sp,
                                            modifier = Modifier.width(20.dp)
                                        )
                                        Column {
                                            Text(
                                                text = song.title,
                                                color = Color.White,
                                                fontSize = 13.sp,
                                                fontWeight = FontWeight.SemiBold,
                                                maxLines = 1,
                                                overflow = TextOverflow.Ellipsis
                                            )
                                            Text(
                                                text = song.artist ?: "Unknown Artist",
                                                color = Color.Gray,
                                                fontSize = 11.sp,
                                                maxLines = 1,
                                                overflow = TextOverflow.Ellipsis
                                            )
                                        }
                                    }
                                    Icon(
                                        imageVector = Icons.Rounded.PlayArrow,
                                        contentDescription = "Play",
                                        tint = Color(0xFF25D366),
                                        modifier = Modifier.size(16.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showCreateDialog) {
        AlertDialog(
            onDismissRequest = { showCreateDialog = false },
            containerColor = Color(0xFF101012),
            shape = RoundedCornerShape(24.dp),
            title = { Text(if (appLang == "hi") "प्लेलिस्ट बनाएं" else "Create Playlist", color = Color.White, fontWeight = FontWeight.Bold) },
            text = {
                OutlinedTextField(
                    value = playlistName,
                    onValueChange = { playlistName = it },
                    placeholder = { Text(if (appLang == "hi") "प्लेलिस्ट का नाम डालें" else "Enter playlist name", color = Color.Gray) },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White,
                        focusedBorderColor = Color(0xFF25D366),
                        unfocusedBorderColor = Color.White.copy(alpha = 0.1f)
                    ),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (playlistName.isNotBlank()) {
                            Toast.makeText(context, if (appLang == "hi") "प्लेलिस्ट '$playlistName' बनाई गई!" else "Playlist '$playlistName' created!", Toast.LENGTH_SHORT).show()
                            showCreateDialog = false
                            playlistName = ""
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF25D366))
                ) {
                    Text(if (appLang == "hi") "बनाएं" else "Create", color = Color.Black, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showCreateDialog = false }) {
                    Text(if (appLang == "hi") "रद्द करें" else "Cancel", color = Color.Gray)
                }
            }
        )
    }
}

@Composable
fun MusicAlbumsTab(
    albums: List<AlbumItem>,
    searchQuery: String,
    onAlbumSelected: (AlbumItem) -> Unit
) {
    val filteredAlbums = remember(albums, searchQuery) {
        if (searchQuery.isBlank()) albums else albums.filter {
            it.name.contains(searchQuery, ignoreCase = true) || it.artist.contains(searchQuery, ignoreCase = true)
        }
    }

    if (filteredAlbums.isEmpty()) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("No matching albums found", color = Color.Gray, fontSize = 13.sp)
        }
    } else {
        LazyVerticalGrid(
            columns = GridCells.Fixed(2),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            contentPadding = PaddingValues(bottom = 110.dp),
            modifier = Modifier.fillMaxSize()
        ) {
            items(filteredAlbums, key = { "tab_album_${it.name}" }) { album ->
                GlassCard(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onAlbumSelected(album) }
                        .testTag("album_card_${album.name}")
                ) {
                    Column {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(130.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(Color.White.copy(alpha = 0.03f))
                        ) {
                            AsyncImage(
                                model = album.artworkUri,
                                contentDescription = album.name,
                                contentScale = ContentScale.Crop,
                                modifier = Modifier.fillMaxSize()
                            )
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = album.name,
                            color = Color.White,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.padding(horizontal = 8.dp)
                        )
                        Text(
                            text = album.artist,
                            color = Color.Gray,
                            fontSize = 11.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.padding(horizontal = 8.dp)
                        )
                        Text(
                            text = "${album.songs.size} tracks",
                            color = ElectricBlue,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun MusicArtistsTab(
    artists: List<ArtistItem>,
    searchQuery: String,
    onArtistSelected: (ArtistItem) -> Unit
) {
    val filteredArtists = remember(artists, searchQuery) {
        if (searchQuery.isBlank()) artists else artists.filter {
            it.name.contains(searchQuery, ignoreCase = true)
        }
    }

    if (filteredArtists.isEmpty()) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("No matching artists found", color = Color.Gray, fontSize = 13.sp)
        }
    } else {
        LazyVerticalGrid(
            columns = GridCells.Fixed(3),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
            contentPadding = PaddingValues(bottom = 110.dp),
            modifier = Modifier.fillMaxSize()
        ) {
            items(filteredArtists, key = { "tab_artist_${it.name}" }) { artist ->
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onArtistSelected(artist) }
                        .testTag("artist_card_${artist.name}")
                ) {
                    Box(
                        modifier = Modifier
                            .size(80.dp)
                            .clip(CircleShape)
                            .background(Color.White.copy(alpha = 0.03f))
                            .border(1.dp, Color.White.copy(alpha = 0.1f), CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        if (artist.artworkUri != null) {
                            AsyncImage(
                                model = artist.artworkUri,
                                contentDescription = artist.name,
                                contentScale = ContentScale.Crop,
                                modifier = Modifier.fillMaxSize()
                            )
                        } else {
                            Icon(Icons.Rounded.Person, contentDescription = null, tint = ElectricBlue, modifier = Modifier.size(32.dp))
                        }
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = artist.name,
                        color = Color.White,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        textAlign = TextAlign.Center
                    )
                    Text(
                        text = "${artist.songs.size} tracks",
                        color = Color.Gray,
                        fontSize = 9.sp,
                        textAlign = TextAlign.Center
                    )
                }
            }
        }
    }
}

@Composable
fun MusicFoldersTab(
    folders: List<FolderItem>,
    searchQuery: String,
    onFolderSelected: (FolderItem) -> Unit
) {
    val filteredFolders = remember(folders, searchQuery) {
        if (searchQuery.isBlank()) folders else folders.filter {
            it.name.contains(searchQuery, ignoreCase = true) || it.path.contains(searchQuery, ignoreCase = true)
        }
    }

    if (filteredFolders.isEmpty()) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("No matching folders found", color = Color.Gray, fontSize = 13.sp)
        }
    } else {
        LazyColumn(
            contentPadding = PaddingValues(bottom = 110.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.fillMaxSize()
        ) {
            items(filteredFolders, key = { "tab_folder_${it.path}" }) { folder ->
                GlassCard(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onFolderSelected(folder) }
                        .testTag("folder_card_${folder.name}")
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(44.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(Color.White.copy(alpha = 0.04f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Rounded.Folder, contentDescription = "Folder", tint = ElectricBlue, modifier = Modifier.size(22.dp))
                        }

                        Spacer(modifier = Modifier.width(14.dp))

                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = folder.name,
                                color = Color.White,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                text = folder.path,
                                color = Color.Gray,
                                fontSize = 10.sp,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }

                        Column(horizontalAlignment = Alignment.End) {
                            Text(
                                text = "${folder.songs.size} items",
                                color = Color.White,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = formatMusicSize(folder.totalSize),
                                color = ElectricBlue,
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }
    }
}

// ==========================================
// DETAILED COMPONENT LAYOUTS
// ==========================================

@Composable
fun HorizontalAlbumCard(album: AlbumItem, onClick: () -> Unit) {
    GlassCard(
        modifier = Modifier
            .width(130.dp)
            .clickable(onClick = onClick)
            .testTag("horiz_album_${album.name}")
    ) {
        Column {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(105.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(Color.White.copy(alpha = 0.02f))
            ) {
                AsyncImage(
                    model = album.artworkUri,
                    contentDescription = album.name,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
            }
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = album.name,
                color = Color.White,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.padding(horizontal = 4.dp)
            )
            Text(
                text = "${album.songs.size} songs",
                color = Color.Gray,
                fontSize = 10.sp,
                modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
            )
        }
    }
}

@Composable
fun HorizontalArtistCard(artist: ArtistItem, onClick: () -> Unit) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .width(75.dp)
            .clickable(onClick = onClick)
            .testTag("horiz_artist_${artist.name}")
    ) {
        Box(
            modifier = Modifier
                .size(60.dp)
                .clip(CircleShape)
                .background(Color.White.copy(alpha = 0.03f))
                .border(1.dp, Color.White.copy(alpha = 0.08f), CircleShape),
            contentAlignment = Alignment.Center
        ) {
            if (artist.artworkUri != null) {
                AsyncImage(
                    model = artist.artworkUri,
                    contentDescription = artist.name,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
            } else {
                Icon(Icons.Rounded.Person, contentDescription = null, tint = ElectricBlue, modifier = Modifier.size(24.dp))
            }
        }
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = artist.name,
            color = Color.White,
            fontSize = 10.sp,
            fontWeight = FontWeight.Bold,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            textAlign = TextAlign.Center
        )
    }
}

@Composable
fun SongRowItem(
    song: ScannedSong,
    onClick: () -> Unit,
    onInfoClick: () -> Unit,
    index: Int = 1,
    isPlaying: Boolean = false
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(vertical = 12.dp, horizontal = 4.dp)
            .testTag("song_item_${song.id}"),
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Left side: Equalizer or Index Number
        Box(
            modifier = Modifier.width(36.dp),
            contentAlignment = Alignment.Center
        ) {
            if (isPlaying) {
                Row(
                    horizontalArrangement = Arrangement.spacedBy(2.dp),
                    verticalAlignment = Alignment.Bottom,
                    modifier = Modifier.height(14.dp)
                ) {
                    val infiniteTransition = rememberInfiniteTransition(label = "MiniEqualizer")
                    repeat(3) { i ->
                        val animHeight = infiniteTransition.animateFloat(
                            initialValue = 0.2f,
                            targetValue = 1.0f,
                            animationSpec = infiniteRepeatable(
                                animation = tween(
                                    durationMillis = 400 + i * 150,
                                    easing = FastOutSlowInEasing
                                ),
                                repeatMode = RepeatMode.Reverse
                            ),
                            label = "Wave$i"
                        )
                        Box(
                            modifier = Modifier
                                .width(3.dp)
                                .fillMaxHeight(animHeight.value)
                                .background(Color(0xFF25D366), RoundedCornerShape(1.5.dp))
                        )
                    }
                }
            } else {
                Text(
                    text = "$index",
                    color = Color.Gray,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Medium
                )
            }
        }

        Spacer(modifier = Modifier.width(12.dp))

        // Center side: Title and Subtitle
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = song.title,
                color = if (isPlaying) Color(0xFF25D366) else Color.White,
                fontSize = 14.sp,
                fontWeight = FontWeight.Normal,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Spacer(modifier = Modifier.height(4.dp))
            val artistStr = if (song.artist.isNullOrBlank() || song.artist == "<unknown>") "unknown" else song.artist
            val albumStr = if (song.album.isNullOrBlank() || song.album == "<unknown>") "unknown" else song.album
            Text(
                text = "<$artistStr>-<$albumStr>",
                color = Color.Gray,
                fontSize = 11.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }

        // Right side: Vertical More options (MoreVert)
        IconButton(
            onClick = onInfoClick,
            modifier = Modifier.size(36.dp)
        ) {
            Icon(
                imageVector = Icons.Rounded.MoreVert,
                contentDescription = "Options",
                tint = Color.Gray,
                modifier = Modifier.size(20.dp)
            )
        }
    }
}

// ==========================================
// NESTED BROWSER SONGS VIEW
// ==========================================
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NestedSongsListView(
    title: String,
    subtitle: String,
    songs: List<ScannedSong>,
    artworkUri: String?,
    onBack: () -> Unit,
    onTrackClicked: (ScannedSong) -> Unit,
    onTrackSpecsClicked: (ScannedSong) -> Unit
) {
    var query by remember { mutableStateOf("") }
    val filteredSongs = remember(songs, query) {
        if (query.isBlank()) songs else songs.filter {
            it.title.contains(query, ignoreCase = true) || 
            (it.artist?.contains(query, ignoreCase = true) ?: false)
        }
    }

    Column(modifier = Modifier.fillMaxSize()) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(
                onClick = onBack,
                modifier = Modifier
                    .background(Color.White.copy(alpha = 0.06f), CircleShape)
                    .size(36.dp)
                    .testTag("nested_back_btn")
            ) {
                Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = "Back", tint = Color.White, modifier = Modifier.size(18.dp))
            }
            Spacer(modifier = Modifier.width(12.dp))
            Column {
                Text(text = title, color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(text = subtitle, color = Color.Gray, fontSize = 10.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        OutlinedTextField(
            value = query,
            onValueChange = { query = it },
            placeholder = { Text("Filter inside...", color = Color.Gray, fontSize = 12.sp) },
            leadingIcon = { Icon(Icons.Rounded.Search, contentDescription = null, tint = ElectricBlue, modifier = Modifier.size(16.dp)) },
            colors = TextFieldDefaults.colors(
                focusedContainerColor = Color.White.copy(alpha = 0.04f),
                unfocusedContainerColor = Color.White.copy(alpha = 0.04f),
                focusedIndicatorColor = ElectricBlue.copy(alpha = 0.8f),
                unfocusedIndicatorColor = Color.White.copy(alpha = 0.08f),
                focusedTextColor = Color.White,
                unfocusedTextColor = Color.White
            ),
            shape = RoundedCornerShape(12.dp),
            singleLine = true,
            modifier = Modifier
                .fillMaxWidth()
                .height(48.dp)
        )

        Spacer(modifier = Modifier.height(14.dp))

        LazyColumn(
            contentPadding = PaddingValues(bottom = 110.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.fillMaxSize()
        ) {
            items(filteredSongs, key = { "nested_song_${it.id}" }) { song ->
                SongRowItem(
                    song = song,
                    onClick = { onTrackClicked(song) },
                    onInfoClick = { onTrackSpecsClicked(song) }
                )
            }
        }
    }
}

// ==========================================
// DETAIL DIALOG (SPECIFICATIONS)
// ==========================================
@Composable
fun TrackSpecDialog(track: ScannedSong, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Rounded.Info, contentDescription = null, tint = ElectricBlue)
                Spacer(modifier = Modifier.width(10.dp))
                Text("Track Specifications", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
            }
        },
        text = {
            Column(
                verticalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                // Large Art
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(120.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(Color.White.copy(alpha = 0.02f)),
                    contentAlignment = Alignment.Center
                ) {
                    AsyncImage(
                        model = track.artworkUri,
                        contentDescription = "Cover",
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                }

                Spacer(modifier = Modifier.height(4.dp))

                TrackSpecRow(label = "Title", value = track.title)
                TrackSpecRow(label = "Artist", value = track.artist ?: "Unknown Artist")
                TrackSpecRow(label = "Album", value = track.album ?: "Unknown Album")
                TrackSpecRow(label = "Duration", value = formatMusicDuration(track.duration))
                TrackSpecRow(label = "File Size", value = formatMusicSize(track.size))
                TrackSpecRow(label = "Added Date", value = formatMusicDate(track.dateAdded))
                TrackSpecRow(label = "Format", value = track.path.substringAfterLast(".").uppercase())
                TrackSpecRow(label = "Location", value = track.path)
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text("Dismiss", color = ElectricBlue, fontWeight = FontWeight.Bold)
            }
        },
        containerColor = Color(0xFF121212),
        shape = RoundedCornerShape(20.dp),
        modifier = Modifier.testTag("track_spec_dialog")
    )
}

@Composable
fun TrackSpecRow(label: String, value: String) {
    Column(modifier = Modifier.fillMaxWidth()) {
        Text(text = label, color = Color.Gray, fontSize = 10.sp, fontWeight = FontWeight.Bold)
        Text(
            text = value,
            color = Color.White,
            fontSize = 12.sp,
            fontWeight = FontWeight.Medium,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis
        )
    }
}

// ==========================================
// LOADING SKELETONS & EMPTY STATES
// ==========================================
@Composable
fun MusicSkeletonGroup() {
    Column(
        verticalArrangement = Arrangement.spacedBy(12.dp),
        modifier = Modifier.fillMaxSize()
    ) {
        // Hero art loader
        val infiniteTransition = rememberInfiniteTransition(label = "skeleton")
        val alpha by infiniteTransition.animateFloat(
            initialValue = 0.25f,
            targetValue = 0.6f,
            animationSpec = infiniteRepeatable(
                animation = tween(1000, easing = LinearEasing),
                repeatMode = RepeatMode.Reverse
            ),
            label = "alpha"
        )

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(150.dp)
                .clip(RoundedCornerShape(16.dp))
                .background(Color.White.copy(alpha = alpha))
        )

        Spacer(modifier = Modifier.height(8.dp))

        Text("Scanning acoustic environment...", color = Color.Gray, fontSize = 11.sp, fontWeight = FontWeight.Bold)

        // List load mock
        repeat(5) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(60.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(Color.White.copy(alpha = alpha))
            )
        }
    }
}

@Composable
fun MusicEmptySanctuaryState(onScan: () -> Unit) {
    Box(
        modifier = Modifier.fillMaxSize(),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.padding(32.dp)
        ) {
            Icon(
                imageVector = Icons.Rounded.LibraryMusic,
                contentDescription = "No Music",
                tint = RoyalPurple,
                modifier = Modifier.size(72.dp)
            )
            Spacer(modifier = Modifier.height(18.dp))
            Text(
                text = "Your Acoustic Sanctuary is Quiet",
                color = Color.White,
                fontSize = 18.sp,
                fontWeight = FontWeight.Black,
                textAlign = TextAlign.Center
            )
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = "Vidiopen luxury audio engine scanned your local storage, but no offline audio files were detected.",
                color = Color.Gray,
                fontSize = 12.sp,
                textAlign = TextAlign.Center,
                lineHeight = 18.sp
            )
            Spacer(modifier = Modifier.height(24.dp))
            GlassButton(
                text = "Rescan Environment",
                onClick = onScan,
                modifier = Modifier.testTag("rescan_empty_btn")
            )
        }
    }
}

// ==========================================
// FORMATTING HELPERS (MUSIC SPECIFIC)
// ==========================================
private fun formatMusicDuration(ms: Long): String {
    val totalSeconds = ms / 1000
    val seconds = totalSeconds % 60
    val minutes = (totalSeconds / 60) % 60
    val hours = totalSeconds / 3600
    return if (hours > 0) {
        String.format("%02d:%02d:%02d", hours, minutes, seconds)
    } else {
        String.format("%02d:%02d", minutes, seconds)
    }
}

private fun formatMusicSize(bytes: Long): String {
    if (bytes <= 0) return "0 B"
    val units = arrayOf("B", "KB", "MB", "GB", "TB")
    val digitGroups = (Math.log10(bytes.toDouble()) / Math.log10(1024.0)).toInt()
    return String.format("%.2f %s", bytes / Math.pow(1024.0, digitGroups.toDouble()), units[digitGroups])
}

private fun formatMusicDate(timestamp: Long): String {
    val sdf = java.text.SimpleDateFormat("MMM dd, yyyy", java.util.Locale.getDefault())
    return sdf.format(java.util.Date(timestamp * 1000))
}

// ==========================================
// FILES SCREEN (STORAGE ANALYZER)
// ==========================================
enum class StorageViewMode {
    DASHBOARD,
    LARGE_FILES,
    DUPLICATES,
    EMPTY_FOLDERS,
    RECENT_DOWNLOADS,
    CAPTURED_FRAMES
}

@Composable
fun FilesScreen(
    viewModel: MediaViewModel,
    mediaStoreViewModel: MediaStoreViewModel
) {
    val context = LocalContext.current
    val storageViewModel: StorageViewModel = androidx.lifecycle.viewmodel.compose.viewModel()
    
    val scannedVideos by mediaStoreViewModel.scannedVideos.collectAsState()
    val isAnalyzing by storageViewModel.isAnalyzing.collectAsState()
    val stats by storageViewModel.storageStats.collectAsState()
    val insights by storageViewModel.storageInsights.collectAsState()
    val largeVideos by storageViewModel.largeVideos.collectAsState()
    val duplicateGroups by storageViewModel.duplicateGroups.collectAsState()
    val emptyFolders by storageViewModel.emptyFolders.collectAsState()
    val pendingDeletion by storageViewModel.pendingDeletion.collectAsState()
    val undoCountdown by storageViewModel.undoCountdown.collectAsState()

    val capturedFrames by viewModel.capturedFrames.collectAsState()

    var activeViewMode by remember { mutableStateOf(StorageViewMode.DASHBOARD) }
    var sizeFilter by remember { mutableStateOf(500L * 1024 * 1024) } // 500MB, 1GB, 2GB, 5GB
    var itemToDelete by remember { mutableStateOf<Any?>(null) } // ScannedVideo or String (folder path)

    // Trigger analysis when scanned videos change
    LaunchedEffect(scannedVideos) {
        storageViewModel.analyzeStorage(scannedVideos)
    }

    val customBgUri by viewModel.customBackgroundUri.collectAsState()

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Transparent)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp)
        ) {
            Spacer(modifier = Modifier.height(60.dp))

            // Header block
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                if (activeViewMode != StorageViewMode.DASHBOARD) {
                    IconButton(
                        onClick = { activeViewMode = StorageViewMode.DASHBOARD },
                        modifier = Modifier
                            .padding(end = 12.dp)
                            .background(Color.White.copy(alpha = 0.05f), CircleShape)
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.ArrowBack,
                            contentDescription = "Back",
                            tint = Color.White
                        )
                    }
                }

                Column {
                    Text(
                        text = when (activeViewMode) {
                            StorageViewMode.DASHBOARD -> "Storage Center"
                            StorageViewMode.LARGE_FILES -> "Large File Finder"
                            StorageViewMode.DUPLICATES -> "Duplicate Detector"
                            StorageViewMode.EMPTY_FOLDERS -> "Empty Folder Finder"
                            StorageViewMode.RECENT_DOWNLOADS -> "Recent Downloads"
                            StorageViewMode.CAPTURED_FRAMES -> "Captured Frames"
                        },
                        fontSize = 28.sp,
                        fontWeight = FontWeight.Black,
                        color = Color.White
                    )
                    GlowText(
                        text = when (activeViewMode) {
                            StorageViewMode.DASHBOARD -> "Premium Media & Storage Optimizer"
                            StorageViewMode.LARGE_FILES -> "Easily locate and clean space hogs"
                            StorageViewMode.DUPLICATES -> "Find identical video copies"
                            StorageViewMode.EMPTY_FOLDERS -> "Clear empty directories instantly"
                            StorageViewMode.RECENT_DOWNLOADS -> "Check recent download files"
                            StorageViewMode.CAPTURED_FRAMES -> "Browse and manage saved video frames"
                        },
                        color = ElectricBlue,
                        fontSize = 13.sp
                    )
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            if (isAnalyzing) {
                // Elegant loading shimmer/placeholder
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .weight(1f),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        CircularProgressIndicator(
                            color = ElectricBlue,
                            strokeWidth = 4.dp,
                            modifier = Modifier.size(48.dp)
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        Text(
                            text = "Analyzing Storage Engine...",
                            color = Color.Gray,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Processing duplicates, files and empty folders...",
                            color = Color.DarkGray,
                            fontSize = 11.sp
                        )
                    }
                }
            } else {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                ) {
                    when (activeViewMode) {
                        StorageViewMode.DASHBOARD -> {
                            DashboardView(
                                stats = stats,
                                insights = insights,
                                largeVideos = largeVideos,
                                duplicateGroups = duplicateGroups,
                                emptyFolders = emptyFolders,
                                scannedVideos = scannedVideos,
                                capturedFramesCount = capturedFrames.size,
                                onNavigateTo = { activeViewMode = it }
                            )
                        }
                        StorageViewMode.LARGE_FILES -> {
                            LargeFilesView(
                                largeVideos = largeVideos,
                                sizeFilter = sizeFilter,
                                onSizeFilterChanged = { sizeFilter = it },
                                onPlayVideo = { video ->
                                    val mediaEntity = MediaStoreViewModel.run { video.toMediaEntity() }
                                    viewModel.playMedia(mediaEntity)
                                },
                                onDeleteVideo = { itemToDelete = it }
                            )
                        }
                        StorageViewMode.DUPLICATES -> {
                            DuplicatesView(
                                duplicateGroups = duplicateGroups,
                                onPlayVideo = { video ->
                                    val mediaEntity = MediaStoreViewModel.run { video.toMediaEntity() }
                                    viewModel.playMedia(mediaEntity)
                                },
                                onDeleteVideo = { itemToDelete = it }
                            )
                        }
                        StorageViewMode.EMPTY_FOLDERS -> {
                            EmptyFoldersView(
                                emptyFolders = emptyFolders,
                                onDeleteFolder = { itemToDelete = it }
                            )
                        }
                        StorageViewMode.RECENT_DOWNLOADS -> {
                            RecentDownloadsView(
                                scannedVideos = scannedVideos,
                                onPlayVideo = { video ->
                                    val mediaEntity = MediaStoreViewModel.run { video.toMediaEntity() }
                                    viewModel.playMedia(mediaEntity)
                                },
                                onDeleteVideo = { itemToDelete = it }
                            )
                        }
                        StorageViewMode.CAPTURED_FRAMES -> {
                            CapturedFramesView(
                                capturedFrames = capturedFrames,
                                onOpenFrame = { frame ->
                                    try {
                                        val file = java.io.File(frame.filePath)
                                        val uri = androidx.core.content.FileProvider.getUriForFile(context, "com.example.fileprovider", file)
                                        val intent = android.content.Intent(android.content.Intent.ACTION_VIEW).apply {
                                            setDataAndType(uri, "image/*")
                                            addFlags(android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                        }
                                        context.startActivity(intent)
                                    } catch (e: Exception) {
                                        Toast.makeText(context, "No app found to open images: ${e.localizedMessage}", Toast.LENGTH_SHORT).show()
                                    }
                                },
                                onShareFrame = { frame ->
                                    try {
                                        val file = java.io.File(frame.filePath)
                                        val uri = androidx.core.content.FileProvider.getUriForFile(context, "com.example.fileprovider", file)
                                        val intent = android.content.Intent(android.content.Intent.ACTION_SEND).apply {
                                            type = "image/*"
                                            putExtra(android.content.Intent.EXTRA_STREAM, uri)
                                            addFlags(android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                        }
                                        context.startActivity(android.content.Intent.createChooser(intent, "Share Captured Frame"))
                                    } catch (e: Exception) {
                                        Toast.makeText(context, "Sharing failed: ${e.localizedMessage}", Toast.LENGTH_SHORT).show()
                                    }
                                },
                                onDeleteFrame = { frame ->
                                    viewModel.deleteCapturedFrame(frame)
                                    Toast.makeText(context, "Deleted captured frame", Toast.LENGTH_SHORT).show()
                                }
                            )
                        }
                    }
                }
            }
        }

        // Deletion Confirmation Dialog
        itemToDelete?.let { item ->
            AlertDialog(
                onDismissRequest = { itemToDelete = null },
                title = {
                    Column {
                        Text(
                            text = "Confirm Deletion",
                            color = Color.White,
                            fontWeight = FontWeight.Black
                        )
                        Text(
                            text = "This action is safe & supports 5-second undo",
                            color = ElectricBlue,
                            fontSize = 11.sp
                        )
                    }
                },
                text = {
                    Column {
                        Text(
                            text = "Are you sure you want to delete this?",
                            color = Color.White,
                            fontSize = 14.sp
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        when (item) {
                            is ScannedVideo -> {
                                Text(
                                    text = "Video: ${item.title}",
                                    color = Color.Gray,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "Size: ${MediaStoreViewModel.formatSize(item.size)}",
                                    color = Color.Gray,
                                    fontSize = 11.sp
                                )
                                Text(
                                    text = "Path: ${item.path}",
                                    color = Color.DarkGray,
                                    fontSize = 10.sp,
                                    maxLines = 2,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                            is String -> {
                                Text(
                                    text = "Folder: ${File(item).name}",
                                    color = Color.Gray,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "Path: $item",
                                    color = Color.DarkGray,
                                    fontSize = 10.sp,
                                    maxLines = 2,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        }
                    }
                },
                confirmButton = {
                    Button(
                        onClick = {
                            when (item) {
                                is ScannedVideo -> storageViewModel.requestDeleteVideo(item)
                                is String -> storageViewModel.requestDeleteFolder(item)
                            }
                            itemToDelete = null
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color.Red)
                    ) {
                        Text("Delete", color = Color.White, fontWeight = FontWeight.Bold)
                    }
                },
                dismissButton = {
                    TextButton(onClick = { itemToDelete = null }) {
                        Text("Cancel", color = Color.Gray)
                    }
                },
                containerColor = Color(0xFF121212)
            )
        }

        // Undo Overlay Banner
        pendingDeletion?.let { deletion ->
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .align(Alignment.BottomCenter)
                    .padding(bottom = 100.dp, start = 16.dp, end = 16.dp)
            ) {
                GlassCard(
                    cornerRadius = 16.dp,
                    borderWidth = 1.dp,
                    glowing = true,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = when (deletion) {
                                    is DeletionItem.Video -> "Deleting video..."
                                    is DeletionItem.Folder -> "Deleting empty folder..."
                                },
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = when (deletion) {
                                    is DeletionItem.Video -> deletion.video.title
                                    is DeletionItem.Folder -> File(deletion.path).name
                                },
                                color = Color.Gray,
                                fontSize = 11.sp,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            // Countdown progress bar
                            LinearProgressIndicator(
                                progress = { undoCountdown / 5f },
                                color = ElectricBlue,
                                trackColor = Color.White.copy(alpha = 0.1f),
                                modifier = Modifier
                                    .fillMaxWidth(0.85f)
                                    .height(3.dp)
                                    .clip(RoundedCornerShape(2.dp))
                            )
                        }
                        GlassButton(
                            onClick = { storageViewModel.undoDeletion() },
                            text = "UNDO",
                            glowColor = ElectricBlue,
                            cornerRadius = 12.dp,
                            modifier = Modifier.height(40.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun DashboardView(
    stats: StorageStats,
    insights: StorageInsights,
    largeVideos: List<ScannedVideo>,
    duplicateGroups: List<DuplicateGroup>,
    emptyFolders: List<String>,
    scannedVideos: List<ScannedVideo>,
    capturedFramesCount: Int,
    onNavigateTo: (StorageViewMode) -> Unit
) {
    val usedPercent = if (stats.totalStorage > 0) stats.usedStorage.toFloat() / stats.totalStorage.toFloat() else 0f
    val sweepAngle = 270f * usedPercent
    val animatedSweepAngle by animateFloatAsState(
        targetValue = sweepAngle,
        animationSpec = tween(durationMillis = 1000, easing = FastOutSlowInEasing),
        label = "MainGaugeSweep"
    )

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(bottom = 120.dp),
        verticalArrangement = Arrangement.spacedBy(20.dp)
    ) {
        // 1. Storage circular gauge indicators
        item {
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "Device Storage Hub",
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp
                    )
                    Spacer(modifier = Modifier.height(16.dp))

                    if (stats.sdCardAvailable) {
                        // Dual side-by-side circular indicators for Internal vs SD Card
                        val intUsedPercent = if (stats.totalInternal > 0) stats.usedInternal.toFloat() / stats.totalInternal.toFloat() else 0f
                        val sdUsedPercent = if (stats.totalSdCard > 0) stats.usedSdCard.toFloat() / stats.totalSdCard.toFloat() else 0f

                        val animIntSweep by animateFloatAsState(
                            targetValue = 270f * intUsedPercent,
                            animationSpec = tween(durationMillis = 1000, easing = FastOutSlowInEasing),
                            label = "InternalGauge"
                        )
                        val animSdSweep by animateFloatAsState(
                            targetValue = 270f * sdUsedPercent,
                            animationSpec = tween(durationMillis = 1000, easing = FastOutSlowInEasing),
                            label = "SdGauge"
                        )

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceEvenly,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            // Internal
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Box(contentAlignment = Alignment.Center, modifier = Modifier.size(110.dp)) {
                                    Canvas(modifier = Modifier.size(90.dp)) {
                                        drawArc(
                                            color = Color.White.copy(alpha = 0.05f),
                                            startAngle = 135f,
                                            sweepAngle = 270f,
                                            useCenter = false,
                                            style = Stroke(width = 8.dp.toPx(), cap = StrokeCap.Round)
                                        )
                                        drawArc(
                                            brush = Brush.sweepGradient(listOf(ElectricBlue, RoyalPurple, ElectricBlue)),
                                            startAngle = 135f,
                                            sweepAngle = animIntSweep,
                                            useCenter = false,
                                            style = Stroke(width = 8.dp.toPx(), cap = StrokeCap.Round)
                                        )
                                    }
                                    Text("${(intUsedPercent * 100).toInt()}%", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Black)
                                }
                                Spacer(modifier = Modifier.height(4.dp))
                                Text("Internal", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                Text(
                                    text = "${MediaStoreViewModel.formatSize(stats.usedInternal)} / ${MediaStoreViewModel.formatSize(stats.totalInternal)}",
                                    color = Color.Gray,
                                    fontSize = 10.sp
                                )
                            }

                            // SD Card
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Box(contentAlignment = Alignment.Center, modifier = Modifier.size(110.dp)) {
                                    Canvas(modifier = Modifier.size(90.dp)) {
                                        drawArc(
                                            color = Color.White.copy(alpha = 0.05f),
                                            startAngle = 135f,
                                            sweepAngle = 270f,
                                            useCenter = false,
                                            style = Stroke(width = 8.dp.toPx(), cap = StrokeCap.Round)
                                        )
                                        drawArc(
                                            brush = Brush.sweepGradient(listOf(RoyalPurple, ElectricBlue, RoyalPurple)),
                                            startAngle = 135f,
                                            sweepAngle = animSdSweep,
                                            useCenter = false,
                                            style = Stroke(width = 8.dp.toPx(), cap = StrokeCap.Round)
                                        )
                                    }
                                    Text("${(sdUsedPercent * 100).toInt()}%", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Black)
                                }
                                Spacer(modifier = Modifier.height(4.dp))
                                Text("SD Card", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                Text(
                                    text = "${MediaStoreViewModel.formatSize(stats.usedSdCard)} / ${MediaStoreViewModel.formatSize(stats.totalSdCard)}",
                                    color = Color.Gray,
                                    fontSize = 10.sp
                                )
                            }
                        }
                    } else {
                        // Large circular indicator for total internal storage
                        Box(
                            contentAlignment = Alignment.Center,
                            modifier = Modifier.size(150.dp)
                        ) {
                            Canvas(modifier = Modifier.size(130.dp)) {
                                drawArc(
                                    color = Color.White.copy(alpha = 0.05f),
                                    startAngle = 135f,
                                    sweepAngle = 270f,
                                    useCenter = false,
                                    style = Stroke(width = 12.dp.toPx(), cap = StrokeCap.Round)
                                )
                                drawArc(
                                    brush = Brush.sweepGradient(
                                        colors = listOf(ElectricBlue, RoyalPurple, ElectricBlue)
                                    ),
                                    startAngle = 135f,
                                    sweepAngle = animatedSweepAngle,
                                    useCenter = false,
                                    style = Stroke(width = 12.dp.toPx(), cap = StrokeCap.Round)
                                )
                            }
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text("${(usedPercent * 100).toInt()}%", color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.Black)
                                Text("Used Space", color = Color.Gray, fontSize = 11.sp)
                            }
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "${MediaStoreViewModel.formatSize(stats.usedStorage)} used of ${MediaStoreViewModel.formatSize(stats.totalStorage)}",
                            color = Color.White,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Detailed Legend with dynamic storage partitions
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceEvenly
                    ) {
                        LegendItem("Videos", MediaStoreViewModel.formatSize(insights.totalVideoSize), ElectricBlue)
                        LegendItem("Free Space", MediaStoreViewModel.formatSize(stats.freeStorage), RoyalPurple)
                        LegendItem("Other Files", MediaStoreViewModel.formatSize(maxOf(0L, stats.usedStorage - insights.totalVideoSize)), Color.Gray)
                    }
                }
            }
        }

        // 2. Quick Actions Shortcuts
        item {
            Text(
                text = "Smart Storage Actions",
                color = Color.White,
                fontWeight = FontWeight.Bold,
                fontSize = 16.sp
            )
            Spacer(modifier = Modifier.height(10.dp))

            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                item {
                    QuickActionCard(
                        title = "Large Files",
                        subtitle = "${largeVideos.size} items detect",
                        icon = Icons.Rounded.Storage,
                        tint = Color(0xFF00D9FF),
                        onClick = { onNavigateTo(StorageViewMode.LARGE_FILES) }
                    )
                }
                item {
                    QuickActionCard(
                        title = "Duplicates",
                        subtitle = "${duplicateGroups.size} groups found",
                        icon = Icons.Rounded.FileCopy,
                        tint = Color(0xFFFF9800),
                        onClick = { onNavigateTo(StorageViewMode.DUPLICATES) }
                    )
                }
                item {
                    QuickActionCard(
                        title = "Empty Folders",
                        subtitle = "${emptyFolders.size} empty folders",
                        icon = Icons.Rounded.FolderOff,
                        tint = Color(0xFFFF2E93),
                        onClick = { onNavigateTo(StorageViewMode.EMPTY_FOLDERS) }
                    )
                }
                item {
                    // Filter recent downloads
                    val recentDownloadCount = scannedVideos.filter {
                        it.path.contains("Download", ignoreCase = true)
                    }.size
                    QuickActionCard(
                        title = "Downloads",
                        subtitle = "$recentDownloadCount downloaded",
                        icon = Icons.Rounded.Download,
                        tint = Color(0xFF00FFCC),
                        onClick = { onNavigateTo(StorageViewMode.RECENT_DOWNLOADS) }
                    )
                }
                item {
                    QuickActionCard(
                        title = "Captured Frames",
                        subtitle = "$capturedFramesCount frames",
                        icon = Icons.Rounded.PhotoCamera,
                        tint = Color(0xFF7C4DFF),
                        onClick = { onNavigateTo(StorageViewMode.CAPTURED_FRAMES) }
                    )
                }
            }
        }

        // 3. Storage Insights
        item {
            Text(
                text = "Storage Insights",
                color = Color.White,
                fontWeight = FontWeight.Bold,
                fontSize = 16.sp,
                modifier = Modifier.padding(top = 10.dp)
            )
            Spacer(modifier = Modifier.height(10.dp))
            Column(
                verticalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                InsightCardRow("Total Video Count", "${insights.totalVideoCount} files", Icons.Rounded.VideoLibrary, Color(0xFF00D9FF))
                InsightCardRow("Total Video Size", MediaStoreViewModel.formatSize(insights.totalVideoSize), Icons.Rounded.Storage, Color(0xFF00FFCC))
                InsightCardRow("Average Video Size", MediaStoreViewModel.formatSize(insights.averageVideoSize), Icons.Rounded.DataUsage, Color(0xFFFF9800))
                InsightCardRow("Largest Video", "${insights.largestVideo} (${MediaStoreViewModel.formatSize(insights.largestVideoSize)})", Icons.Rounded.Movie, Color(0xFFFF2E93))
                InsightCardRow("Largest Folder", "${insights.largestFolder} (${MediaStoreViewModel.formatSize(insights.largestFolderSize)})", Icons.Rounded.FolderSpecial, Color(0xFF7C4DFF))
            }
        }
    }
}

@Composable
fun QuickActionCard(
    title: String,
    subtitle: String,
    icon: ImageVector,
    tint: Color = ElectricBlue,
    onClick: () -> Unit
) {
    val interactionSource = remember { MutableInteractionSource() }
    val isPressed by interactionSource.collectIsPressedAsState()
    
    val scale by animateFloatAsState(
        targetValue = if (isPressed) 0.92f else 1.0f,
        animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessLow),
        label = "QuickActionScale"
    )

    Box(
        modifier = Modifier
            .width(130.dp)
            .height(120.dp)
            .scale(scale)
            .clip(RoundedCornerShape(16.dp))
            .clickable(
                interactionSource = interactionSource,
                indication = null,
                onClick = onClick
            )
    ) {
        GlassCard(
            cornerRadius = 16.dp,
            modifier = Modifier.fillMaxSize()
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(12.dp),
                verticalArrangement = Arrangement.SpaceBetween,
                horizontalAlignment = Alignment.Start
            ) {
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .background(tint.copy(alpha = 0.12f), CircleShape)
                        .border(1.dp, tint.copy(alpha = 0.25f), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = title,
                        tint = tint,
                        modifier = Modifier.size(18.dp)
                    )
                }
                Column {
                    Text(
                        text = title,
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp
                    )
                    Text(
                        text = subtitle,
                        color = Color.Gray,
                        fontSize = 10.sp
                    )
                }
            }
        }
    }
}

@Composable
fun InsightCardRow(
    label: String,
    value: String,
    icon: ImageVector,
    tint: Color = RoyalPurple
) {
    GlassCard(modifier = Modifier.fillMaxWidth()) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.weight(1f)
            ) {
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .background(tint.copy(alpha = 0.12f), CircleShape)
                        .border(1.5.dp, tint.copy(alpha = 0.25f), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = label,
                        tint = tint,
                        modifier = Modifier.size(18.dp)
                    )
                }
                Spacer(modifier = Modifier.width(12.dp))
                Text(
                    text = label,
                    color = Color.LightGray,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Medium
                )
            }
            Text(
                text = value,
                color = Color.White,
                fontWeight = FontWeight.Bold,
                fontSize = 13.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier
                    .weight(1f, fill = false)
                    .padding(start = 16.dp)
            )
        }
    }
}

@Composable
fun LargeFilesView(
    largeVideos: List<ScannedVideo>,
    sizeFilter: Long,
    onSizeFilterChanged: (Long) -> Unit,
    onPlayVideo: (ScannedVideo) -> Unit,
    onDeleteVideo: (ScannedVideo) -> Unit
) {
    val filteredList = remember(largeVideos, sizeFilter) {
        largeVideos.filter { it.size >= sizeFilter }
    }

    Column(modifier = Modifier.fillMaxSize()) {
        // Size filters Row
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            val sizes = listOf(
                500L * 1024 * 1024 to "500 MB+",
                1024L * 1024 * 1024 to "1 GB+",
                2L * 1024 * 1024 * 1024 to "2 GB+",
                5L * 1024 * 1024 * 1024 to "5 GB+"
            )
            sizes.forEach { (bytes, label) ->
                val active = sizeFilter == bytes
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(12.dp))
                        .background(if (active) ElectricBlue else Color.White.copy(alpha = 0.05f))
                        .clickable { onSizeFilterChanged(bytes) }
                        .padding(horizontal = 12.dp, vertical = 6.dp)
                ) {
                    Text(
                        text = label,
                        color = if (active) Color.Black else Color.White,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        if (filteredList.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .weight(1f),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "No large files found matching this filter",
                    color = Color.Gray,
                    fontSize = 14.sp
                )
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .weight(1f),
                contentPadding = PaddingValues(bottom = 120.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(filteredList, key = { it.id }) { video ->
                    GlassCard(modifier = Modifier.fillMaxWidth()) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(60.dp)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(Color.DarkGray.copy(alpha = 0.3f))
                                    .clickable { onPlayVideo(video) }
                            ) {
                                AsyncImage(
                                    model = video.thumbnailUrl,
                                    contentDescription = video.title,
                                    contentScale = ContentScale.Crop,
                                    modifier = Modifier.fillMaxSize()
                                )
                                Icon(
                                    imageVector = Icons.Rounded.PlayArrow,
                                    contentDescription = "Preview",
                                    tint = Color.White,
                                    modifier = Modifier.align(Alignment.Center)
                                )
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = video.title,
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Text(
                                    text = "Size: ${MediaStoreViewModel.formatSize(video.size)}",
                                    color = ElectricBlue,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "Path: ${video.path}",
                                    color = Color.Gray,
                                    fontSize = 9.sp,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                            IconButton(
                                onClick = { onDeleteVideo(video) }
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.Delete,
                                    contentDescription = "Delete",
                                    tint = Color.Red.copy(alpha = 0.8f)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun DuplicatesView(
    duplicateGroups: List<DuplicateGroup>,
    onPlayVideo: (ScannedVideo) -> Unit,
    onDeleteVideo: (ScannedVideo) -> Unit
) {
    if (duplicateGroups.isEmpty()) {
        Box(
            modifier = Modifier.fillMaxSize(),
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(
                    imageVector = Icons.Rounded.CheckCircleOutline,
                    contentDescription = "Clean",
                    tint = ElectricBlue,
                    modifier = Modifier.size(48.dp)
                )
                Spacer(modifier = Modifier.height(12.dp))
                Text(
                    text = "Zero Duplicates Found!",
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp
                )
                Text(
                    text = "Your library is clean and perfectly optimized.",
                    color = Color.Gray,
                    fontSize = 12.sp
                )
            }
        }
    } else {
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(bottom = 120.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            items(duplicateGroups) { group ->
                GlassCard(modifier = Modifier.fillMaxWidth()) {
                    Column {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = "Duplicate Set",
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp
                                )
                                Text(
                                    text = "File size: ${MediaStoreViewModel.formatSize(group.size)}",
                                    color = ElectricBlue,
                                    fontSize = 11.sp
                                )
                            }
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(ElectricBlue.copy(alpha = 0.1f))
                                    .padding(horizontal = 8.dp, vertical = 4.dp)
                            ) {
                                Text(
                                    text = "${group.videos.size} copies",
                                    color = ElectricBlue,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        group.videos.forEach { video ->
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp)
                                    .background(Color.White.copy(alpha = 0.02f), RoundedCornerShape(8.dp))
                                    .padding(8.dp)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(40.dp)
                                        .clip(RoundedCornerShape(6.dp))
                                        .background(Color.DarkGray)
                                        .clickable { onPlayVideo(video) }
                                ) {
                                    AsyncImage(
                                        model = video.thumbnailUrl,
                                        contentDescription = video.title,
                                        contentScale = ContentScale.Crop,
                                        modifier = Modifier.fillMaxSize()
                                    )
                                    Icon(
                                        imageVector = Icons.Rounded.PlayArrow,
                                        contentDescription = "Play",
                                        tint = Color.White,
                                        modifier = Modifier.align(Alignment.Center)
                                    )
                                }
                                Spacer(modifier = Modifier.width(10.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = video.title,
                                        color = Color.White,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    Text(
                                        text = video.path,
                                        color = Color.Gray,
                                        fontSize = 9.sp,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                                IconButton(
                                    onClick = { onDeleteVideo(video) },
                                    modifier = Modifier.size(24.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Rounded.Delete,
                                        contentDescription = "Delete copy",
                                        tint = Color.Red.copy(alpha = 0.8f),
                                        modifier = Modifier.size(16.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun EmptyFoldersView(
    emptyFolders: List<String>,
    onDeleteFolder: (String) -> Unit
) {
    if (emptyFolders.isEmpty()) {
        Box(
            modifier = Modifier.fillMaxSize(),
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(
                    imageVector = Icons.Rounded.FolderSpecial,
                    contentDescription = "Clean",
                    tint = ElectricBlue,
                    modifier = Modifier.size(48.dp)
                )
                Spacer(modifier = Modifier.height(12.dp))
                Text(
                    text = "No Empty Folders Found",
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp
                )
                Text(
                    text = "All folder hierarchies contain active media resources.",
                    color = Color.Gray,
                    fontSize = 12.sp
                )
            }
        }
    } else {
        Column(modifier = Modifier.fillMaxSize()) {
            Text(
                text = "The following directories contain no recognized media files:",
                color = Color.Gray,
                fontSize = 11.sp,
                modifier = Modifier.padding(bottom = 12.dp)
            )

            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .weight(1f),
                contentPadding = PaddingValues(bottom = 120.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(emptyFolders, key = { it }) { path ->
                    val name = File(path).name
                    GlassCard(modifier = Modifier.fillMaxWidth()) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                                Box(
                                    modifier = Modifier
                                        .size(42.dp)
                                        .background(Color.White.copy(alpha = 0.05f), RoundedCornerShape(10.dp)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Rounded.FolderOff,
                                        contentDescription = name,
                                        tint = Color.Red.copy(alpha = 0.8f)
                                    )
                                }
                                Spacer(modifier = Modifier.width(12.dp))
                                Column {
                                    Text(
                                        text = name,
                                        color = Color.White,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 14.sp
                                    )
                                    Text(
                                        text = path,
                                        color = Color.Gray,
                                        fontSize = 10.sp,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                            }
                            IconButton(
                                onClick = { onDeleteFolder(path) }
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.Delete,
                                    contentDescription = "Delete empty folder",
                                    tint = Color.Red
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun RecentDownloadsView(
    scannedVideos: List<ScannedVideo>,
    onPlayVideo: (ScannedVideo) -> Unit,
    onDeleteVideo: (ScannedVideo) -> Unit
) {
    val downloadVideos = remember(scannedVideos) {
        scannedVideos.filter { it.path.contains("Download", ignoreCase = true) }
            .sortedByDescending { it.dateAdded }
    }

    if (downloadVideos.isEmpty()) {
        Box(
            modifier = Modifier.fillMaxSize(),
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(
                    imageVector = Icons.Rounded.DownloadDone,
                    contentDescription = "Downloads",
                    tint = ElectricBlue,
                    modifier = Modifier.size(48.dp)
                )
                Spacer(modifier = Modifier.height(12.dp))
                Text(
                    text = "No Downloaded Videos",
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp
                )
                Text(
                    text = "No video files found inside your Download directories.",
                    color = Color.Gray,
                    fontSize = 12.sp
                )
            }
        }
    } else {
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(bottom = 120.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(downloadVideos, key = { it.id }) { video ->
                GlassCard(modifier = Modifier.fillMaxWidth()) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Box(
                            modifier = Modifier
                                .size(60.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(Color.DarkGray.copy(alpha = 0.3f))
                                .clickable { onPlayVideo(video) }
                        ) {
                            AsyncImage(
                                model = video.thumbnailUrl,
                                contentDescription = video.title,
                                contentScale = ContentScale.Crop,
                                modifier = Modifier.fillMaxSize()
                              )
                              Icon(
                                  imageVector = Icons.Rounded.PlayArrow,
                                  contentDescription = "Preview",
                                  tint = Color.White,
                                  modifier = Modifier.align(Alignment.Center)
                              )
                          }
                          Spacer(modifier = Modifier.width(12.dp))
                          Column(modifier = Modifier.weight(1f)) {
                              Text(
                                  text = video.title,
                                  color = Color.White,
                                  fontWeight = FontWeight.Bold,
                                  fontSize = 13.sp,
                                  maxLines = 1,
                                  overflow = TextOverflow.Ellipsis
                              )
                              Text(
                                  text = MediaStoreViewModel.formatSize(video.size),
                                  color = ElectricBlue,
                                  fontSize = 11.sp,
                                  fontWeight = FontWeight.Bold
                              )
                              Text(
                                  text = video.path,
                                  color = Color.Gray,
                                  fontSize = 9.sp,
                                  maxLines = 1,
                                  overflow = TextOverflow.Ellipsis
                              )
                          }
                          IconButton(
                              onClick = { onDeleteVideo(video) }
                          ) {
                              Icon(
                                  imageVector = Icons.Rounded.Delete,
                                  contentDescription = "Delete download",
                                  tint = Color.Red.copy(alpha = 0.8f)
                              )
                          }
                      }
                  }
              }
          }
      }
  }

@Composable
fun StorageAnalysisCompactCard(onClick: () -> Unit) {
    GlassCard(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .testTag("storage_compact_card")
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Rounded.Storage, contentDescription = "Storage Analyzer", tint = ElectricBlue, modifier = Modifier.size(28.dp))
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Text("Storage Usage 66%", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    Text("84.2 GB used of 128 GB", color = Color.Gray, fontSize = 11.sp)
                }
            }
            Icon(Icons.Rounded.ChevronRight, contentDescription = "View details", tint = Color.Gray)
        }
    }
}

@Composable
fun LegendItem(label: String, size: String, color: Color) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier
                    .size(8.dp)
                    .background(color, CircleShape)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(label, color = Color.Gray, fontSize = 11.sp)
        }
        Text(size, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun FolderRow(name: String, count: String, size: String, icon: ImageVector) {
    GlassCard(modifier = Modifier.fillMaxWidth()) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(42.dp)
                        .background(Color.White.copy(alpha = 0.05f), RoundedCornerShape(10.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(imageVector = icon, contentDescription = name, tint = ElectricBlue)
                }
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Text(name, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    Text(count, color = Color.Gray, fontSize = 11.sp)
                }
            }
            Text(size, color = ElectricBlue, fontWeight = FontWeight.Bold, fontSize = 13.sp)
        }
    }
}

// ==========================================
// REDESIGNED SETTINGS SCREEN (ME SCREEN)
// ==========================================

@Composable
fun DownloadsDualIcon() {
    Box(modifier = Modifier.size(36.dp), contentAlignment = Alignment.Center) {
        Canvas(modifier = Modifier.size(28.dp)) {
            val w = size.width
            val h = size.height
            val path = androidx.compose.ui.graphics.Path().apply {
                moveTo(w * 0.2f, h * 0.6f)
                lineTo(w * 0.2f, h * 0.8f)
                lineTo(w * 0.8f, h * 0.8f)
                lineTo(w * 0.8f, h * 0.6f)
            }
            drawPath(
                path = path,
                color = Color(0xFF10B981),
                style = androidx.compose.ui.graphics.drawscope.Stroke(width = 3.dp.toPx(), cap = androidx.compose.ui.graphics.StrokeCap.Round)
            )
        }
        Icon(
            imageVector = Icons.Rounded.ArrowDownward,
            contentDescription = null,
            tint = Color.White,
            modifier = Modifier.size(18.dp).offset(y = (-3).dp)
        )
    }
}

@Composable
fun Mp3ConverterDualIcon() {
    Box(modifier = Modifier.size(36.dp), contentAlignment = Alignment.Center) {
        Icon(
            imageVector = Icons.Rounded.Headphones,
            contentDescription = null,
            tint = Color.White,
            modifier = Modifier.size(26.dp)
        )
        Icon(
            imageVector = Icons.Rounded.MusicNote,
            contentDescription = null,
            tint = Color(0xFF10B981),
            modifier = Modifier.size(12.dp).offset(y = 2.dp)
        )
    }
}

@Composable
fun PrivacyDualIcon() {
    Box(modifier = Modifier.size(36.dp), contentAlignment = Alignment.Center) {
        Icon(
            imageVector = Icons.Rounded.Folder,
            contentDescription = null,
            tint = Color(0xFF10B981),
            modifier = Modifier.size(28.dp)
        )
        Icon(
            imageVector = Icons.Rounded.Lock,
            contentDescription = null,
            tint = Color.White,
            modifier = Modifier.size(11.dp).offset(y = 2.dp)
        )
    }
}

@Composable
fun FileTransferDualIcon() {
    Box(modifier = Modifier.size(36.dp), contentAlignment = Alignment.Center) {
        Icon(
            imageVector = Icons.Rounded.Folder,
            contentDescription = null,
            tint = Color(0xFF10B981),
            modifier = Modifier.size(28.dp)
        )
        Icon(
            imageVector = Icons.Rounded.SwapHoriz,
            contentDescription = null,
            tint = Color.White,
            modifier = Modifier.size(14.dp).offset(y = 2.dp)
        )
    }
}

@Composable
fun MediaManageDualIcon() {
    Box(modifier = Modifier.size(36.dp), contentAlignment = Alignment.Center) {
        Icon(
            imageVector = Icons.Rounded.FolderOpen,
            contentDescription = null,
            tint = Color(0xFF10B981),
            modifier = Modifier.size(28.dp)
        )
        Canvas(modifier = Modifier.size(12.dp)) {
            val w = size.width
            val h = size.height
            drawLine(
                color = Color.White,
                start = androidx.compose.ui.geometry.Offset(w * 0.2f, h * 0.5f),
                end = androidx.compose.ui.geometry.Offset(w * 0.8f, h * 0.5f),
                strokeWidth = 2.dp.toPx()
            )
            drawLine(
                color = Color.White,
                start = androidx.compose.ui.geometry.Offset(w * 0.2f, h * 0.8f),
                end = androidx.compose.ui.geometry.Offset(w * 0.6f, h * 0.8f),
                strokeWidth = 2.dp.toPx()
            )
        }
    }
}

@Composable
fun TShirtIconComposed() {
    Canvas(modifier = Modifier.size(28.dp)) {
        val w = size.width
        val h = size.height
        val path = androidx.compose.ui.graphics.Path().apply {
            moveTo(w * 0.35f, h * 0.15f)
            quadraticTo(w * 0.5f, h * 0.25f, w * 0.65f, h * 0.15f)
            lineTo(w * 0.8f, h * 0.25f)
            lineTo(w * 0.95f, h * 0.45f)
            lineTo(w * 0.8f, h * 0.55f)
            lineTo(w * 0.75f, h * 0.5f)
            lineTo(w * 0.75f, h * 0.85f)
            lineTo(w * 0.25f, h * 0.85f)
            lineTo(w * 0.25f, h * 0.5f)
            lineTo(w * 0.2f, h * 0.55f)
            lineTo(w * 0.05f, h * 0.45f)
            lineTo(w * 0.2f, h * 0.25f)
            close()
        }
        drawPath(
            path = path,
            color = Color.White,
            style = androidx.compose.ui.graphics.drawscope.Fill
        )
        drawPath(
            path = path,
            color = Color(0xFF10B981),
            style = androidx.compose.ui.graphics.drawscope.Stroke(width = 2.dp.toPx())
        )
    }
}

@Composable
fun ThemeDualIcon() {
    Box(modifier = Modifier.size(36.dp), contentAlignment = Alignment.Center) {
        TShirtIconComposed()
    }
}

@Composable
fun HistoryDualIcon() {
    Box(modifier = Modifier.size(36.dp), contentAlignment = Alignment.Center) {
        Icon(
            imageVector = Icons.Rounded.History,
            contentDescription = null,
            tint = Color.White,
            modifier = Modifier.size(28.dp)
        )
        Box(
            modifier = Modifier
                .size(4.dp)
                .background(Color(0xFF10B981), CircleShape)
        )
    }
}

@Composable
fun AdFreeGiftDualIcon() {
    Box(modifier = Modifier.size(36.dp), contentAlignment = Alignment.Center) {
        Icon(
            imageVector = Icons.Rounded.Block,
            contentDescription = null,
            tint = Color(0xFFFF9800),
            modifier = Modifier.size(26.dp)
        )
        Text(
            text = "AD",
            color = Color.White,
            fontSize = 9.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.offset(y = (-1).dp)
        )
    }
}

@Composable
fun CleanDualIcon() {
    Box(modifier = Modifier.size(36.dp), contentAlignment = Alignment.Center) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            drawCircle(
                color = Color.White.copy(alpha = 0.3f),
                radius = size.minDimension / 2.2f,
                style = androidx.compose.ui.graphics.drawscope.Stroke(width = 1.5.dp.toPx())
              )
              drawCircle(
                  color = Color(0xFF10B981),
                  radius = size.minDimension / 2.2f,
                  style = androidx.compose.ui.graphics.drawscope.Stroke(
                      width = 2.5.dp.toPx(),
                      pathEffect = androidx.compose.ui.graphics.PathEffect.dashPathEffect(floatArrayOf(15f, 10f), 0f)
                  )
              )
          }
          Text(
              text = "87%",
              color = Color.White,
              fontSize = 9.sp,
              fontWeight = FontWeight.Bold
          )
      }
  }

@Composable
fun MeGridItem(
    title: String,
    showNewBadge: Boolean = false,
    badgeText: String? = null,
    icon: @Composable () -> Unit,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(vertical = 12.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Box(contentAlignment = Alignment.TopEnd) {
                icon()
                
                if (showNewBadge) {
                    Box(
                        modifier = Modifier
                            .offset(x = 12.dp, y = (-4).dp)
                            .background(Color(0xFFEF4444), RoundedCornerShape(4.dp))
                            .padding(horizontal = 4.dp, vertical = 1.dp)
                    ) {
                        Text(
                            text = badgeText ?: "NEW",
                            color = Color.White,
                            fontSize = 8.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = title,
                color = Color.White,
                fontSize = 12.sp,
                textAlign = TextAlign.Center,
                maxLines = 2,
                lineHeight = 14.sp
            )
        }
    }
}

@Composable
fun MeListRow(
    title: String,
    icon: ImageVector,
    onClick: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 16.dp, horizontal = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = icon,
                contentDescription = title,
                tint = Color.White.copy(alpha = 0.85f),
                modifier = Modifier.size(22.dp)
            )
            Spacer(modifier = Modifier.width(16.dp))
            Text(
                text = title,
                color = Color.White,
                fontSize = 15.sp,
                fontWeight = FontWeight.Medium,
                modifier = Modifier.weight(1f)
            )
            Icon(
                imageVector = Icons.Rounded.ChevronRight,
                contentDescription = null,
                tint = Color.Gray.copy(alpha = 0.5f),
                modifier = Modifier.size(18.dp)
            )
        }
        Divider(
            color = Color.White.copy(alpha = 0.08f),
            thickness = 0.5.dp,
            modifier = Modifier.padding(start = 42.dp)
        )
    }
}

@Composable
fun MadeInIndiaSection() {
    val infiniteTransition = rememberInfiniteTransition(label = "pulse_animation")
    
    // Smooth breathing scale animation
    val scale by infiniteTransition.animateFloat(
        initialValue = 0.95f,
        targetValue = 1.05f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 1800, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "scale"
    )

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center,
            modifier = Modifier
                .graphicsLayer(
                    scaleX = scale,
                    scaleY = scale,
                    clip = false
                )
                .background(
                    Brush.radialGradient(
                        colors = listOf(
                            Color(0xFFFF9933).copy(alpha = 0.12f), // Beautiful Saffron glow
                            Color(0xFF128807).copy(alpha = 0.12f), // Beautiful Green glow
                            Color.Transparent
                        )
                    )
                )
                .padding(horizontal = 20.dp, vertical = 10.dp)
        ) {
            // Elegant Vector Indian Flag
            Box(
                modifier = Modifier
                    .size(width = 24.dp, height = 16.dp)
                    .clip(RoundedCornerShape(2.dp))
                    .border(0.5.dp, Color.White.copy(alpha = 0.25f), RoundedCornerShape(2.dp))
            ) {
                Column(modifier = Modifier.fillMaxSize()) {
                    // Saffron Row
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxWidth()
                            .background(Color(0xFFFF9933))
                    )
                    // White Row with blue Ashoka Chakra
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxWidth()
                            .background(Color.White),
                        contentAlignment = Alignment.Center
                    ) {
                        Canvas(modifier = Modifier.size(4.dp)) {
                            drawCircle(
                                color = Color(0xFF000080),
                                radius = size.minDimension / 2f,
                                style = Stroke(width = 0.8f)
                            )
                        }
                    }
                    // Green Row
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxWidth()
                            .background(Color(0xFF128807))
                    )
                }
            }

            Spacer(modifier = Modifier.width(10.dp))

            // Premium bold letter-spaced text
            Text(
                text = "MADE IN INDIA",
                style = MaterialTheme.typography.labelSmall.copy(
                    fontWeight = FontWeight.ExtraBold,
                    letterSpacing = 2.5.sp,
                    fontSize = 11.sp
                ),
                color = Color.White.copy(alpha = 0.9f)
            )
        }
        
        Spacer(modifier = Modifier.height(4.dp))
        
        Text(
            text = "Vidiopen Luxury Edition",
            color = Color.Gray,
            style = MaterialTheme.typography.bodySmall.copy(
                fontSize = 9.sp,
                letterSpacing = 1.2.sp
            )
        )
    }
}

@Composable
fun SettingsScreen(
    viewModel: MediaViewModel,
    onNavigateToSection: (String) -> Unit = {},
    onOpenVault: () -> Unit = {}
) {
    val customBgUri by viewModel.customBackgroundUri.collectAsState()
    val selectedThemeId by viewModel.selectedThemeId.collectAsState()
    val context = LocalContext.current
    val appLang by viewModel.appLanguage.collectAsState()

    // Dialog state controllers
    var showDownloadsDialog by remember { mutableStateOf(false) }
    var showMp3ConverterDialog by remember { mutableStateOf(false) }
    var showPinDialog by remember { mutableStateOf(false) }
    var showPrivacyDialog by remember { mutableStateOf(false) }
    var showThemeDialog by remember { mutableStateOf(false) }
    var showHistoryDialog by remember { mutableStateOf(false) }
    var showCleanDialog by remember { mutableStateOf(false) }
    var showSettingsDetailsDialog by remember { mutableStateOf(false) }
    var showRecycleBinDialog by remember { mutableStateOf(false) }
    var showRateUsDialog by remember { mutableStateOf(false) }
    var showAboutDialog by remember { mutableStateOf(false) }

    // Logic and data models
    val allMedia by viewModel.allMedia.collectAsState()
    val watchHistory by viewModel.watchHistory.collectAsState()
    val conversionState by viewModel.conversionState.collectAsState()

    var isVaultUnlocked by remember { mutableStateOf(false) }
    var enteredPin by remember { mutableStateOf("") }
    var pinError by remember { mutableStateOf(false) }
    var savedPin by remember { mutableStateOf("1234") } // Default PIN
    var isSettingNewPin by remember { mutableStateOf(false) }

    // Theme selector
    val imagePickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri ->
        if (uri != null) {
            viewModel.setCustomBackgroundUri(uri.toString())
            viewModel.setSelectedThemeId("custom_image")
        }
    }

    // Support Email Composer Intent
    fun sendSupportEmail() {
        try {
            val intent = Intent(Intent.ACTION_SENDTO).apply {
                data = Uri.parse("mailto:")
                putExtra(Intent.EXTRA_EMAIL, arrayOf("abhayshukla8498@gmail.com"))
                putExtra(Intent.EXTRA_SUBJECT, "Vidiopen Pro - Support Request")
                putExtra(Intent.EXTRA_TEXT, "Hello Developer,\n\nI am using Vidiopen Pro Luxury Edition...")
            }
            context.startActivity(intent)
        } catch (e: Exception) {
            android.widget.Toast.makeText(context, "No email app found! Email developer at abhayshukla8498@gmail.com", android.widget.Toast.LENGTH_LONG).show()
        }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Transparent)
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 48.dp, bottom = 120.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // 1. GRID SECTION (3 Columns, 9 items)
        item {
            Column(
                modifier = Modifier.fillMaxWidth()
            ) {
                // Row 1
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Box(modifier = Modifier.weight(1f)) {
                        MeGridItem(
                            title = if (appLang == "hi") "डाउनलोड" else "Downloads",
                            icon = { DownloadsDualIcon() }
                        ) {
                            showDownloadsDialog = true
                        }
                    }
                    Box(modifier = Modifier.weight(1f)) {
                        MeGridItem(
                            title = if (appLang == "hi") "एमपी3 कनवर्टर" else "MP3 Converter",
                            icon = { Mp3ConverterDualIcon() }
                        ) {
                            showMp3ConverterDialog = true
                        }
                    }
                    Box(modifier = Modifier.weight(1f)) {
                        MeGridItem(
                            title = if (appLang == "hi") "गोपनीयता" else "Privacy",
                            icon = { PrivacyDualIcon() }
                        ) {
                            showPinDialog = true
                        }
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Row 2
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Box(modifier = Modifier.weight(1f)) {
                        MeGridItem(
                            title = if (appLang == "hi") "फ़ाइल ट्रांसफर" else "File Transfer",
                            showNewBadge = true,
                            icon = { FileTransferDualIcon() }
                        ) {
                            onNavigateToSection("wifi_transfer")
                        }
                    }
                    Box(modifier = Modifier.weight(1f)) {
                        MeGridItem(
                            title = if (appLang == "hi") "मीडिया प्रबंधन" else "Media Manage",
                            icon = { MediaManageDualIcon() }
                        ) {
                            onNavigateToSection("files")
                        }
                    }
                    Box(modifier = Modifier.weight(1f)) {
                        MeGridItem(
                            title = if (appLang == "hi") "थीम" else "Theme",
                            icon = { ThemeDualIcon() }
                        ) {
                            showThemeDialog = true
                        }
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Row 3
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Box(modifier = Modifier.weight(1f)) {
                        MeGridItem(
                            title = if (appLang == "hi") "इतिहास" else "History",
                            icon = { HistoryDualIcon() }
                        ) {
                            showHistoryDialog = true
                        }
                    }
                    Box(modifier = Modifier.weight(1f)) {
                        MeGridItem(
                            title = if (appLang == "hi") "साफ़ करें" else "Clean",
                            showNewBadge = true,
                            icon = { CleanDualIcon() }
                        ) {
                            showCleanDialog = true
                        }
                    }
                }
            }
        }

        // 3. LIST SECTION
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color.Black)
            ) {
                MeListRow(
                    title = if (appLang == "hi") "सेटिंग्स (Settings)" else "Settings",
                    icon = Icons.Rounded.Settings
                ) {
                    showSettingsDetailsDialog = true
                }

                MeListRow(
                    title = if (appLang == "hi") "रीसायकल बिन (Recycle Bin)" else "Recycle Bin",
                    icon = Icons.Rounded.DeleteOutline
                ) {
                    showRecycleBinDialog = true
                }

                MeListRow(
                    title = if (appLang == "hi") "वीआईपी पाने के लिए साझा करें" else "Share to get VIP",
                    icon = Icons.Rounded.Share
                ) {
                    try {
                        val shareIntent = Intent(Intent.ACTION_SEND).apply {
                            type = "text/plain"
                            putExtra(Intent.EXTRA_SUBJECT, "Vidiopen Pro")
                            putExtra(Intent.EXTRA_TEXT, "Hey, download Vidiopen Pro Luxury Edition - the best private secure player! Offline-only and zero tracker ads!")
                        }
                        context.startActivity(Intent.createChooser(shareIntent, "Share with friends"))
                    } catch (e: Exception) {
                        android.widget.Toast.makeText(context, "Sharing not supported on this device.", android.widget.Toast.LENGTH_SHORT).show()
                    }
                }

                MeListRow(
                    title = if (appLang == "hi") "सहायता और प्रतिक्रिया" else "Help & Feedback",
                    icon = Icons.Rounded.ChatBubbleOutline
                ) {
                    sendSupportEmail()
                }

                MeListRow(
                    title = if (appLang == "hi") "हमें रेट करें (Rate us)" else "Rate us",
                    icon = Icons.Rounded.ThumbUp
                ) {
                    showRateUsDialog = true
                }

                MeListRow(
                    title = if (appLang == "hi") "गोपनीयता नीति (Privacy Policy)" else "Privacy Policy",
                    icon = Icons.Rounded.Security
                ) {
                    showPrivacyDialog = true
                }

                MeListRow(
                    title = if (appLang == "hi") "इसके बारे में (About)" else "About",
                    icon = Icons.Rounded.Info
                ) {
                    showAboutDialog = true
                }
            }
        }

        item {
            MadeInIndiaSection()
        }
    }

    // ==========================================
    // INTERACTIVE DIALOGS IMPLEMENTATION
    // ==========================================

    // 1. DOWNLOADS DIALOG
    if (showDownloadsDialog) {
        val downloadedMedia = allMedia.filter { it.category == "Downloaded" || it.url.startsWith("file://") }
        androidx.compose.ui.window.Dialog(
            onDismissRequest = { showDownloadsDialog = false },
            properties = androidx.compose.ui.window.DialogProperties(
                usePlatformDefaultWidth = false,
                dismissOnBackPress = true,
                dismissOnClickOutside = false
            )
        ) {
            Surface(
                modifier = Modifier.fillMaxSize(),
                color = Color(0xFF070709)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .statusBarsPadding()
                        .navigationBarsPadding()
                ) {
                    // Header Bar
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(
                            onClick = { showDownloadsDialog = false },
                            modifier = Modifier.size(48.dp)
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Rounded.ArrowBack,
                                contentDescription = "Back",
                                tint = Color.White
                            )
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = if (appLang == "hi") "ऑफ़लाइन डाउनलोड" else "Offline Downloads",
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                fontSize = 18.sp
                            )
                            Text(
                                text = "Downloaded Library Files",
                                color = Color.Gray,
                                fontSize = 11.sp
                            )
                        }
                        
                        // Icon Badge
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .background(ElectricBlue.copy(alpha = 0.15f), CircleShape)
                                .border(1.dp, ElectricBlue.copy(alpha = 0.3f), CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.CloudDownload,
                                contentDescription = null,
                                tint = ElectricBlue,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }

                    // Divider
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(1.dp)
                            .background(Color.White.copy(alpha = 0.08f))
                    )

                    // Content
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        if (downloadedMedia.isEmpty()) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .weight(1f),
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.Center
                            ) {
                                Icon(Icons.Rounded.CloudDownload, contentDescription = null, tint = Color.Gray, modifier = Modifier.size(64.dp))
                                Spacer(modifier = Modifier.height(16.dp))
                                Text(
                                    text = if (appLang == "hi") "अभी तक कोई ऑफ़लाइन डाउनलोड नहीं है" else "No offline downloads yet",
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 16.sp
                                )
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(
                                    text = if (appLang == "hi") "आपके डाउनलोड या कनवर्ट किए गए गाने यहाँ दिखाई देंगे।" else "Your downloaded or converted items will appear here.",
                                    color = Color.Gray,
                                    fontSize = 12.sp,
                                    textAlign = TextAlign.Center,
                                    modifier = Modifier.padding(horizontal = 32.dp)
                                )
                            }
                        } else {
                            LazyColumn(
                                verticalArrangement = Arrangement.spacedBy(10.dp),
                                modifier = Modifier.fillMaxSize()
                            ) {
                                items(downloadedMedia) { video ->
                                    GlassCard(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clickable {
                                                viewModel.playMedia(video)
                                                showDownloadsDialog = false
                                            },
                                        cornerRadius = 14.dp
                                    ) {
                                        Row(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .padding(12.dp),
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Box(
                                                modifier = Modifier
                                                    .size(40.dp)
                                                    .background(ElectricBlue.copy(alpha = 0.1f), CircleShape),
                                                contentAlignment = Alignment.Center
                                            ) {
                                                Icon(
                                                    imageVector = Icons.Rounded.PlayArrow,
                                                    contentDescription = null,
                                                    tint = ElectricBlue,
                                                    modifier = Modifier.size(20.dp)
                                                )
                                            }
                                            Spacer(modifier = Modifier.width(12.dp))
                                            Column(modifier = Modifier.weight(1f)) {
                                                Text(
                                                    text = video.title,
                                                    color = Color.White,
                                                    fontSize = 14.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    maxLines = 1,
                                                    overflow = TextOverflow.Ellipsis
                                                )
                                                Spacer(modifier = Modifier.height(2.dp))
                                                Text(
                                                    text = if (appLang == "hi") "ऑफ़लाइन फ़ाइल • ${video.artist ?: "Unknown"}" else "Offline File • ${video.artist ?: "Unknown"}",
                                                    color = Color.Gray,
                                                    fontSize = 12.sp
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // 2. MP3 CONVERTER DIALOG
    if (showMp3ConverterDialog) {
        var selectedVideoIndex by remember { mutableStateOf(-1) }
        var dropdownExpanded by remember { mutableStateOf(false) }

        androidx.compose.ui.window.Dialog(
            onDismissRequest = { 
                showMp3ConverterDialog = false 
                viewModel.resetConversionState()
            },
            properties = androidx.compose.ui.window.DialogProperties(
                usePlatformDefaultWidth = false,
                dismissOnBackPress = true,
                dismissOnClickOutside = false
            )
        ) {
            Surface(
                modifier = Modifier.fillMaxSize(),
                color = Color(0xFF070709)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .statusBarsPadding()
                        .navigationBarsPadding()
                ) {
                    // Header Bar
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(
                            onClick = { 
                                showMp3ConverterDialog = false 
                                viewModel.resetConversionState()
                            },
                            modifier = Modifier.size(48.dp)
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Rounded.ArrowBack,
                                contentDescription = "Back",
                                tint = Color.White
                            )
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = if (appLang == "hi") "एमपी3 कनवर्टर" else "MP3 Converter",
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                fontSize = 18.sp
                            )
                            Text(
                                text = "Extract Audio Track",
                                color = Color.Gray,
                                fontSize = 11.sp
                            )
                        }
                        
                        // Icon Badge
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .background(RoyalPurple.copy(alpha = 0.15f), CircleShape)
                                .border(1.dp, RoyalPurple.copy(alpha = 0.3f), CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.Headphones,
                                contentDescription = null,
                                tint = RoyalPurple,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }

                    // Divider
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(1.dp)
                            .background(Color.White.copy(alpha = 0.08f))
                    )

                    // Content
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .verticalScroll(rememberScrollState())
                            .padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(16.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        when (val state = conversionState) {
                            is MediaConversionState.Idle -> {
                                GlassCard(
                                    modifier = Modifier.fillMaxWidth(),
                                    cornerRadius = 16.dp
                                ) {
                                    Column(
                                        modifier = Modifier.padding(16.dp),
                                        verticalArrangement = Arrangement.spacedBy(12.dp)
                                    ) {
                                        Text(
                                            text = if (appLang == "hi") "हाई-फिडेलिटी एमपी3 ऑडियो निकालने के लिए अपनी रिपॉजिटरी से किसी भी स्थानीय वीडियो फ़ाइल का चयन करें:" else "Select any local video file from your repository to extract a high-fidelity MP3 audio track:",
                                            color = Color.LightGray,
                                            fontSize = 13.sp,
                                            lineHeight = 20.sp
                                        )

                                        // Dropdown/Selector button
                                        Box(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .background(Color.White.copy(alpha = 0.05f), RoundedCornerShape(12.dp))
                                                .border(1.dp, Color.White.copy(alpha = 0.1f), RoundedCornerShape(12.dp))
                                                .clickable { dropdownExpanded = true }
                                                .padding(14.dp)
                                        ) {
                                            Row(
                                                modifier = Modifier.fillMaxWidth(),
                                                horizontalArrangement = Arrangement.SpaceBetween,
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                val currentText = if (selectedVideoIndex >= 0 && selectedVideoIndex < allMedia.size) {
                                                    allMedia[selectedVideoIndex].title
                                                } else {
                                                    if (appLang == "hi") "एक वीडियो चुनें..." else "Choose a video..."
                                                }
                                                Text(
                                                    text = currentText,
                                                    color = if (selectedVideoIndex >= 0) Color.White else Color.Gray,
                                                    fontSize = 13.sp,
                                                    maxLines = 1,
                                                    overflow = TextOverflow.Ellipsis,
                                                    modifier = Modifier.weight(1f)
                                                )
                                                Icon(
                                                    imageVector = if (dropdownExpanded) Icons.Rounded.ArrowDropUp else Icons.Rounded.ArrowDropDown,
                                                    contentDescription = null,
                                                    tint = Color.Gray
                                                )
                                            }

                                            DropdownMenu(
                                                expanded = dropdownExpanded,
                                                onDismissRequest = { dropdownExpanded = false },
                                                modifier = Modifier
                                                    .fillMaxWidth(0.85f)
                                                    .background(Color(0xFF101012))
                                                    .heightIn(max = 280.dp)
                                            ) {
                                                if (allMedia.isEmpty()) {
                                                    DropdownMenuItem(
                                                        text = { Text(if (appLang == "hi") "कोई वीडियो नहीं मिला" else "No videos found", color = Color.Gray, fontSize = 13.sp) },
                                                        onClick = { dropdownExpanded = false }
                                                    )
                                                } else {
                                                    allMedia.forEachIndexed { idx, m ->
                                                        DropdownMenuItem(
                                                            text = { 
                                                                Text(
                                                                    text = m.title, 
                                                                    color = Color.White, 
                                                                    fontSize = 13.sp, 
                                                                    maxLines = 1, 
                                                                    overflow = TextOverflow.Ellipsis
                                                                ) 
                                                            },
                                                            onClick = {
                                                                selectedVideoIndex = idx
                                                                dropdownExpanded = false
                                                            }
                                                        )
                                                    }
                                                }
                                            }
                                        }

                                        Spacer(modifier = Modifier.height(8.dp))

                                        Button(
                                            onClick = {
                                                if (selectedVideoIndex >= 0 && selectedVideoIndex < allMedia.size) {
                                                    val media = allMedia[selectedVideoIndex]
                                                    viewModel.convertVideoToMp3(
                                                        videoUrl = media.url,
                                                        title = media.title,
                                                        artist = media.artist ?: "Vidiopen Pro"
                                                    )
                                                } else {
                                                    android.widget.Toast.makeText(context, if (appLang == "hi") "कृपया पहले एक वीडियो फ़ाइल चुनें" else "Please select a video file first", android.widget.Toast.LENGTH_SHORT).show()
                                                }
                                            },
                                            modifier = Modifier.fillMaxWidth(),
                                            shape = RoundedCornerShape(12.dp),
                                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF10B981)),
                                            enabled = selectedVideoIndex >= 0
                                        ) {
                                            Text(
                                                text = if (appLang == "hi") "एमपी3 ऑडियो निकालें" else "Extract MP3 Audio",
                                                color = Color.Black,
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 14.sp
                                            )
                                        }
                                    }
                                }
                            }

                            is MediaConversionState.Converting -> {
                                Column(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 48.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    verticalArrangement = Arrangement.spacedBy(16.dp)
                                ) {
                                    CircularProgressIndicator(
                                        progress = state.progress,
                                        color = Color(0xFF10B981),
                                        trackColor = Color.White.copy(alpha = 0.1f),
                                        modifier = Modifier.size(56.dp)
                                    )
                                    Text(
                                        text = if (appLang == "hi") "कनवर्ट हो रहा है: ${(state.progress * 100).toInt()}%" else "Converting: ${(state.progress * 100).toInt()}%",
                                        color = Color.White,
                                        fontSize = 16.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(
                                        text = state.statusMessage,
                                        color = Color.Gray,
                                        fontSize = 12.sp,
                                        textAlign = TextAlign.Center
                                    )
                                }
                            }

                            is MediaConversionState.Success -> {
                                Column(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 48.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    verticalArrangement = Arrangement.spacedBy(16.dp)
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(72.dp)
                                            .background(Color(0xFF10B981).copy(alpha = 0.1f), CircleShape)
                                            .border(1.dp, Color(0xFF10B981).copy(alpha = 0.2f), CircleShape),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(
                                            imageVector = Icons.Rounded.CheckCircle,
                                            contentDescription = null,
                                            tint = Color(0xFF10B981),
                                            modifier = Modifier.size(36.dp)
                                        )
                                    }
                                    Text(
                                        text = if (appLang == "hi") "कनवर्ट पूरा हुआ!" else "Conversion Complete!",
                                        color = Color.White,
                                        fontSize = 18.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(
                                        text = state.fileName,
                                        color = Color.LightGray,
                                        fontSize = 13.sp,
                                        textAlign = TextAlign.Center,
                                        modifier = Modifier.padding(horizontal = 24.dp)
                                    )
                                    
                                    Button(
                                        onClick = {
                                            val newTrack = MediaEntity(
                                                id = "conv_${System.currentTimeMillis()}",
                                                title = state.fileName.substringBeforeLast("."),
                                                url = state.filePath,
                                                duration = 180000L,
                                                artist = "Converted MP3",
                                                thumbnailUrl = null,
                                                category = "Music"
                                            )
                                            viewModel.playMedia(newTrack)
                                            showMp3ConverterDialog = false
                                            viewModel.resetConversionState()
                                        },
                                        modifier = Modifier.fillMaxWidth().padding(top = 16.dp),
                                        shape = RoundedCornerShape(12.dp),
                                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF10B981))
                                    ) {
                                        Text(
                                            text = if (appLang == "hi") "एमपी3 स्ट्रीम चलाएं" else "Play MP3 Stream",
                                            color = Color.Black,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 14.sp
                                        )
                                    }
                                }
                            }

                            is MediaConversionState.Error -> {
                                Column(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 48.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    verticalArrangement = Arrangement.spacedBy(16.dp)
                                ) {
                                    Icon(Icons.Rounded.ErrorOutline, contentDescription = null, tint = Color.Red, modifier = Modifier.size(64.dp))
                                    Text(
                                        text = if (appLang == "hi") "निकालने में विफल" else "Extraction Failed",
                                        color = Color.Red,
                                        fontSize = 16.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(
                                        text = state.errorMessage,
                                        color = Color.Gray,
                                        fontSize = 12.sp,
                                        textAlign = TextAlign.Center
                                    )
                                    
                                    Button(
                                        onClick = { viewModel.resetConversionState() },
                                        modifier = Modifier.fillMaxWidth().padding(top = 16.dp),
                                        shape = RoundedCornerShape(12.dp),
                                        colors = ButtonDefaults.buttonColors(containerColor = Color.White.copy(alpha = 0.15f))
                                    ) {
                                        Text(
                                            text = if (appLang == "hi") "पुनः प्रयास करें" else "Try Again",
                                            color = Color.White,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 14.sp
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // 3. SECURE VAULT SECURED PIN DIALOG
    if (showPinDialog) {
        AlertDialog(
            onDismissRequest = { showPinDialog = false },
            containerColor = Color(0xFF0C0C0F),
            shape = RoundedCornerShape(24.dp),
            title = {
                Text(
                    text = if (isSettingNewPin) "Set New PIN" else "Vault Security PIN",
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp
                )
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = if (isSettingNewPin) "Enter a new 4-digit security PIN for your Vault:"
                               else "Enter 4-digit PIN to access private safe folders (Default: 1234):",
                        color = Color.LightGray,
                        fontSize = 12.sp
                    )

                    BasicTextField(
                        value = enteredPin,
                        onValueChange = {
                            if (it.length <= 4 && it.all { char -> char.isDigit() }) {
                                enteredPin = it
                            }
                        },
                        textStyle = androidx.compose.ui.text.TextStyle(
                            color = Color.White,
                            fontSize = 24.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 8.sp,
                            textAlign = TextAlign.Center
                        ),
                        cursorBrush = SolidColor(Color(0xFF10B981)),
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(Color.White.copy(alpha = 0.05f), RoundedCornerShape(12.dp))
                            .padding(16.dp),
                        singleLine = true
                    )

                    if (pinError) {
                        Text("Incorrect security PIN! Try again.", color = Color.Red, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (isSettingNewPin) {
                            if (enteredPin.length == 4) {
                                savedPin = enteredPin
                                isVaultUnlocked = true
                                isSettingNewPin = false
                                showPinDialog = false
                                onOpenVault()
                            } else {
                                pinError = true
                            }
                        } else {
                            if (enteredPin == savedPin) {
                                isVaultUnlocked = true
                                showPinDialog = false
                                pinError = false
                                onOpenVault()
                            } else {
                                pinError = true
                            }
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF10B981))
                ) {
                    Text("Confirm", color = Color.Black, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(
                    onClick = {
                        showPinDialog = false
                        isSettingNewPin = false
                    }
                ) {
                    Text("Cancel", color = Color.Gray)
                }
            }
        )
    }

    // 4. THEME SELECTION FULL SCREEN DIALOG
    if (showThemeDialog) {
        androidx.compose.ui.window.Dialog(
            onDismissRequest = { showThemeDialog = false },
            properties = androidx.compose.ui.window.DialogProperties(
                usePlatformDefaultWidth = false,
                dismissOnBackPress = true,
                dismissOnClickOutside = false
            )
        ) {
            Surface(
                modifier = Modifier.fillMaxSize(),
                color = Color(0xFF070709) // Deep high contrast dark background
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .statusBarsPadding()
                        .navigationBarsPadding()
                ) {
                    // Header Row
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(
                            onClick = { showThemeDialog = false },
                            modifier = Modifier.size(48.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.ArrowBack,
                                contentDescription = "Back",
                                tint = Color.White,
                                modifier = Modifier.size(24.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Text(
                            text = if (appLang == "hi") "थीम चुनें" else "Theme Selection",
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 20.sp,
                            modifier = Modifier.weight(1f)
                        )
                    }

                    // Content Area (Grid of options)
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(horizontal = 20.dp, vertical = 10.dp)
                            .verticalScroll(rememberScrollState()),
                        verticalArrangement = Arrangement.spacedBy(24.dp)
                    ) {
                        Text(
                            text = if (appLang == "hi") "आकर्षक कवर या कलर थीम प्रीसेट चुनें:" else "Choose a beautiful preset theme or customize with your gallery:",
                            color = Color.Gray,
                            fontSize = 14.sp,
                            lineHeight = 20.sp
                        )

                        // 2 Columns Grid
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(16.dp)
                        ) {
                            // Theme 1: Customize Theme (Top Left)
                            Column(
                                modifier = Modifier
                                    .weight(1f)
                                    .clickable {
                                        if (customBgUri.isNotEmpty() && selectedThemeId != "custom_image") {
                                            viewModel.setSelectedThemeId("custom_image")
                                        } else {
                                            imagePickerLauncher.launch("image/*")
                                        }
                                    },
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .aspectRatio(0.72f)
                                        .clip(RoundedCornerShape(16.dp))
                                        .background(Color(0xFF1E1E26))
                                        .border(
                                            width = if (selectedThemeId == "custom_image") 2.dp else 1.dp,
                                            color = if (selectedThemeId == "custom_image") Color(0xFF10B981) else Color.White.copy(alpha = 0.08f),
                                            shape = RoundedCornerShape(16.dp)
                                        ),
                                    contentAlignment = Alignment.Center
                                ) {
                                    if (customBgUri.isNotEmpty()) {
                                        coil.compose.AsyncImage(
                                            model = customBgUri,
                                            contentDescription = null,
                                            modifier = Modifier.fillMaxSize(),
                                            contentScale = androidx.compose.ui.layout.ContentScale.Crop,
                                            alpha = 0.45f
                                        )
                                    }

                                    // Custom visual: T-Shirt icon with "+" in the middle
                                    Column(
                                        horizontalAlignment = Alignment.CenterHorizontally,
                                        verticalArrangement = Arrangement.Center
                                    ) {
                                        // Draw beautiful clothing t-shirt shape
                                        Canvas(modifier = Modifier.size(64.dp)) {
                                            val w = size.width
                                            val h = size.height
                                            val path = Path().apply {
                                                moveTo(w * 0.4f, h * 0.25f)
                                                quadraticTo(w * 0.5f, h * 0.32f, w * 0.6f, h * 0.25f)
                                                lineTo(w * 0.8f, h * 0.32f)
                                                lineTo(w * 0.9f, h * 0.48f)
                                                lineTo(w * 0.78f, h * 0.55f)
                                                lineTo(w * 0.72f, h * 0.48f)
                                                lineTo(w * 0.72f, h * 0.85f)
                                                lineTo(w * 0.28f, h * 0.85f)
                                                lineTo(w * 0.28f, h * 0.48f)
                                                lineTo(w * 0.22f, h * 0.55f)
                                                lineTo(w * 0.1f, h * 0.48f)
                                                lineTo(w * 0.2f, h * 0.32f)
                                                close()
                                            }
                                            drawPath(path, Color.White.copy(alpha = 0.35f))
                                            
                                            val strokeWidth = 3.dp.toPx()
                                            val len = 12.dp.toPx()
                                            val cx = w / 2
                                            val cy = h * 0.58f
                                            drawLine(
                                                color = Color.White,
                                                start = Offset(cx - len / 2, cy),
                                                end = Offset(cx + len / 2, cy),
                                                strokeWidth = strokeWidth,
                                                cap = StrokeCap.Round
                                            )
                                            drawLine(
                                                color = Color.White,
                                                start = Offset(cx, cy - len / 2),
                                                end = Offset(cx, cy + len / 2),
                                                strokeWidth = strokeWidth,
                                                cap = StrokeCap.Round
                                            )
                                        }
                                        Spacer(modifier = Modifier.height(12.dp))
                                        Text(
                                            text = if (appLang == "hi") "गैलरी से चुनें" else "Choose Photo",
                                            color = Color.White.copy(alpha = 0.6f),
                                            fontSize = 12.sp,
                                            fontWeight = FontWeight.Medium
                                        )
                                    }

                                    // Selection badge
                                    if (selectedThemeId == "custom_image") {
                                        Box(
                                            modifier = Modifier
                                                .align(Alignment.BottomEnd)
                                                .padding(10.dp)
                                                .size(24.dp)
                                                .background(Color(0xFF10B981), CircleShape),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Icon(
                                                imageVector = Icons.Rounded.Check,
                                                contentDescription = "Selected",
                                                tint = Color.White,
                                                modifier = Modifier.size(16.dp)
                                            )
                                        }
                                    }
                                }
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(
                                    text = if (appLang == "hi") "कस्टमाइज़ थीम" else "Customize Theme",
                                    color = Color.White,
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.SemiBold
                                )
                            }

                            // Theme 2: Dark Colour (Top Right)
                            Column(
                                modifier = Modifier
                                    .weight(1f)
                                    .clickable {
                                        viewModel.setSelectedThemeId("dark_color")
                                    },
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .aspectRatio(0.72f)
                                        .clip(RoundedCornerShape(16.dp))
                                        .background(Color(0xFF0F172A))
                                        .border(
                                            width = if (selectedThemeId == "dark_color") 2.dp else 1.dp,
                                            color = if (selectedThemeId == "dark_color") Color(0xFF10B981) else Color.White.copy(alpha = 0.08f),
                                            shape = RoundedCornerShape(16.dp)
                                        )
                                ) {
                                    // Preview of Starry background inside card
                                    Canvas(modifier = Modifier.fillMaxSize()) {
                                        val w = size.width
                                        val h = size.height
                                        
                                        // Stars
                                        val starOffset = listOf(
                                            Offset(w * 0.2f, h * 0.15f),
                                            Offset(w * 0.5f, h * 0.25f),
                                            Offset(w * 0.8f, h * 0.12f),
                                            Offset(w * 0.35f, h * 0.4f),
                                            Offset(w * 0.7f, h * 0.35f)
                                        )
                                        starOffset.forEach { pos ->
                                            drawCircle(Color.White.copy(alpha = 0.6f), radius = 2f, center = pos)
                                        }
                                        
                                        // Diamond star
                                        val cx = w * 0.55f
                                        val cy = h * 0.15f
                                        val path = Path().apply {
                                            moveTo(cx, cy - 6f)
                                            lineTo(cx + 3f, cy - 1f)
                                            lineTo(cx + 6f, cy)
                                            lineTo(cx + 3f, cy + 1f)
                                            moveTo(cx, cy + 6f)
                                            lineTo(cx - 3f, cy + 1f)
                                            lineTo(cx - 6f, cy)
                                            lineTo(cx - 3f, cy - 1f)
                                            close()
                                        }
                                        drawPath(path, Color.White.copy(alpha = 0.85f))

                                        // Glowing green circle dome at bottom as shown in image
                                        drawCircle(
                                            color = Color(0xFF10B981).copy(alpha = 0.15f),
                                            radius = w * 0.5f,
                                            center = Offset(w * 0.6f, h * 1.1f)
                                        )
                                        drawCircle(
                                            color = Color(0xFF047857).copy(alpha = 0.25f),
                                            radius = w * 0.35f,
                                            center = Offset(w * 0.6f, h * 1.1f)
                                        )
                                    }

                                    // Selection badge
                                    if (selectedThemeId == "dark_color") {
                                        Box(
                                            modifier = Modifier
                                                .align(Alignment.BottomEnd)
                                                .padding(10.dp)
                                                .size(24.dp)
                                                .background(Color(0xFF10B981), CircleShape),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Icon(
                                                imageVector = Icons.Rounded.Check,
                                                contentDescription = "Selected",
                                                tint = Color.White,
                                                modifier = Modifier.size(16.dp)
                                            )
                                        }
                                    }
                                }
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(
                                    text = if (appLang == "hi") "डार्क कलर" else "Dark Colour",
                                    color = Color.White,
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.SemiBold
                                )
                            }
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(16.dp)
                        ) {
                            // Theme 3: Light Colour (Bottom Left)
                            Column(
                                modifier = Modifier
                                    .weight(1f)
                                    .clickable {
                                        viewModel.setSelectedThemeId("light_color")
                                    },
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .aspectRatio(0.72f)
                                        .clip(RoundedCornerShape(16.dp))
                                        .background(
                                            androidx.compose.ui.graphics.Brush.verticalGradient(
                                                colors = listOf(
                                                    Color(0xFFE8ECEF),
                                                    Color(0xFFF1F3F5),
                                                    Color(0xFFDFE4E8)
                                                )
                                            )
                                        )
                                        .border(
                                            width = if (selectedThemeId == "light_color") 2.dp else 1.dp,
                                            color = if (selectedThemeId == "light_color") Color(0xFF10B981) else Color.White.copy(alpha = 0.08f),
                                            shape = RoundedCornerShape(16.dp)
                                        )
                                ) {
                                    // Preview of Light background decoration
                                    Canvas(modifier = Modifier.fillMaxSize()) {
                                        drawCircle(
                                            color = Color(0xFFD0D7DE).copy(alpha = 0.4f),
                                            radius = size.width * 0.6f,
                                            center = Offset(size.width * 1.2f, size.height * 0.2f)
                                        )
                                        drawCircle(
                                            color = Color(0xFFE2E7EC).copy(alpha = 0.6f),
                                            radius = size.width * 0.7f,
                                            center = Offset(-size.width * 0.2f, size.height * 0.8f)
                                        )
                                    }

                                    // Selection badge
                                    if (selectedThemeId == "light_color") {
                                        Box(
                                            modifier = Modifier
                                                .align(Alignment.BottomEnd)
                                                .padding(10.dp)
                                                .size(24.dp)
                                                .background(Color(0xFF10B981), CircleShape),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Icon(
                                                imageVector = Icons.Rounded.Check,
                                                contentDescription = "Selected",
                                                tint = Color.White,
                                                modifier = Modifier.size(16.dp)
                                            )
                                        }
                                    }
                                }
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(
                                    text = if (appLang == "hi") "लाइट कलर" else "Light Colour",
                                    color = Color.White,
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.SemiBold
                                )
                            }

                            // Empty space block on bottom-right to align correctly since VIP is excluded
                            Spacer(modifier = Modifier.weight(1f))
                        }

                        if (selectedThemeId == "custom_image" && customBgUri.isNotEmpty()) {
                            Spacer(modifier = Modifier.height(8.dp))
                            Button(
                                onClick = {
                                    viewModel.setCustomBackgroundUri("")
                                    viewModel.setSelectedThemeId("dark_color")
                                    android.widget.Toast.makeText(context, "Custom background removed.", android.widget.Toast.LENGTH_SHORT).show()
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = Color.Red.copy(alpha = 0.8f)),
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(14.dp)
                            ) {
                                Text(
                                    text = if (appLang == "hi") "कस्टम वॉलपेपर हटाएं" else "Reset Custom Wallpaper",
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    // 5. PLAY HISTORY DIALOG
    if (showHistoryDialog) {
        androidx.compose.ui.window.Dialog(
            onDismissRequest = { showHistoryDialog = false },
            properties = androidx.compose.ui.window.DialogProperties(
                usePlatformDefaultWidth = false,
                dismissOnBackPress = true,
                dismissOnClickOutside = false
            )
        ) {
            Surface(
                modifier = Modifier.fillMaxSize(),
                color = Color(0xFF070709)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .statusBarsPadding()
                        .navigationBarsPadding()
                ) {
                    // Header Bar
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(
                            onClick = { showHistoryDialog = false },
                            modifier = Modifier.size(48.dp)
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Rounded.ArrowBack,
                                contentDescription = "Back",
                                tint = Color.White
                            )
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = if (appLang == "hi") "प्लेबैक इतिहास" else "Watch History",
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                fontSize = 18.sp
                            )
                            Text(
                                text = "Your recent playbacks",
                                color = Color.Gray,
                                fontSize = 11.sp
                            )
                        }
                        
                        // Clear option as text button on the right
                        if (watchHistory.isNotEmpty()) {
                            TextButton(
                                onClick = {
                                    viewModel.clearWatchHistory()
                                    android.widget.Toast.makeText(context, "History cleared", android.widget.Toast.LENGTH_SHORT).show()
                                }
                            ) {
                                Text(
                                    text = if (appLang == "hi") "साफ़ करें" else "Clear All",
                                    color = Color.Red,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }

                    // Divider
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(1.dp)
                            .background(Color.White.copy(alpha = 0.08f))
                    )

                    // Content
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        if (watchHistory.isEmpty()) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .weight(1f),
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.Center
                            ) {
                                Icon(Icons.Rounded.History, contentDescription = null, tint = Color.Gray, modifier = Modifier.size(64.dp))
                                Spacer(modifier = Modifier.height(16.dp))
                                Text(
                                    text = if (appLang == "hi") "इतिहास खाली है" else "History is empty",
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 16.sp
                                )
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(
                                    text = if (appLang == "hi") "आपके द्वारा देखे गए वीडियो और गाने यहाँ दिखाई देंगे।" else "Videos you watch will show up here.",
                                    color = Color.Gray,
                                    fontSize = 12.sp,
                                    textAlign = TextAlign.Center
                                )
                            }
                        } else {
                            LazyColumn(
                                verticalArrangement = Arrangement.spacedBy(10.dp),
                                modifier = Modifier.fillMaxSize()
                            ) {
                                items(watchHistory) { item ->
                                    GlassCard(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clickable {
                                                val playable = MediaEntity(
                                                    id = item.id,
                                                    title = item.title,
                                                    url = item.url,
                                                    duration = item.duration,
                                                    artist = item.artist,
                                                    thumbnailUrl = item.thumbnailUrl,
                                                    category = item.category
                                                )
                                                viewModel.playMedia(playable)
                                                showHistoryDialog = false
                                            },
                                        cornerRadius = 14.dp
                                    ) {
                                        Row(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .padding(12.dp),
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Box(
                                                modifier = Modifier
                                                    .size(40.dp)
                                                    .background(ElectricBlue.copy(alpha = 0.1f), CircleShape),
                                                contentAlignment = Alignment.Center
                                            ) {
                                                Icon(
                                                    imageVector = Icons.Rounded.PlayArrow,
                                                    contentDescription = null,
                                                    tint = ElectricBlue,
                                                    modifier = Modifier.size(20.dp)
                                                )
                                            }
                                            Spacer(modifier = Modifier.width(12.dp))
                                            Column(modifier = Modifier.weight(1f)) {
                                                Text(
                                                    text = item.title,
                                                    color = Color.White,
                                                    fontSize = 14.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    maxLines = 1,
                                                    overflow = TextOverflow.Ellipsis
                                                )
                                                Spacer(modifier = Modifier.height(2.dp))
                                                Text(
                                                    text = item.artist ?: "Offline Stream",
                                                    color = Color.Gray,
                                                    fontSize = 12.sp
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // 7. CLEAN DIALOG
    if (showCleanDialog) {
        var isScanning by remember { mutableStateOf(false) }
        var isCleanComplete by remember { mutableStateOf(false) }
        var scanProgress by remember { mutableStateOf(0f) }
        var activeLogText by remember { mutableStateOf("Ready to scan") }

        LaunchedEffect(isScanning) {
            if (isScanning) {
                val logs = listOf(
                    "Analyzing video cache directories...",
                    "Purging expired metadata stream buffers...",
                    "Sweeping corrupt SQLite indices...",
                    "Clearing high-fidelity audio conversion temps...",
                    "Defragmenting physical file mapping lists...",
                    "Optimizing database pipelines..."
                )
                for (i in 1..20) {
                    delay(100)
                    scanProgress = i.toFloat() / 20f
                    activeLogText = logs[(i / 4).coerceAtMost(logs.size - 1)]
                }
                isScanning = false
                isCleanComplete = true
            }
        }

        androidx.compose.ui.window.Dialog(
            onDismissRequest = { showCleanDialog = false },
            properties = androidx.compose.ui.window.DialogProperties(
                usePlatformDefaultWidth = false,
                dismissOnBackPress = true,
                dismissOnClickOutside = false
            )
        ) {
            Surface(
                modifier = Modifier.fillMaxSize(),
                color = Color(0xFF070709)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .statusBarsPadding()
                        .navigationBarsPadding()
                ) {
                    // Header Bar
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(
                            onClick = { showCleanDialog = false },
                            modifier = Modifier.size(48.dp)
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Rounded.ArrowBack,
                                contentDescription = "Back",
                                tint = Color.White
                            )
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = if (appLang == "hi") "स्टोरेज ऑप्टिमाइज़र" else "Storage Optimizer",
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                fontSize = 18.sp
                            )
                            Text(
                                text = "System Junk Cleaner",
                                color = Color.Gray,
                                fontSize = 11.sp
                            )
                        }
                        
                        // Icon Badge
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .background(Color(0xFF10B981).copy(alpha = 0.15f), CircleShape)
                                .border(1.dp, Color(0xFF10B981).copy(alpha = 0.3f), CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.DeleteSweep,
                                contentDescription = null,
                                tint = Color(0xFF10B981),
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }

                    // Divider
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(1.dp)
                            .background(Color.White.copy(alpha = 0.08f))
                    )

                    // Content
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(16.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        if (!isScanning && !isCleanComplete) {
                            Spacer(modifier = Modifier.height(24.dp))
                            
                            GlassCard(
                                modifier = Modifier.fillMaxWidth(),
                                cornerRadius = 16.dp
                            ) {
                                Column(
                                    modifier = Modifier.padding(16.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    verticalArrangement = Arrangement.spacedBy(12.dp)
                                ) {
                                    Text(
                                        text = if (appLang == "hi") "अस्थायी वीडियो कैश, अनुक्रमणिका लॉग और समाप्त हो चुकी स्ट्रीम फ़ाइलों को साफ़ करें ताकि तुरंत डिस्क स्थान खाली हो सके:" else "Clean temporary video caches, indexing logs, and expired stream files to instantly free up disk space:",
                                        color = Color.LightGray,
                                        fontSize = 13.sp,
                                        lineHeight = 20.sp,
                                        textAlign = TextAlign.Center
                                    )
                                    
                                    Spacer(modifier = Modifier.height(8.dp))

                                    Box(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .background(Color.White.copy(alpha = 0.04f), RoundedCornerShape(12.dp))
                                            .border(1.dp, Color.White.copy(alpha = 0.08f), RoundedCornerShape(12.dp))
                                            .padding(24.dp),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                            Text(
                                                text = if (appLang == "hi") "कचरा और कैश मिला" else "Junk & Cache Found",
                                                color = Color.Gray,
                                                fontSize = 12.sp,
                                                fontWeight = FontWeight.Medium
                                            )
                                            Spacer(modifier = Modifier.height(6.dp))
                                            Text("184.2 MB", color = Color(0xFF10B981), fontSize = 36.sp, fontWeight = FontWeight.Bold)
                                        }
                                    }
                                    
                                    Spacer(modifier = Modifier.height(8.dp))

                                    Button(
                                        onClick = { isScanning = true },
                                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF10B981)),
                                        modifier = Modifier.fillMaxWidth(),
                                        shape = RoundedCornerShape(12.dp)
                                    ) {
                                        Text(
                                            text = if (appLang == "hi") "जंक साफ़ करें" else "Scan & Clear Junk",
                                            color = Color.Black,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 14.sp
                                        )
                                    }
                                }
                            }
                        } else if (isScanning) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .weight(1f),
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.Center
                            ) {
                                CircularProgressIndicator(
                                    progress = scanProgress,
                                    color = Color(0xFF10B981),
                                    trackColor = Color.White.copy(alpha = 0.1f),
                                    modifier = Modifier.size(64.dp)
                                )
                                Spacer(modifier = Modifier.height(24.dp))
                                Text(
                                    text = if (appLang == "hi") "अनुकूलन हो रहा है: ${(scanProgress * 100).toInt()}%" else "Optimizing: ${(scanProgress * 100).toInt()}%",
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 18.sp
                                )
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(activeLogText, color = Color.Gray, fontSize = 13.sp, textAlign = TextAlign.Center)
                            }
                        } else if (isCleanComplete) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .weight(1f),
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.Center
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(72.dp)
                                        .background(Color(0xFF10B981).copy(alpha = 0.1f), CircleShape)
                                        .border(1.dp, Color(0xFF10B981).copy(alpha = 0.2f), CircleShape),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(Icons.Rounded.CheckCircle, contentDescription = null, tint = Color(0xFF10B981), modifier = Modifier.size(40.dp))
                                }
                                Spacer(modifier = Modifier.height(20.dp))
                                Text(
                                    text = if (appLang == "hi") "सिस्टम पूरी तरह से अनुकूलित!" else "System Fully Optimized!",
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 18.sp
                                )
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(
                                    text = if (appLang == "hi") "184.2 MB स्टोरेज कैश सफलतापूर्वक साफ़ किया गया।" else "Freed up 184.2 MB of storage cache.",
                                    color = Color.Gray,
                                    fontSize = 13.sp,
                                    textAlign = TextAlign.Center
                                )
                                
                                Button(
                                    onClick = { 
                                        showCleanDialog = false 
                                        isCleanComplete = false
                                    },
                                    modifier = Modifier.fillMaxWidth(0.6f).padding(top = 24.dp),
                                    colors = ButtonDefaults.buttonColors(containerColor = Color.White.copy(alpha = 0.12f)),
                                    shape = RoundedCornerShape(12.dp)
                                ) {
                                    Text(
                                        text = if (appLang == "hi") "बहुत बढ़िया" else "Awesome",
                                        color = Color.White,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // 8. NEW DIALOGS REGION START
    // 8. SETTINGS DETAILS DIALOG (PLAYER SETTINGS)
    if (showSettingsDetailsDialog) {
        val appLang by viewModel.appLanguage.collectAsState()
        var activeSubPanel by remember { mutableStateOf<String?>(null) }
        var blockGameCenter by remember { mutableStateOf(true) } // Set to true (active) as shown in the image
        
        // Settings State parameters (interactable & simulated for high fidelity)
        var popUpPlay by remember { mutableStateOf(true) }
        var continuousPlay by remember { mutableStateOf(true) }
        var videoOrientation by remember { mutableStateOf("Sensor/Auto") }
        var filterShortAudio by remember { mutableStateOf(true) }
        var skipNomedia by remember { mutableStateOf(true) }
        var maxDownloads by remember { mutableStateOf(3) }
        var downloadOverWifi by remember { mutableStateOf(false) }

        // Handle hardware back press cleanly
        androidx.activity.compose.BackHandler(enabled = showSettingsDetailsDialog) {
            if (activeSubPanel != null) {
                activeSubPanel = null
            } else {
                showSettingsDetailsDialog = false
            }
        }

        @Composable
        fun SettingsItemRow(
            title: String,
            subtitle: String,
            icon: androidx.compose.ui.graphics.vector.ImageVector,
            showChevron: Boolean = true,
            rightContent: @Composable (() -> Unit)? = null,
            onClick: () -> Unit = {}
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable(onClick = onClick)
                    .padding(horizontal = 20.dp, vertical = 18.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = Color.White,
                    modifier = Modifier.size(24.dp)
                )
                
                Spacer(modifier = Modifier.width(20.dp))
                
                Column(
                    modifier = Modifier.weight(1f)
                ) {
                    Text(
                        text = title,
                        color = Color.White,
                        fontSize = 17.sp,
                        fontWeight = FontWeight.Medium
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = subtitle,
                        color = Color(0xFF8E8E93),
                        fontSize = 13.sp,
                        lineHeight = 18.sp
                    )
                }
                
                if (rightContent != null) {
                    rightContent()
                } else if (showChevron) {
                    Icon(
                        imageVector = Icons.Rounded.ChevronRight,
                        contentDescription = null,
                        tint = Color(0xFF5A5A5F),
                        modifier = Modifier.size(20.dp)
                    )
                }
            }
        }

        androidx.compose.ui.window.Dialog(
            onDismissRequest = { showSettingsDetailsDialog = false },
            properties = androidx.compose.ui.window.DialogProperties(
                usePlatformDefaultWidth = false,
                dismissOnBackPress = true,
                dismissOnClickOutside = false
            )
        ) {
            Surface(
                modifier = Modifier.fillMaxSize(),
                color = Color(0xFF070709) // Sleek absolute black background to match the reference image
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .statusBarsPadding()
                        .navigationBarsPadding()
                ) {
                    // Header Bar
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(56.dp)
                            .padding(horizontal = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(onClick = {
                            if (activeSubPanel != null) {
                                activeSubPanel = null
                            } else {
                                showSettingsDetailsDialog = false
                            }
                        }) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Rounded.ArrowBack,
                                contentDescription = "Back",
                                tint = Color.White
                            )
                        }
                        
                        Text(
                            text = when (activeSubPanel) {
                                "GENERAL" -> if (appLang == "hi") "सामान्य सेटिंग्स" else "General"
                                "VIDEO" -> if (appLang == "hi") "वीडियो सेटिंग्स" else "Video"
                                "AUDIO" -> if (appLang == "hi") "ऑडियो सेटिंग्स" else "Audio"
                                "DOWNLOADS" -> if (appLang == "hi") "डाउनलोड सेटिंग्स" else "Downloads"
                                "SUBSCRIPTION" -> if (appLang == "hi") "सदस्यता" else "Subscription"
                                "ABOUT" -> if (appLang == "hi") "हमारे बारे में" else "About us"
                                else -> if (appLang == "hi") "सेटिंग्स" else "Settings"
                            },
                            color = Color.White,
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold,
                            textAlign = TextAlign.Center,
                            modifier = Modifier
                                .weight(1f)
                                .padding(end = 48.dp) // Centering offset adjustment
                        )
                    }

                    // Separation Divider line
                    Divider(color = Color.White.copy(alpha = 0.08f), thickness = 1.dp)

                    if (activeSubPanel == null) {
                        // Main Settings options matching reference image exactly
                        LazyColumn(
                            modifier = Modifier.fillMaxSize(),
                            contentPadding = PaddingValues(top = 8.dp, bottom = 24.dp)
                        ) {
                            item {
                                SettingsItemRow(
                                    title = if (appLang == "hi") "सामान्य" else "General",
                                    subtitle = if (appLang == "hi") "भाषा, इतिहास" else "Language, History",
                                    icon = Icons.Rounded.Smartphone,
                                    onClick = { activeSubPanel = "GENERAL" }
                                )
                                Divider(color = Color.White.copy(alpha = 0.04f), thickness = 1.dp, modifier = Modifier.padding(horizontal = 20.dp))
                            }
                            
                            item {
                                SettingsItemRow(
                                    title = if (appLang == "hi") "वीडियो" else "Video",
                                    subtitle = if (appLang == "hi") "पॉप-अप प्ले, स्क्रीन ओरिएंटेशन, निरंतर प्लेबैक..." else "Pop-up play, screen orientation, continuous playb...",
                                    icon = Icons.Rounded.PlayCircle,
                                    onClick = { activeSubPanel = "VIDEO" }
                                )
                                Divider(color = Color.White.copy(alpha = 0.04f), thickness = 1.dp, modifier = Modifier.padding(horizontal = 20.dp))
                            }
                            
                            item {
                                SettingsItemRow(
                                    title = if (appLang == "hi") "ऑडियो" else "Audio",
                                    subtitle = if (appLang == "hi") "ऑडियो प्रारूप, ऑडियो अवधि, नोमीडिया फ़ोल्डर सेटिंग्स..." else "Audio format, audio duration, nomedia folder set...",
                                    icon = Icons.Rounded.Headphones,
                                    onClick = { activeSubPanel = "AUDIO" }
                                )
                                Divider(color = Color.White.copy(alpha = 0.04f), thickness = 1.dp, modifier = Modifier.padding(horizontal = 20.dp))
                            }
                            
                            item {
                                SettingsItemRow(
                                    title = if (appLang == "hi") "डाउनलोड" else "Downloads",
                                    subtitle = if (appLang == "hi") "पाथ, अधिकतम डाउनलोड कार्य" else "Path, max download tasks",
                                    icon = Icons.Rounded.Download,
                                    onClick = { activeSubPanel = "DOWNLOADS" }
                                )
                                Divider(color = Color.White.copy(alpha = 0.04f), thickness = 1.dp, modifier = Modifier.padding(horizontal = 20.dp))
                            }
                            
                            item {
                                SettingsItemRow(
                                    title = if (appLang == "hi") "सदस्यता" else "Subscription",
                                    subtitle = if (appLang == "hi") "सदस्यता प्रबंधित करें या रद्द करें" else "Manage or Cancel subscription",
                                    icon = Icons.Rounded.WorkspacePremium,
                                    onClick = { activeSubPanel = "SUBSCRIPTION" }
                                )
                                Divider(color = Color.White.copy(alpha = 0.04f), thickness = 1.dp, modifier = Modifier.padding(horizontal = 20.dp))
                            }
                            
                            item {
                                SettingsItemRow(
                                    title = if (appLang == "hi") "गेम सेंटर" else "Game Center",
                                    subtitle = if (appLang == "hi") "गेम सेंटर को ब्लॉक करें और गेम सामग्री प्रदर्शित न करें" else "Block the game center and do not display game content",
                                    icon = Icons.Rounded.SportsEsports,
                                    showChevron = false,
                                    rightContent = {
                                        Switch(
                                            checked = blockGameCenter,
                                            onCheckedChange = { 
                                                blockGameCenter = it
                                                val msg = if (it) {
                                                    if (appLang == "hi") "गेम सेंटर ब्लॉक किया गया" else "Game Center blocked!"
                                                } else {
                                                    if (appLang == "hi") "गेम सेंटर प्रदर्शित किया गया" else "Game Center displayed!"
                                                }
                                                Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
                                            },
                                            colors = SwitchDefaults.colors(
                                                checkedThumbColor = Color.White,
                                                checkedTrackColor = Color(0xFF10B981),
                                                uncheckedThumbColor = Color(0xFFD1D1D6),
                                                uncheckedTrackColor = Color(0xFF3A3A3C)
                                            )
                                        )
                                    }
                                )
                                Divider(color = Color.White.copy(alpha = 0.04f), thickness = 1.dp, modifier = Modifier.padding(horizontal = 20.dp))
                            }
                            
                            item {
                                SettingsItemRow(
                                    title = if (appLang == "hi") "हमारे बारे में" else "About us",
                                    subtitle = if (appLang == "hi") "प्रशंसक समूह, आधिकारिक वेबसाइट, पेज और चैनल" else "Fans group, official website, pages & channel",
                                    icon = Icons.Rounded.Info,
                                    onClick = { activeSubPanel = "ABOUT" }
                                )
                            }
                        }
                    } else {
                        // Settings Sub-panel Views
                        Column(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(horizontal = 20.dp, vertical = 20.dp),
                            verticalArrangement = Arrangement.spacedBy(18.dp)
                        ) {
                            when (activeSubPanel) {
                                "GENERAL" -> {
                                    Text(
                                        text = if (appLang == "hi") "भाषा और स्थानीयकरण" else "Language & Localization",
                                        color = Color.White,
                                        fontSize = 15.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                    
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                                    ) {
                                        listOf("en" to "English", "hi" to "Hindi").forEach { lang ->
                                            val selected = appLang == lang.first
                                            Box(
                                                modifier = Modifier
                                                    .weight(1f)
                                                    .border(
                                                        width = 1.dp,
                                                        color = if (selected) Color(0xFF10B981) else Color.White.copy(alpha = 0.1f),
                                                        shape = RoundedCornerShape(10.dp)
                                                    )
                                                    .background(
                                                        if (selected) Color(0xFF10B981).copy(alpha = 0.12f) else Color.White.copy(alpha = 0.02f),
                                                        RoundedCornerShape(10.dp)
                                                    )
                                                    .clickable {
                                                        viewModel.setAppLanguage(lang.first)
                                                        Toast.makeText(context, "Language: ${lang.second}", Toast.LENGTH_SHORT).show()
                                                    }
                                                    .padding(14.dp),
                                                contentAlignment = Alignment.Center
                                            ) {
                                                Text(lang.second, color = if (selected) Color(0xFF10B981) else Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                                            }
                                        }
                                    }

                                    Spacer(modifier = Modifier.height(10.dp))
                                    Divider(color = Color.White.copy(alpha = 0.1f))

                                    Text(
                                        text = if (appLang == "hi") "प्लेबैक इतिहास प्रबंधन" else "Playback History Management",
                                        color = Color.White,
                                        fontSize = 15.sp,
                                        fontWeight = FontWeight.Bold
                                    )

                                    Button(
                                        onClick = {
                                            viewModel.clearWatchHistory()
                                            Toast.makeText(context, if (appLang == "hi") "प्लेबैक इतिहास साफ़ कर दिया गया!" else "Playback watch history cleared!", Toast.LENGTH_SHORT).show()
                                        },
                                        modifier = Modifier.fillMaxWidth(),
                                        shape = RoundedCornerShape(12.dp),
                                        colors = ButtonDefaults.buttonColors(containerColor = Color.Red.copy(alpha = 0.1f), contentColor = Color.Red)
                                    ) {
                                        Text(if (appLang == "hi") "प्लेबैक इतिहास साफ़ करें" else "Clear Watch History", fontWeight = FontWeight.Bold)
                                    }
                                }
                                
                                "VIDEO" -> {
                                    Text(
                                        text = if (appLang == "hi") "वीडियो प्लेबैक विकल्प" else "Video Playback Preferences",
                                        color = Color.White,
                                        fontSize = 15.sp,
                                        fontWeight = FontWeight.Bold
                                    )

                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(if (appLang == "hi") "पॉप-अप प्ले (PiP)" else "Pop-up play (Picture-in-Picture)", color = Color.LightGray, fontSize = 14.sp)
                                        Switch(
                                            checked = popUpPlay,
                                            onCheckedChange = { popUpPlay = it },
                                            colors = SwitchDefaults.colors(checkedThumbColor = Color.White, checkedTrackColor = Color(0xFF10B981))
                                        )
                                    }

                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(if (appLang == "hi") "निरंतर प्लेबैक" else "Continuous playback", color = Color.LightGray, fontSize = 14.sp)
                                        Switch(
                                            checked = continuousPlay,
                                            onCheckedChange = { continuousPlay = it },
                                            colors = SwitchDefaults.colors(checkedThumbColor = Color.White, checkedTrackColor = Color(0xFF10B981))
                                        )
                                    }

                                    Spacer(modifier = Modifier.height(10.dp))
                                    Divider(color = Color.White.copy(alpha = 0.1f))

                                    Text(
                                        text = if (appLang == "hi") "डिफ़ॉल्ट स्क्रीन ओरिएंटेशन" else "Default Screen Orientation",
                                        color = Color.White,
                                        fontSize = 15.sp,
                                        fontWeight = FontWeight.Bold
                                    )

                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        listOf("Sensor/Auto", "Landscape", "Portrait").forEach { mode ->
                                            val isSel = videoOrientation == mode
                                            Box(
                                                modifier = Modifier
                                                    .weight(1f)
                                                    .border(
                                                        width = 1.dp,
                                                        color = if (isSel) Color(0xFF10B981) else Color.White.copy(alpha = 0.08f),
                                                        shape = RoundedCornerShape(8.dp)
                                                    )
                                                    .background(
                                                        if (isSel) Color(0xFF10B981).copy(alpha = 0.1f) else Color.White.copy(alpha = 0.02f),
                                                        RoundedCornerShape(8.dp)
                                                    )
                                                    .clickable { videoOrientation = mode }
                                                    .padding(12.dp),
                                                contentAlignment = Alignment.Center
                                            ) {
                                                Text(mode, color = if (isSel) Color(0xFF10B981) else Color.LightGray, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                            }
                                        }
                                    }
                                }
                                
                                "AUDIO" -> {
                                    Text(
                                        text = if (appLang == "hi") "ऑडियो सेटिंग्स" else "Audio Player Settings",
                                        color = Color.White,
                                        fontSize = 15.sp,
                                        fontWeight = FontWeight.Bold
                                    )

                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(if (appLang == "hi") "शॉर्ट ऑडियो फ़िल्टर करें (<30s)" else "Filter short audio (<30s)", color = Color.LightGray, fontSize = 14.sp)
                                        Switch(
                                            checked = filterShortAudio,
                                            onCheckedChange = { filterShortAudio = it },
                                            colors = SwitchDefaults.colors(checkedThumbColor = Color.White, checkedTrackColor = Color(0xFF10B981))
                                        )
                                    }

                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(if (appLang == "hi") ".nomedia फ़ोल्डर्स को छोड़ें" else "Skip .nomedia folders", color = Color.LightGray, fontSize = 14.sp)
                                        Switch(
                                            checked = skipNomedia,
                                            onCheckedChange = { skipNomedia = it },
                                            colors = SwitchDefaults.colors(checkedThumbColor = Color.White, checkedTrackColor = Color(0xFF10B981))
                                        )
                                    }

                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(if (appLang == "hi") "बैकग्राउंड ऑडियो स्ट्रीम प्लेबैक" else "Background play audio stream", color = Color.LightGray, fontSize = 14.sp)
                                        var bgPlayStream by remember { mutableStateOf(true) }
                                        Switch(
                                            checked = bgPlayStream,
                                            onCheckedChange = { bgPlayStream = it },
                                            colors = SwitchDefaults.colors(checkedThumbColor = Color.White, checkedTrackColor = Color(0xFF10B981))
                                        )
                                    }
                                }
                                
                                "DOWNLOADS" -> {
                                    Text(
                                        text = if (appLang == "hi") "डाउनलोड संग्रहण पाथ" else "Download Storage Path",
                                        color = Color.White,
                                        fontSize = 15.sp,
                                        fontWeight = FontWeight.Bold
                                    )

                                    Box(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .background(Color.White.copy(alpha = 0.03f), RoundedCornerShape(12.dp))
                                            .border(1.dp, Color.White.copy(alpha = 0.06f), RoundedCornerShape(12.dp))
                                            .clickable {
                                                Toast.makeText(context, "Storage path copied!", Toast.LENGTH_SHORT).show()
                                            }
                                            .padding(16.dp)
                                    ) {
                                        Column {
                                            Text(
                                                text = if (appLang == "hi") "प्राथमिक पाथ:" else "Primary Directory Path:",
                                                color = Color.Gray,
                                                fontSize = 12.sp
                                            )
                                            Spacer(modifier = Modifier.height(4.dp))
                                            Text(
                                                text = "/storage/emulated/0/Download/Vidiopen/",
                                                color = Color(0xFF10B981),
                                                fontSize = 13.sp,
                                                fontWeight = FontWeight.Bold
                                            )
                                            Spacer(modifier = Modifier.height(6.dp))
                                            Text(
                                                text = if (appLang == "hi") "कॉपी करने के लिए टैप करें" else "Tap to copy storage path",
                                                color = Color.LightGray,
                                                fontSize = 11.sp,
                                                fontWeight = FontWeight.Medium
                                            )
                                        }
                                    }

                                    Spacer(modifier = Modifier.height(8.dp))
                                    Divider(color = Color.White.copy(alpha = 0.1f))

                                    Text(
                                        text = if (appLang == "hi") "अधिकतम समानांतर डाउनलोड" else "Max Concurrent Download Tasks",
                                        color = Color.White,
                                        fontSize = 15.sp,
                                        fontWeight = FontWeight.Bold
                                    )

                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        listOf(1, 2, 3, 4, 5).forEach { num ->
                                            val isSel = maxDownloads == num
                                            Box(
                                                modifier = Modifier
                                                    .weight(1f)
                                                    .border(
                                                        width = 1.dp,
                                                        color = if (isSel) Color(0xFF10B981) else Color.White.copy(alpha = 0.08f),
                                                        shape = RoundedCornerShape(8.dp)
                                                    )
                                                    .background(
                                                        if (isSel) Color(0xFF10B981).copy(alpha = 0.1f) else Color.White.copy(alpha = 0.02f),
                                                        RoundedCornerShape(8.dp)
                                                    )
                                                    .clickable { maxDownloads = num }
                                                    .padding(12.dp),
                                                contentAlignment = Alignment.Center
                                            ) {
                                                Text("$num", color = if (isSel) Color(0xFF10B981) else Color.LightGray, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                                            }
                                        }
                                    }

                                    Row(
                                        modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(if (appLang == "hi") "केवल वाई-फाई पर डाउनलोड करें" else "Download over Wi-Fi only", color = Color.LightGray, fontSize = 14.sp)
                                        Switch(
                                            checked = downloadOverWifi,
                                            onCheckedChange = { downloadOverWifi = it },
                                            colors = SwitchDefaults.colors(checkedThumbColor = Color.White, checkedTrackColor = Color(0xFF10B981))
                                        )
                                    }
                                }
                                
                                "SUBSCRIPTION" -> {
                                    Box(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .background(
                                                Brush.verticalGradient(
                                                    colors = listOf(Color(0xFF1B1123), Color(0xFF0A0512))
                                                ),
                                                RoundedCornerShape(16.dp)
                                            )
                                            .border(
                                                width = 1.dp,
                                                brush = Brush.horizontalGradient(
                                                    colors = listOf(Color(0xFFFFB03A), Color(0xFFFF1E27))
                                                ),
                                                shape = RoundedCornerShape(16.dp)
                                            )
                                            .padding(20.dp)
                                    ) {
                                        Column(
                                            horizontalAlignment = Alignment.CenterHorizontally,
                                            modifier = Modifier.fillMaxWidth()
                                        ) {
                                            Icon(
                                                imageVector = Icons.Rounded.WorkspacePremium,
                                                contentDescription = "VIP Icon",
                                                tint = Color(0xFFFFB03A),
                                                modifier = Modifier.size(56.dp)
                                            )
                                            Spacer(modifier = Modifier.height(10.dp))
                                            Text(
                                                text = "VIDIOPEN LIFETIME PRO",
                                                color = Color.White,
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 18.sp,
                                                letterSpacing = 1.5.sp
                                            )
                                            Text(
                                                text = if (appLang == "hi") "सक्रिय सदस्यता: लक्जरी संस्करण" else "Active Membership: Luxury Edition",
                                                color = Color(0xFF10B981),
                                                fontSize = 13.sp,
                                                fontWeight = FontWeight.Medium
                                            )

                                            Spacer(modifier = Modifier.height(16.dp))
                                            Divider(color = Color.White.copy(alpha = 0.1f))
                                            Spacer(modifier = Modifier.height(16.dp))

                                            listOf(
                                                if (appLang == "hi") "✅ विज्ञापन-मुक्त लक्जरी प्लेयर" else "✅ 100% Ad-Free Premium Playback",
                                                if (appLang == "hi") "✅ 4K अल्ट्रा एचडी हार्डवेयर डिकोडिंग" else "✅ 4K Ultra-HD Hardware Decoding",
                                                if (appLang == "hi") "✅ बैकग्राउंड ऑडियो और पिप सक्षम" else "✅ Background Audio & PiP Enabled",
                                                if (appLang == "hi") "✅ असीमित एमपी3 कनवर्टर और वाई-फाई ट्रांसफर" else "✅ Unlimited MP3 Converter & File Transfer"
                                            ).forEach { benefit ->
                                                Text(
                                                    text = benefit,
                                                    color = Color.LightGray,
                                                    fontSize = 13.sp,
                                                    modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                                                    textAlign = TextAlign.Start
                                                )
                                            }

                                            Spacer(modifier = Modifier.height(20.dp))

                                            Button(
                                                onClick = {
                                                    Toast.makeText(context, if (appLang == "hi") "आप पहले से ही आजीवन प्रो संस्करण का उपयोग कर रहे हैं!" else "You are already using the lifetime PRO version!", Toast.LENGTH_LONG).show()
                                                },
                                                modifier = Modifier.fillMaxWidth(),
                                                shape = RoundedCornerShape(12.dp),
                                                colors = ButtonDefaults.buttonColors(
                                                    containerColor = Color(0xFF10B981)
                                                )
                                            ) {
                                                Text(
                                                    text = if (appLang == "hi") "सदस्यता प्रबंधित करें" else "Manage Subscription",
                                                    fontWeight = FontWeight.Bold,
                                                    color = Color.Black
                                                )
                                            }
                                        }
                                    }
                                }
                                
                                "ABOUT" -> {
                                    Column(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalAlignment = Alignment.CenterHorizontally,
                                        verticalArrangement = Arrangement.spacedBy(14.dp)
                                    ) {
                                        Box(
                                            modifier = Modifier
                                                .size(72.dp)
                                                .background(Color(0xFF16161A), CircleShape)
                                                .border(1.dp, Color.White.copy(alpha = 0.08f), CircleShape),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            AppLogo(modifier = Modifier.size(48.dp))
                                        }

                                        Text(
                                            text = "Vidiopen Pro Luxury",
                                            color = Color.White,
                                            fontSize = 18.sp,
                                            fontWeight = FontWeight.Bold
                                        )

                                        Text(
                                            text = "Version 1.2.5 (Luxury Edition)",
                                            color = Color.Gray,
                                            fontSize = 13.sp
                                        )

                                        Spacer(modifier = Modifier.height(8.dp))
                                        Divider(color = Color.White.copy(alpha = 0.08f))

                                        Row(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .background(Color.White.copy(alpha = 0.02f), RoundedCornerShape(10.dp))
                                                .clickable {
                                                    Toast.makeText(context, "Opening Vidiopen Fans Community Group...", Toast.LENGTH_SHORT).show()
                                                }
                                                .padding(14.dp),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Text(if (appLang == "hi") "प्रशंसक समूह (Fans Group)" else "Official Community Fans Group", color = Color.LightGray, fontSize = 13.sp, fontWeight = FontWeight.Medium)
                                            Icon(Icons.Rounded.ChevronRight, contentDescription = null, tint = Color.Gray)
                                        }

                                        Row(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .background(Color.White.copy(alpha = 0.02f), RoundedCornerShape(10.dp))
                                                .clickable {
                                                    val webIntent = Intent(Intent.ACTION_VIEW, Uri.parse("https://vidiopen.in"))
                                                    try {
                                                        context.startActivity(webIntent)
                                                    } catch (e: Exception) {
                                                        Toast.makeText(context, "Opening official website https://vidiopen.in ...", Toast.LENGTH_SHORT).show()
                                                    }
                                                }
                                                .padding(14.dp),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Text(if (appLang == "hi") "आधिकारिक वेबसाइट" else "Official Website (vidiopen.in)", color = Color.LightGray, fontSize = 13.sp, fontWeight = FontWeight.Medium)
                                            Icon(Icons.Rounded.ChevronRight, contentDescription = null, tint = Color.Gray)
                                        }

                                        var checkingForUpdate by remember { mutableStateOf(false) }
                                        Button(
                                            onClick = {
                                                checkingForUpdate = true
                                            },
                                            modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
                                            colors = ButtonDefaults.buttonColors(containerColor = Color.White.copy(alpha = 0.06f), contentColor = Color.White)
                                        ) {
                                            if (checkingForUpdate) {
                                                CircularProgressIndicator(modifier = Modifier.size(18.dp), color = Color(0xFF10B981), strokeWidth = 2.dp)
                                                Spacer(modifier = Modifier.width(10.dp))
                                                Text(if (appLang == "hi") "अपडेट की जांच की जा रही है..." else "Checking for updates...")
                                                LaunchedEffect(Unit) {
                                                    delay(1500)
                                                    checkingForUpdate = false
                                                    Toast.makeText(context, if (appLang == "hi") "वीडिओपेन पूरी तरह से अपडेटेड है!" else "Vidiopen is fully up to date!", Toast.LENGTH_SHORT).show()
                                                }
                                            } else {
                                                Text(if (appLang == "hi") "अपडेट के लिए जांचें" else "Check for Updates", fontWeight = FontWeight.Bold)
                                            }
                                        }

                                        Spacer(modifier = Modifier.height(10.dp))

                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.Center,
                                            modifier = Modifier
                                                .background(Color.White.copy(alpha = 0.04f), RoundedCornerShape(8.dp))
                                                .padding(horizontal = 12.dp, vertical = 6.dp)
                                        ) {
                                            Text("Proudly Crafted in India", color = Color.Gray, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text("🇮🇳", fontSize = 12.sp)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // 9. RECYCLE BIN DIALOG (Premium Full Screen)
    if (showRecycleBinDialog) {
        var binCleared by remember { mutableStateOf(false) }
        androidx.compose.ui.window.Dialog(
            onDismissRequest = { showRecycleBinDialog = false },
            properties = androidx.compose.ui.window.DialogProperties(
                usePlatformDefaultWidth = false,
                dismissOnBackPress = true,
                dismissOnClickOutside = false
            )
        ) {
            Surface(
                modifier = Modifier.fillMaxSize(),
                color = Color(0xFF070709)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .statusBarsPadding()
                        .navigationBarsPadding()
                ) {
                    // Header Bar
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(
                            onClick = { showRecycleBinDialog = false },
                            modifier = Modifier.size(48.dp)
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Rounded.ArrowBack,
                                contentDescription = "Back",
                                tint = Color.White
                            )
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = if (appLang == "hi") "रीसायकल बिन" else "Recycle Bin",
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                fontSize = 18.sp
                            )
                            Text(
                                text = "Temporary Storage Shield",
                                color = Color.Gray,
                                fontSize = 11.sp
                            )
                        }
                        
                        if (!binCleared) {
                            TextButton(
                                onClick = { 
                                    binCleared = true
                                    Toast.makeText(context, if (appLang == "hi") "रीसायकल बिन खाली किया गया" else "Recycle Bin Cleared Successfully", Toast.LENGTH_SHORT).show()
                                }
                            ) {
                                Text(
                                    text = if (appLang == "hi") "खाली करें" else "Empty Bin",
                                    color = Color.Red,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp
                                )
                            }
                        }
                    }

                    HorizontalDivider(color = Color.White.copy(alpha = 0.08f))

                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        if (binCleared) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .weight(1f),
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.DeleteSweep,
                                    contentDescription = null,
                                    tint = Color.Gray.copy(alpha = 0.5f),
                                    modifier = Modifier.size(72.dp)
                                )
                                Spacer(modifier = Modifier.height(16.dp))
                                Text(
                                    text = if (appLang == "hi") "रीसायकल बिन पूरी तरह से खाली है" else "Recycle Bin is completely empty",
                                    color = Color.Gray,
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Medium
                                )
                            }
                        } else {
                            Text(
                                text = if (appLang == "hi") 
                                    "हटाए गए स्ट्रीम आइटम स्थायी रूप से हटाए जाने से पहले 30 दिनों तक कैश में रहते हैं:" 
                                    else "Deleted streaming cache items remain in local application storage for 30 days before permanent deletion:",
                                color = Color.LightGray,
                                fontSize = 12.sp,
                                lineHeight = 18.sp
                            )

                            Spacer(modifier = Modifier.height(8.dp))

                            // Sample item inside Recycle Bin
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(Color.White.copy(alpha = 0.03f), RoundedCornerShape(16.dp))
                                    .border(1.dp, Color.White.copy(alpha = 0.05f), RoundedCornerShape(16.dp))
                                    .padding(16.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(48.dp)
                                        .background(Color.Red.copy(alpha = 0.1f), RoundedCornerShape(12.dp)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Rounded.DeleteSweep,
                                        contentDescription = null,
                                        tint = Color.Red,
                                        modifier = Modifier.size(24.dp)
                                    )
                                }

                                Spacer(modifier = Modifier.width(16.dp))

                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = "corrupted_temp_clip_108.mp4",
                                        color = Color.White,
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Bold,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    Text(
                                        text = "Deleted 2 days ago • 14.8 MB",
                                        color = Color.Gray,
                                        fontSize = 11.sp
                                    )
                                }

                                Button(
                                    onClick = { 
                                        binCleared = true
                                        android.widget.Toast.makeText(context, "Item restored successfully!", android.widget.Toast.LENGTH_SHORT).show()
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF10B981)),
                                    contentPadding = PaddingValues(horizontal = 14.dp, vertical = 6.dp),
                                    shape = RoundedCornerShape(8.dp),
                                    modifier = Modifier.height(36.dp)
                                ) {
                                    Text(
                                        text = if (appLang == "hi") "पुनर्प्राप्त करें" else "Restore",
                                        color = Color.Black,
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // 10. RATE US DIALOG
    if (showRateUsDialog) {
        var starRating by remember { mutableStateOf(0) }
        var isSubmitted by remember { mutableStateOf(false) }

        AlertDialog(
            onDismissRequest = { showRateUsDialog = false },
            containerColor = Color(0xFF101012),
            shape = RoundedCornerShape(24.dp),
            title = {
                Text("Rate Vidiopen Pro", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
            },
            text = {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(14.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    if (!isSubmitted) {
                        Text(
                            text = "Tap on stars to leave an active rating for our development team:",
                            color = Color.LightGray,
                            fontSize = 12.sp,
                            textAlign = TextAlign.Center
                        )
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            for (i in 1..5) {
                                Icon(
                                    imageVector = if (i <= starRating) Icons.Rounded.Star else Icons.Rounded.StarBorder,
                                    contentDescription = "Star $i",
                                    tint = if (i <= starRating) Color(0xFFFFD700) else Color.Gray,
                                    modifier = Modifier
                                        .size(36.dp)
                                        .clickable { starRating = i }
                                )
                            }
                        }
                        
                        val prompt = when (starRating) {
                            1 -> "We're extremely sorry! Tell us how to improve."
                            2 -> "We'll work hard to improve the offline player."
                            3 -> "Thanks! Tell us what features to add next."
                            4 -> "Great! We are glad you like the luxury player."
                            5 -> "Awesome! You made our developer's day!"
                            else -> "Tap to rate"
                        }
                        Text(prompt, color = Color(0xFF10B981), fontSize = 12.sp, fontWeight = FontWeight.Bold)

                        Button(
                            onClick = { isSubmitted = true },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF10B981)),
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(12.dp),
                            enabled = starRating > 0
                        ) {
                            Text("Submit Feedback", color = Color.Black, fontWeight = FontWeight.Bold)
                        }
                    } else {
                        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            Icon(Icons.Rounded.CheckCircle, contentDescription = null, tint = Color(0xFF10B981), modifier = Modifier.size(56.dp))
                            Text("Thank You for Rating!", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                            Text("Your active rating keeps Vidiopen Pro 100% ad-free and secure.", color = Color.Gray, fontSize = 11.sp, textAlign = TextAlign.Center)
                            
                            Button(
                                onClick = { 
                                    showRateUsDialog = false
                                    isSubmitted = false
                                    starRating = 0
                                },
                                modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = Color.White.copy(alpha = 0.12f))
                            ) {
                                Text("Close", color = Color.White)
                            }
                        }
                    }
                }
            },
            confirmButton = {}
        )
    }

    // 11. ABOUT DIALOG
    if (showAboutDialog) {
        AlertDialog(
            onDismissRequest = { showAboutDialog = false },
            containerColor = Color(0xFF101012),
            shape = RoundedCornerShape(24.dp),
            title = {
                Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
                    Icon(Icons.Rounded.PlayCircle, contentDescription = null, tint = Color(0xFF10B981), modifier = Modifier.size(48.dp))
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("Vidiopen Pro", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                    Text("Luxury Pro Edition • v1.0.0", color = Color.Gray, fontSize = 11.sp)
                }
            },
            text = {
                Column(
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.fillMaxWidth().verticalScroll(rememberScrollState())
                ) {
                    Text(
                        text = "Vidiopen Pro is an offline-first premium secure media player that stores and processes all your movie assets, MP3 files, history logs, and folder vaults strictly inside your local physical storage device. Zero network telemetry or third-party background integrations.",
                        color = Color.LightGray,
                        fontSize = 12.sp,
                        lineHeight = 18.sp,
                        textAlign = TextAlign.Center
                    )
                    Divider(color = Color.White.copy(alpha = 0.1f))
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Architecture", color = Color.Gray, fontSize = 11.sp)
                        Text("100% Secure Kotlin", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Support Email", color = Color.Gray, fontSize = 11.sp)
                        Text("abhayshukla8498@gmail.com", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Encryption Standard", color = Color.Gray, fontSize = 11.sp)
                        Text("AES-256 Vault Locker", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = { showAboutDialog = false },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF10B981)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Dismiss", color = Color.Black, fontWeight = FontWeight.Bold)
                }
            }
        )
    }

    // 12. PRIVACY POLICY DIALOG
    if (showPrivacyDialog) {
        androidx.compose.ui.window.Dialog(
            onDismissRequest = { showPrivacyDialog = false },
            properties = androidx.compose.ui.window.DialogProperties(
                usePlatformDefaultWidth = false,
                dismissOnBackPress = true,
                dismissOnClickOutside = false
            )
        ) {
            Surface(
                modifier = Modifier.fillMaxSize(),
                color = Color(0xFF070709)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .statusBarsPadding()
                        .navigationBarsPadding()
                ) {
                    // Header Bar
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(
                            onClick = { showPrivacyDialog = false },
                            modifier = Modifier.size(48.dp)
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Rounded.ArrowBack,
                                contentDescription = "Back",
                                tint = Color.White
                            )
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = if (appLang == "hi") "गोपनीयता नीति" else "Privacy Policy",
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                fontSize = 18.sp
                            )
                            Text(
                                text = "Vidiopen Security Hub",
                                color = Color.Gray,
                                fontSize = 11.sp
                            )
                        }
                        
                        // Shield Badge
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .background(Color(0xFF10B981).copy(alpha = 0.15f), CircleShape)
                                .border(1.dp, Color(0xFF10B981).copy(alpha = 0.3f), CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.Security,
                                contentDescription = null,
                                tint = Color(0xFF10B981),
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }

                    // Divider
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(1.dp)
                            .background(Color.White.copy(alpha = 0.08f))
                    )

                    // Scrollable steps content
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .verticalScroll(rememberScrollState())
                            .padding(horizontal = 16.dp, vertical = 16.dp),
                        verticalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        // Title Card
                        GlassCard(
                            modifier = Modifier.fillMaxWidth(),
                            cornerRadius = 16.dp
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Text(
                                    text = if (appLang == "hi") "Vidiopen के लिए गोपनीयता नीति" else "Privacy Policy for Vidiopen",
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 18.sp
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = if (appLang == "hi") "अंतिम अपडेट: 19 जुलाई, 2026" else "Last Updated: July 19, 2026",
                                    color = ElectricBlue,
                                    fontWeight = FontWeight.SemiBold,
                                    fontSize = 12.sp
                                )
                                Spacer(modifier = Modifier.height(12.dp))
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(1.dp)
                                        .background(Color.White.copy(alpha = 0.05f))
                                )
                                Spacer(modifier = Modifier.height(12.dp))
                                Text(
                                    text = if (appLang == "hi") {
                                        "Vidiopen (\"हम,\" \"हमारा,\" या \"हमें\") में आपका स्वागत है। हम आपकी गोपनीयता की रक्षा करने के लिए पूरी तरह से प्रतिबद्ध हैं। यह गोपनीयता नीति बताती है कि जब आप Vidiopen मोबाइल एप्लिकेशन का उपयोग करते हैं तो हम जानकारी और डेटा को कैसे संभालते हैं।"
                                    } else {
                                        "Welcome to Vidiopen (\"we,\" \"our,\" or \"us\"). We are highly committed to protecting your privacy. This Privacy Policy explains how we handle information and data when you use the Vidiopen mobile application."
                                    },
                                    color = Color.LightGray,
                                    fontSize = 13.sp,
                                    lineHeight = 20.sp
                                )
                            }
                        }

                        // STEP 1: Information We Access (Core Functionality)
                        PrivacyStepCard(
                            stepNumber = "1",
                            title = if (appLang == "hi") "जानकारी जिसे हम एक्सेस करते हैं (मुख्य कार्यक्षमता)" else "Information We Access (Core Functionality)",
                            icon = Icons.Rounded.Folder,
                            iconColor = ElectricBlue
                        ) {
                            Text(
                                text = if (appLang == "hi") {
                                    "आपको एक बेहतरीन वीडियो और ऑडियो प्लेबैक अनुभव प्रदान करने के लिए, Vidiopen को आपके डिवाइस पर कुछ सुविधाओं तक पहुंच की आवश्यकता होती है।"
                                } else {
                                    "To provide you with a seamless and high-quality video and audio playback experience, Vidiopen requires access to certain features on your device."
                                },
                                color = Color.LightGray,
                                fontSize = 13.sp,
                                lineHeight = 19.sp,
                                modifier = Modifier.padding(bottom = 8.dp)
                            )

                            PrivacySubPoint(
                                title = if (appLang == "hi") "स्टोरेज अनुमति (मीडिया फ़ाइलें)" else "Storage Permission (Media Files)",
                                description = if (appLang == "hi") {
                                    "Vidiopen आपके डिवाइस के आंतरिक स्टोरेज और एसडी कार्ड पर संग्रहीत वीडियो और ऑडियो फ़ाइलों को स्वचालित रूप से स्कैन, पहचान और व्यवस्थित करता है। इसका उपयोग केवल आपकी मीडिया फ़ाइलों को स्थानीय रूप से प्रदर्शित करने, स्मार्ट फ़ोल्डरों में व्यवस्थित करने और चलाने के लिए किया जाता है।"
                                } else {
                                    "Vidiopen automatically scans, detects, and organizes video and audio files stored on your device's internal storage and SD card. This is strictly used to display, organize into smart folders, and play your media files locally."
                                },
                                icon = Icons.Rounded.FolderSpecial,
                                iconColor = ElectricBlue
                            )

                            PrivacySubPoint(
                                title = if (appLang == "hi") "प्राइवेट फोल्डर फीचर्स" else "Private Folder Features",
                                description = if (appLang == "hi") {
                                    "कोई भी वीडियो या फ़ाइल जिसे आप \"प्राइवेट फ़ोल्डर\" में ले जाते हैं, वह आपके डिवाइस पर स्थानीय रूप से एन्क्रिप्टेड रहती है। हमारे पास आपकी निजी फ़ाइलों तक कोई पहुंच नहीं है, और न ही हम आपका पासवर्ड/पिन सहेजते हैं।"
                                } else {
                                    "Any video or file you move to the \"Private Folder\" remains encrypted locally on your device. We do not have access to your private files, nor do we store your password/PIN."
                                },
                                icon = Icons.Rounded.Lock,
                                iconColor = ElectricBlue
                            )

                            PrivacySubPoint(
                                title = if (appLang == "hi") "🔒 ज़ीरो सर्वर आर्किटेक्चर" else "🔒 Zero Server Architecture",
                                description = if (appLang == "hi") {
                                    "सभी मीडिया स्कैनिंग, processing और प्लेबैक स्थानीय रूप से आपके डिवाइस पर होते हैं। Vidiopen आपके किसी भी व्यक्तिगत वीडियो, ऑडियो या फ़ाइल को किसी बाहरी सर्वर पर अपलोड, एकत्र या स्थानांतरित नहीं करता है। आपकी फ़ाइलें कभी भी आपका फोन नहीं छोड़ती हैं।"
                                } else {
                                    "All media scanning, processing, and playback happen locally on your device. Vidiopen does not upload, collect, or transfer any of your personal videos, audios, or files to any external servers. Your files never leave your phone."
                                },
                                icon = Icons.Rounded.Security,
                                iconColor = Color(0xFF10B981)
                            )
                        }

                        // STEP 2: Information We Do NOT Collect
                        PrivacyStepCard(
                            stepNumber = "2",
                            title = if (appLang == "hi") "जानकारी जो हम एकत्र नहीं करते हैं" else "Information We Do NOT Collect",
                            icon = Icons.Rounded.CheckCircle,
                            iconColor = Color(0xFF10B981)
                        ) {
                            Text(
                                text = if (appLang == "hi") "हम पूर्ण उपयोगकर्ता गोपनीयता में विश्वास करते हैं।" else "We believe in absolute user privacy.",
                                color = Color.White,
                                fontWeight = FontWeight.SemiBold,
                                fontSize = 13.sp,
                                modifier = Modifier.padding(bottom = 8.dp)
                            )

                            PrivacySubPoint(
                                title = "",
                                description = if (appLang == "hi") {
                                    "हम व्यक्तिगत पहचान जानकारी (जैसे आपका नाम, ईमेल पता, फोन नंबर, या डिवाइस पहचानकर्ता) एकत्र नहीं करते हैं।"
                                } else {
                                    "We do not collect personal identification information (such as your name, email address, phone number, or device identifiers)."
                                },
                                icon = Icons.Rounded.CheckCircle,
                                iconColor = Color(0xFF10B981)
                            )

                            PrivacySubPoint(
                                title = "",
                                description = if (appLang == "hi") {
                                    "हम आपके वीडियो देखने के इतिहास, प्लेलिस्ट या खोज प्राथमिकताओं को ट्रैक नहीं करते हैं।"
                                } else {
                                    "We do not track your video viewing history, playlists, or search preferences."
                                },
                                icon = Icons.Rounded.CheckCircle,
                                iconColor = Color(0xFF10B981)
                            )
                        }

                        // STEP 3: Permissions Used & Why
                        PrivacyStepCard(
                            stepNumber = "3",
                            title = if (appLang == "hi") "उपयोग की जाने वाली अनुमतियाँ और क्यों" else "Permissions Used & Why",
                            icon = Icons.Rounded.Settings,
                            iconColor = RoyalPurple
                        ) {
                            Text(
                                text = if (appLang == "hi") {
                                    "Vidiopen एक उन्नत मीडिया प्लेयर के रूप में कार्य करने के लिए आवश्यक न्यूनतम अनुमतियों की मांग करता है:"
                                } else {
                                    "Vidiopen asks for minimal permissions required to function as an advanced media player:"
                                },
                                color = Color.LightGray,
                                fontSize = 13.sp,
                                lineHeight = 19.sp,
                                modifier = Modifier.padding(bottom = 8.dp)
                            )

                            PrivacySubPoint(
                                title = "READ_EXTERNAL_STORAGE / READ_MEDIA_VIDEO",
                                description = if (appLang == "hi") {
                                    "आपके डिवाइस से वीडियो फ़ाइलों को स्वचालित रूप से खोजने और उन्हें स्मार्ट फ़ोल्डरों में व्यवस्थित करने के लिए आवश्यक है।"
                                } else {
                                    "Required to auto-detect and organize video files from your device into smart folders."
                                },
                                icon = Icons.Rounded.Folder,
                                iconColor = RoyalPurple
                            )

                            PrivacySubPoint(
                                title = "WRITE_EXTERNAL_STORAGE",
                                description = if (appLang == "hi") {
                                    "आपको वीडियो हटाने या उनका नाम बदलने और MP4 फ़ाइलों को MP3 में बदलने की अनुमति देने के लिए आवश्यक है।"
                                } else {
                                    "Required to allow you to delete or rename videos and convert MP4 files to MP3."
                                },
                                icon = Icons.Rounded.Settings,
                                iconColor = RoyalPurple
                            )

                            PrivacySubPoint(
                                title = "FOREGROUND_SERVICE",
                                description = if (appLang == "hi") {
                                    "बैकग्राउंड प्ले फीचर को सक्षम करने के लिए आवश्यक है, जिससे ऐप के बंद होने या स्क्रीन लॉक होने पर भी वीडियो का ऑडियो सुचारू रूप से चलता रहे।"
                                } else {
                                    "Required to enable the Background Play feature, allowing the audio of your video to continue playing seamlessly when the app is minimized or the screen is locked."
                                },
                                icon = Icons.Rounded.Settings,
                                iconColor = RoyalPurple
                            )
                        }

                        // STEP 4: Data Security
                        PrivacyStepCard(
                            stepNumber = "4",
                            title = if (appLang == "hi") "डेटा सुरक्षा" else "Data Security",
                            icon = Icons.Rounded.Security,
                            iconColor = ElectricBlue
                        ) {
                            Text(
                                text = if (appLang == "hi") {
                                    "चूंकि आपकी सभी फाइलें आपके डिवाइस पर स्थानीय रूप से संग्रहीत हैं, इसलिए आपके डेटा की सुरक्षा आपके डिवाइस की सुरक्षा पर निर्भर करती है। प्राइवेट फ़ोल्डर सुविधा के लिए, कृपया सुनिश्चित करें कि आप अपना पिन/पासवर्ड याद रखें, क्योंकि हम अपने पूरी तरह से ऑफ़लाइन संचालन के कारण इसे आपके लिए पुनर्प्राप्त नहीं कर सकते हैं।"
                                } else {
                                    "Since all your files are stored locally on your device, the security of your data depends on your device's security. For the Private Folder feature, please ensure you remember your PIN/Password, as we cannot recover it for you due to our strictly offline operation."
                                },
                                color = Color.LightGray,
                                fontSize = 13.sp,
                                lineHeight = 19.sp
                            )
                        }

                        // STEP 5: Third-Party Services
                        PrivacyStepCard(
                            stepNumber = "5",
                            title = if (appLang == "hi") "तृतीय-पक्ष सेवाएँ" else "Third-Party Services",
                            icon = Icons.Rounded.Info,
                            iconColor = RoyalPurple
                        ) {
                            Text(
                                text = if (appLang == "hi") {
                                    "Vidiopen ऐप के भीतर विज्ञापन दिखाने के लिए तृतीय-पक्ष विज्ञापन नेटवर्क (जैसे Google AdMob) का उपयोग कर सकता है। ये तृतीय-पक्ष विक्रेता आपकी रुचियों के आधार पर विज्ञापन दिखाने के लिए अनाम डिवाइस पहचानकर्ता या कुकीज़ का उपयोग कर सकते हैं। आप इन सेटिंग्स को अपने Google खाते की विज्ञापन सेटिंग्स में प्रबंधित कर सकते हैं।"
                                } else {
                                    "Vidiopen may use third-party advertising networks (such as Google AdMob) to serve advertisements within the app. These third-party vendors may use anonymous device identifiers or cookies to serve ads based on your interests. You can manage these settings in your Google Account's Ad settings."
                                },
                                color = Color.LightGray,
                                fontSize = 13.sp,
                                lineHeight = 19.sp
                            )
                        }

                        // STEP 6: Changes to This Privacy Policy
                        PrivacyStepCard(
                            stepNumber = "6",
                            title = if (appLang == "hi") "इस गोपनीयता नीति में बदलाव" else "Changes to This Privacy Policy",
                            icon = Icons.Rounded.History,
                            iconColor = ElectricBlue
                        ) {
                            Text(
                                text = if (appLang == "hi") {
                                    "हम समय-समय पर अपनी गोपनीयता नीति को अपडेट कर सकते हैं। हम आपको किसी भी बदलाव के लिए समय-समय पर इस पृष्ठ की समीक्षा करने की सलाह देते हैं। बदलाव इस पृष्ठ पर पोस्ट होने के तुरंत बाद प्रभावी होते हैं।"
                                } else {
                                    "We may update our Privacy Policy from time to time. We advise you to review this page periodically for any changes. Changes are effective immediately after they are posted on this page."
                                },
                                color = Color.LightGray,
                                fontSize = 13.sp,
                                lineHeight = 19.sp
                            )
                        }

                        // STEP 7: Contact Us
                        PrivacyStepCard(
                            stepNumber = "7",
                            title = if (appLang == "hi") "हमसे संपर्क करें" else "Contact Us",
                            icon = Icons.Rounded.ChatBubbleOutline,
                            iconColor = Color(0xFF10B981)
                        ) {
                            Text(
                                text = if (appLang == "hi") {
                                    "यदि इस गोपनीयता नीति के बारे में आपके कोई प्रश्न, सुझाव या चिंताएँ हैं, तो कृपया बेझिझक हमसे यहाँ संपर्क करें:\nईमेल: abhayshukla8498@gmail.com"
                                } else {
                                    "If you have any questions, suggestions, or concerns about this Privacy Policy, please feel free to contact us at:\nEmail: abhayshukla8498@gmail.com"
                                },
                                color = Color.LightGray,
                                fontSize = 13.sp,
                                lineHeight = 19.sp
                            )
                            
                            Spacer(modifier = Modifier.height(14.dp))
                            
                            Button(
                                onClick = { sendSupportEmail() },
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF10B981)),
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.ChatBubbleOutline,
                                    contentDescription = null,
                                    tint = Color.Black,
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = if (appLang == "hi") "ईमेल भेजें" else "Send Email",
                                    color = Color.Black,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp
                                )
                            }
                        }
                        
                        Spacer(modifier = Modifier.height(32.dp))
                    }
                }
            }
        }
    }
}

@Composable
fun PrivacyStepCard(
    stepNumber: String,
    title: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    iconColor: Color = ElectricBlue,
    content: @Composable ColumnScope.() -> Unit
) {
    GlassCard(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        cornerRadius = 16.dp
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                Box(
                    modifier = Modifier
                        .size(32.dp)
                        .background(iconColor.copy(alpha = 0.1f), CircleShape)
                        .border(1.dp, iconColor.copy(alpha = 0.2f), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = null,
                        tint = iconColor,
                        modifier = Modifier.size(16.dp)
                    )
                }
                Spacer(modifier = Modifier.width(12.dp))
                if (stepNumber.isNotEmpty()) {
                    Text(
                        text = stepNumber,
                        color = iconColor,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp,
                        modifier = Modifier
                            .background(iconColor.copy(alpha = 0.1f), RoundedCornerShape(4.dp))
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                }
                Text(
                    text = title,
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    modifier = Modifier.weight(1f)
                )
            }
            Spacer(modifier = Modifier.height(12.dp))
            Box(modifier = Modifier.fillMaxWidth().height(1.dp).background(Color.White.copy(alpha = 0.05f)))
            Spacer(modifier = Modifier.height(12.dp))
            content()
        }
    }
}

@Composable
fun PrivacySubPoint(
    title: String,
    description: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector? = null,
    iconColor: Color = ElectricBlue
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp),
        verticalAlignment = Alignment.Top
    ) {
        if (icon != null) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = iconColor,
                modifier = Modifier
                    .padding(top = 2.dp)
                    .size(16.dp)
            )
            Spacer(modifier = Modifier.width(10.dp))
        } else {
            Box(
                modifier = Modifier
                    .padding(top = 6.dp)
                    .size(6.dp)
                    .background(iconColor, CircleShape)
            )
            Spacer(modifier = Modifier.width(10.dp))
        }
        Column(modifier = Modifier.weight(1f)) {
            if (title.isNotEmpty()) {
                Text(
                    text = title,
                    color = Color.White,
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 13.sp
                )
                Spacer(modifier = Modifier.height(2.dp))
            }
            Text(
                text = description,
                color = Color.LightGray,
                fontSize = 12.sp,
                lineHeight = 18.sp
            )
        }
    }
}

@Composable
fun SettingSwitchRow(
    title: String,
    subtitle: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit,
    icon: ImageVector? = null,
    tint: Color = ElectricBlue
) {
    GlassCard(modifier = Modifier.fillMaxWidth()) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.weight(1f)
            ) {
                if (icon != null) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .background(tint.copy(alpha = 0.12f), CircleShape)
                            .border(1.dp, tint.copy(alpha = 0.25f), CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = icon,
                            contentDescription = title,
                            tint = tint,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                }
                Column(modifier = Modifier.weight(1f)) {
                    Text(title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    Text(subtitle, color = Color.Gray, fontSize = 11.sp)
                }
            }
            Switch(
                checked = checked,
                onCheckedChange = onCheckedChange,
                colors = SwitchDefaults.colors(
                    checkedThumbColor = Color.Black,
                    checkedTrackColor = ElectricBlue
                )
            )
        }
    }
}

@Composable
fun SettingFeatureLinkRow(
    title: String,
    subtitle: String,
    icon: ImageVector,
    tint: Color,
    onClick: () -> Unit
) {
    val interactionSource = remember { MutableInteractionSource() }
    val isPressed by interactionSource.collectIsPressedAsState()
    
    val scale by animateFloatAsState(
        targetValue = if (isPressed) 0.95f else 1.0f,
        animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessLow),
        label = "SettingLinkScale"
    )

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .scale(scale)
            .clip(RoundedCornerShape(16.dp))
            .clickable(
                interactionSource = interactionSource,
                indication = null,
                onClick = onClick
            )
    ) {
        GlassCard(
            cornerRadius = 16.dp,
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(12.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    Box(
                        modifier = Modifier
                            .size(40.dp)
                            .background(tint.copy(alpha = 0.12f), CircleShape)
                            .border(1.5.dp, tint.copy(alpha = 0.35f), CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = icon,
                            contentDescription = title,
                            tint = tint,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(16.dp))
                    Column {
                        Text(
                            text = title,
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp
                        )
                        Text(
                            text = subtitle,
                            color = Color.LightGray,
                            fontSize = 11.sp
                        )
                    }
                }
                Icon(
                    imageVector = Icons.Rounded.ChevronRight,
                    contentDescription = "Navigate",
                    tint = Color.LightGray,
                    modifier = Modifier.size(24.dp)
                )
            }
        }
    }
}

@Composable
fun SettingSelectionRow(
    title: String,
    subtitle: String,
    onClick: () -> Unit,
    icon: ImageVector? = null,
    tint: Color = ElectricBlue
) {
    val interactionSource = remember { MutableInteractionSource() }
    val isPressed by interactionSource.collectIsPressedAsState()
    
    val scale by animateFloatAsState(
        targetValue = if (isPressed) 0.98f else 1.0f,
        animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessLow),
        label = "SettingSelectionScale"
    )

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .scale(scale)
            .clip(RoundedCornerShape(16.dp))
            .clickable(
                interactionSource = interactionSource,
                indication = null,
                onClick = onClick
            )
    ) {
        GlassCard(
            cornerRadius = 16.dp,
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(12.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    if (icon != null) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .background(tint.copy(alpha = 0.12f), CircleShape)
                                .border(1.dp, tint.copy(alpha = 0.25f), CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = icon,
                                contentDescription = title,
                                tint = tint,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                    }
                    Column {
                        Text(
                            text = title,
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp
                        )
                        Text(
                            text = subtitle,
                            color = Color.Gray,
                            fontSize = 11.sp
                        )
                    }
                }
                Icon(
                    imageVector = Icons.Rounded.ChevronRight,
                    contentDescription = "Configure",
                    tint = Color.LightGray,
                    modifier = Modifier.size(24.dp)
                )
            }
        }
    }
}

// ==========================================
// PRIVATE VAULT SCREEN (PRODUCTION SECURE VAULT)
// ==========================================

// Helper to find FragmentActivity from context for Biometrics
private fun Context.findActivity(): FragmentActivity? {
    var currentContext = this
    while (currentContext is ContextWrapper) {
        if (currentContext is FragmentActivity) {
            return currentContext
        }
        currentContext = currentContext.baseContext
    }
    return null
}

// Biometric helper
private fun triggerBiometricPrompt(
    context: Context,
    onSuccess: () -> Unit,
    onError: (String) -> Unit
) {
    val activity = context.findActivity()
    if (activity == null) {
        onError("Biometrics failed: Parent activity context is unavailable.")
        return
    }
    val executor = ContextCompat.getMainExecutor(context)
    val biometricPrompt = BiometricPrompt(activity, executor, object : BiometricPrompt.AuthenticationCallback() {
        override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
            super.onAuthenticationSucceeded(result)
            onSuccess()
        }
        override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
            super.onAuthenticationError(errorCode, errString)
            onError(errString.toString())
        }
    })

    val promptInfo = BiometricPrompt.PromptInfo.Builder()
        .setTitle("Nova Vault Verification")
        .setSubtitle("Authenticate with your fingerprint to enter the private area")
        .setNegativeButtonText("Use Credentials")
        .build()

    try {
        biometricPrompt.authenticate(promptInfo)
    } catch (e: Exception) {
        onError("Biometric authentication failed: ${e.localizedMessage}")
    }
}

// Format duration helper
private fun formatVaultDuration(ms: Long): String {
    val totalSec = ms / 1000
    val min = totalSec / 60
    val sec = totalSec % 60
    return String.format("%02d:%02d", min, sec)
}

// Secure Video Player View
@Composable
fun VaultVideoPlayerView(
    file: java.io.File,
    title: String,
    onClose: () -> Unit
) {
    val context = LocalContext.current
    val exoPlayer = remember {
        androidx.media3.exoplayer.ExoPlayer.Builder(context).build().apply {
            val mediaItem = androidx.media3.common.MediaItem.fromUri(android.net.Uri.fromFile(file))
            setMediaItem(mediaItem)
            prepare()
            playWhenReady = true
        }
    }

    DisposableEffect(Unit) {
        val activity = context as? android.app.Activity
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            val isScreenHdr = context.resources.configuration.isScreenHdr
            val isEmulator = android.os.Build.FINGERPRINT.startsWith("generic") 
                    || android.os.Build.MODEL.contains("google_sdk") 
                    || android.os.Build.MODEL.contains("Emulator") 
                    || android.os.Build.MODEL.contains("Android SDK built for x86")
            if (isScreenHdr && !isEmulator) {
                activity?.window?.colorMode = android.content.pm.ActivityInfo.COLOR_MODE_HDR
            }
        }
        onDispose {
            exoPlayer.release()
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                activity?.window?.colorMode = android.content.pm.ActivityInfo.COLOR_MODE_DEFAULT
            }
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black)
    ) {
        androidx.compose.ui.viewinterop.AndroidView(
            factory = { ctx ->
                androidx.media3.ui.PlayerView(ctx).apply {
                    player = exoPlayer
                    useController = true
                }
            },
            modifier = Modifier.fillMaxSize()
        )

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .statusBarsPadding()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(
                onClick = onClose,
                modifier = Modifier.background(Color.Black.copy(alpha = 0.5f), CircleShape)
            ) {
                Icon(Icons.Rounded.ArrowBack, contentDescription = "Close Video", tint = Color.White)
            }
            Spacer(modifier = Modifier.width(16.dp))
            Text(
                text = title,
                color = Color.White,
                fontWeight = FontWeight.Bold,
                fontSize = 16.sp,
                maxLines = 1,
                modifier = Modifier
                    .weight(1f)
                    .background(Color.Black.copy(alpha = 0.5f), RoundedCornerShape(8.dp))
                    .padding(8.dp)
            )
        }
    }
}

// Secure Audio Player View
@Composable
fun VaultAudioPlayerView(
    file: java.io.File,
    title: String,
    onClose: () -> Unit
) {
    val context = LocalContext.current
    val exoPlayer = remember {
        androidx.media3.exoplayer.ExoPlayer.Builder(context).build().apply {
            val mediaItem = androidx.media3.common.MediaItem.fromUri(android.net.Uri.fromFile(file))
            setMediaItem(mediaItem)
            prepare()
            playWhenReady = true
        }
    }

    var isPlaying by remember { mutableStateOf(true) }
    var duration by remember { mutableStateOf(0L) }
    var currentPosition by remember { mutableStateOf(0L) }

    LaunchedEffect(exoPlayer) {
        while (true) {
            isPlaying = exoPlayer.isPlaying
            currentPosition = exoPlayer.currentPosition
            duration = exoPlayer.duration.coerceAtLeast(0L)
            kotlinx.coroutines.delay(500)
        }
    }

    DisposableEffect(Unit) {
        onDispose {
            exoPlayer.release()
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
            modifier = Modifier
                .fillMaxWidth()
                .padding(24.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(220.dp)
                    .clip(CircleShape)
                    .background(
                        Brush.radialGradient(
                            listOf(RoyalPurple.copy(alpha = 0.6f), Color.Black),
                            radius = 350f
                        )
                    )
                    .border(2.dp, ElectricBlue, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Rounded.MusicNote,
                    contentDescription = null,
                    tint = ElectricBlue,
                    modifier = Modifier.size(90.dp)
                )
            }

            Spacer(modifier = Modifier.height(36.dp))

            Text(
                text = title,
                color = Color.White,
                fontWeight = FontWeight.Bold,
                fontSize = 20.sp,
                textAlign = TextAlign.Center,
                maxLines = 2
            )
            Text(
                text = "Secured Vault Audio Track",
                color = Color.Gray,
                fontSize = 12.sp,
                modifier = Modifier.padding(top = 4.dp)
            )

            Spacer(modifier = Modifier.height(36.dp))

            Slider(
                value = if (duration > 0) currentPosition.toFloat() / duration.toFloat() else 0f,
                onValueChange = { ratio ->
                    val dest = (ratio * duration).toLong()
                    exoPlayer.seekTo(dest)
                },
                colors = SliderDefaults.colors(
                    thumbColor = ElectricBlue,
                    activeTrackColor = ElectricBlue,
                    inactiveTrackColor = Color.White.copy(alpha = 0.2f)
                ),
                modifier = Modifier.fillMaxWidth()
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = formatVaultDuration(currentPosition),
                    color = Color.Gray,
                    fontSize = 11.sp
                )
                Text(
                    text = formatVaultDuration(duration),
                    color = Color.Gray,
                    fontSize = 11.sp
                )
            }

            Spacer(modifier = Modifier.height(32.dp))

            Row(
                horizontalArrangement = Arrangement.spacedBy(28.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = { exoPlayer.seekTo((currentPosition - 10000).coerceAtLeast(0L)) },
                    modifier = Modifier.background(Color.White.copy(alpha = 0.05f), CircleShape)
                ) {
                    Icon(Icons.Rounded.Replay10, contentDescription = "Rewind 10s", tint = Color.White)
                }

                IconButton(
                    onClick = {
                        if (isPlaying) {
                            exoPlayer.pause()
                        } else {
                            exoPlayer.play()
                        }
                    },
                    modifier = Modifier
                        .size(72.dp)
                        .background(ElectricBlue, CircleShape)
                ) {
                    Icon(
                        imageVector = if (isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                        contentDescription = "Play/Pause",
                        tint = Color.Black,
                        modifier = Modifier.size(36.dp)
                    )
                }

                IconButton(
                    onClick = { exoPlayer.seekTo((currentPosition + 10000).coerceAtMost(duration)) },
                    modifier = Modifier.background(Color.White.copy(alpha = 0.05f), CircleShape)
                ) {
                    Icon(Icons.Rounded.Forward10, contentDescription = "Forward 10s", tint = Color.White)
                }
            }
        }

        IconButton(
            onClick = onClose,
            modifier = Modifier
                .align(Alignment.TopStart)
                .statusBarsPadding()
                .padding(16.dp)
                .background(Color.Black.copy(alpha = 0.5f), CircleShape)
        ) {
            Icon(Icons.Rounded.ArrowBack, contentDescription = "Close", tint = Color.White)
        }
    }
}

// Secure Photo Viewer View
@Composable
fun VaultPhotoViewer(
    file: java.io.File,
    title: String,
    onClose: () -> Unit
) {
    val bitmap = remember(file) {
        try {
            android.graphics.BitmapFactory.decodeFile(file.absolutePath)
        } catch (e: Exception) {
            null
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black)
    ) {
        if (bitmap != null) {
            Image(
                bitmap = bitmap.asImageBitmap(),
                contentDescription = title,
                modifier = Modifier
                    .fillMaxSize()
                    .align(Alignment.Center),
                contentScale = ContentScale.Fit
            )
        } else {
            Column(
                modifier = Modifier.align(Alignment.Center),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(Icons.Rounded.BrokenImage, contentDescription = null, tint = Color.Red, modifier = Modifier.size(48.dp))
                Text("Failed to render encrypted photo", color = Color.Gray, fontSize = 14.sp)
            }
        }

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .statusBarsPadding()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(
                onClick = onClose,
                modifier = Modifier.background(Color.Black.copy(alpha = 0.5f), CircleShape)
            ) {
                Icon(Icons.Rounded.ArrowBack, contentDescription = "Close Photo", tint = Color.White)
            }
            Spacer(modifier = Modifier.width(16.dp))
            Text(
                text = title,
                color = Color.White,
                fontWeight = FontWeight.Bold,
                fontSize = 16.sp,
                maxLines = 1,
                modifier = Modifier
                    .weight(1f)
                    .background(Color.Black.copy(alpha = 0.5f), RoundedCornerShape(8.dp))
                    .padding(8.dp)
            )
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PrivateVaultScreen(
    viewModel: MediaViewModel,
    onBack: () -> Unit = {},
    vaultViewModel: VaultViewModel = androidx.lifecycle.viewmodel.compose.viewModel(
        factory = VaultViewModelFactory(
            application = LocalContext.current.applicationContext as android.app.Application,
            repository = (LocalContext.current.applicationContext as com.example.NovaPlayApplication).container.mediaRepository
        )
    )
) {
    val context = LocalContext.current

    // Bind state flows
    val isUnlocked by vaultViewModel.isUnlocked.collectAsState()
    val unlockMethod by vaultViewModel.unlockMethod.collectAsState()
    val hasPin by vaultViewModel.hasPin.collectAsState()
    val hasPattern by vaultViewModel.hasPattern.collectAsState()
    val hasPassword by vaultViewModel.hasPassword.collectAsState()
    val isBiometricEnabled by vaultViewModel.isBiometricEnabled.collectAsState()
    val autoLockTimeout by vaultViewModel.autoLockTimeout.collectAsState()
    val activeSection by vaultViewModel.activeSection.collectAsState()

    // Sub-category items
    val videosList by vaultViewModel.videos.collectAsState()
    val photosList by vaultViewModel.photos.collectAsState()
    val audioList by vaultViewModel.audio.collectAsState()
    val documentsList by vaultViewModel.documents.collectAsState()
    val favoritesList by vaultViewModel.favorites.collectAsState()
    val recentlyAddedList by vaultViewModel.recentlyAdded.collectAsState()

    // Active decrypted files for immediate play/view
    val activeDecryptedFile by vaultViewModel.activeDecryptedFile.collectAsState()
    val activeDecryptedItem by vaultViewModel.activeDecryptedItem.collectAsState()

    // Screen states
    val appLang by viewModel.appLanguage.collectAsState()
    val selectedThemeId by viewModel.selectedThemeId.collectAsState()
    val customBgUri by viewModel.customBackgroundUri.collectAsState()
    var enteredPin by remember { mutableStateOf("") }
    var firstAttemptPin by remember { mutableStateOf("") }
    var isConfirming by remember { mutableStateOf(false) }
    var authErrorMessage by remember { mutableStateOf("") }

    var showSettingsSheet by remember { mutableStateOf(false) }
    var fileImportError by remember { mutableStateOf<String?>(null) }

    // States for custom privacy file renaming
    var pickedUriForRename by remember { mutableStateOf<android.net.Uri?>(null) }
    var pickedTypeForRename by remember { mutableStateOf<String?>(null) }
    var privateRenameValue by remember { mutableStateOf("") }

    // Dialog for Delete Original Confirmation
    var fileToDeleteAfterImport by remember { mutableStateOf<java.io.File?>(null) }
    var showDeleteOriginalDialog by remember { mutableStateOf(false) }

    // File Pickers Launchers
    val videoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri ->
        uri?.let {
            pickedUriForRename = it
            pickedTypeForRename = "VIDEO"
            privateRenameValue = "Privacy_Video_" + (System.currentTimeMillis() % 100000)
        }
    }

    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri ->
        uri?.let {
            pickedUriForRename = it
            pickedTypeForRename = "PHOTO"
            privateRenameValue = "Privacy_Photo_" + (System.currentTimeMillis() % 100000)
        }
    }

    val audioPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri ->
        uri?.let {
            pickedUriForRename = it
            pickedTypeForRename = "AUDIO"
            privateRenameValue = "Privacy_Audio_" + (System.currentTimeMillis() % 100000)
        }
    }

    val documentPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri ->
        uri?.let {
            pickedUriForRename = it
            pickedTypeForRename = "DOCUMENT"
            privateRenameValue = "Privacy_Doc_" + (System.currentTimeMillis() % 100000)
        }
    }

    // Auto-lock lifecycle observer
    val lifecycleOwner = androidx.lifecycle.compose.LocalLifecycleOwner.current
    DisposableEffect(lifecycleOwner) {
        val observer = androidx.lifecycle.LifecycleEventObserver { _, event ->
            if (event == androidx.lifecycle.Lifecycle.Event.ON_STOP) {
                vaultViewModel.onAppGoToBackground()
            } else if (event == androidx.lifecycle.Lifecycle.Event.ON_START) {
                vaultViewModel.onAppReturnToForeground()
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose {
            lifecycleOwner.lifecycle.removeObserver(observer)
        }
    }

    // Trigger fingerprint prompt on screen launch if biometrics is enabled
    LaunchedEffect(isUnlocked) {
        if (!isUnlocked && isBiometricEnabled) {
            val biometricManager = BiometricManager.from(context)
            val canAuthenticate = biometricManager.canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_STRONG) == BiometricManager.BIOMETRIC_SUCCESS
            if (canAuthenticate) {
                triggerBiometricPrompt(context,
                    onSuccess = { vaultViewModel.verifyBiometricSuccess() },
                    onError = { authErrorMessage = it }
                )
            }
        }
    }

    // Main layout container
    Box(
        modifier = Modifier
            .fillMaxSize()
    ) {
        AppThemeBackground(
            selectedThemeId = selectedThemeId,
            customBackgroundUri = customBgUri
        )
        if (!isUnlocked) {
            // Force preferred unlock method to PIN for the Privacy feature
            if (unlockMethod != "PIN") {
                LaunchedEffect(Unit) {
                    vaultViewModel.setUnlockMethod("PIN")
                }
            }

            // Automatic PIN state transition handler
            LaunchedEffect(enteredPin) {
                if (enteredPin.length == 4) {
                    kotlinx.coroutines.delay(150)
                    if (!hasPin) {
                        if (!isConfirming) {
                            firstAttemptPin = enteredPin
                            enteredPin = ""
                            isConfirming = true
                            authErrorMessage = ""
                        } else {
                            if (enteredPin == firstAttemptPin) {
                                vaultViewModel.savePin(enteredPin)
                                enteredPin = ""
                                firstAttemptPin = ""
                                isConfirming = false
                                authErrorMessage = ""
                            } else {
                                authErrorMessage = if (appLang == "hi") "पिन मेल नहीं खाते! फिर से प्रयास करें।" else "PINs do not match! Start over."
                                enteredPin = ""
                                firstAttemptPin = ""
                                isConfirming = false
                            }
                        }
                    } else {
                        val success = vaultViewModel.verifyUnlock(enteredPin)
                        if (success) {
                            enteredPin = ""
                            authErrorMessage = ""
                        } else {
                            authErrorMessage = if (appLang == "hi") "गलत पिन! फिर से कोशिश करें।" else "Incorrect PIN! Try again."
                            enteredPin = ""
                        }
                    }
                }
            }

            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .statusBarsPadding()
                    .navigationBarsPadding()
            ) {
                // Header Bar (Matches design header "← Set Password")
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(56.dp)
                        .padding(horizontal = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = { onBack() }) {
                        Icon(
                            imageVector = Icons.Rounded.ArrowBack,
                            contentDescription = "Back",
                            tint = Color.White,
                            modifier = Modifier.size(24.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Text(
                        text = if (!hasPin) {
                            if (appLang == "hi") "पासवर्ड सेट करें" else "Set Password"
                        } else {
                            if (appLang == "hi") "गोपनीयता" else "Privacy"
                        },
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 20.sp
                    )
                }

                // PIN content and Keypad layout
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(bottom = 24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.padding(top = 40.dp)
                    ) {
                        val instructionText = if (!hasPin) {
                            if (!isConfirming) {
                                if (appLang == "hi") "अपनी गोपनीयता की सुरक्षा के लिए पिन बनाएं" else "Create PIN to protect your privacy"
                            } else {
                                if (appLang == "hi") "अपने पासवर्ड की पुष्टि करें" else "Confirm your password"
                            }
                        } else {
                            if (appLang == "hi") "अपनी गोपनीयता की सुरक्षा के लिए पिन डालें" else "Enter PIN to protect your privacy"
                        }

                        Text(
                            text = instructionText,
                            color = Color.White,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Normal,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.padding(horizontal = 24.dp)
                        )

                        Spacer(modifier = Modifier.height(36.dp))

                        // Row of 4 squares
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(16.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            repeat(4) { index ->
                                val isFilled = index < enteredPin.length
                                val isActive = index == enteredPin.length
                                
                                Box(
                                    modifier = Modifier
                                        .size(60.dp)
                                        .clip(RoundedCornerShape(12.dp))
                                        .background(Color(0xFF262626)) // Dark gray square from image
                                        .then(
                                            if (isActive) Modifier.border(2.dp, Color(0xFF10B981), RoundedCornerShape(12.dp))
                                            else Modifier
                                        ),
                                    contentAlignment = Alignment.Center
                                ) {
                                    if (isFilled) {
                                        Box(
                                            modifier = Modifier
                                                .size(12.dp)
                                                .clip(CircleShape)
                                                .background(Color.White)
                                        )
                                    } else if (isActive) {
                                        Box(
                                            modifier = Modifier
                                                .width(2.dp)
                                                .height(20.dp)
                                                .background(Color(0xFF10B981))
                                        )
                                    }
                                }
                            }
                        }

                        if (authErrorMessage.isNotEmpty()) {
                            Spacer(modifier = Modifier.height(16.dp))
                            Text(
                                text = authErrorMessage,
                                color = Color.Red,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Medium,
                                textAlign = TextAlign.Center,
                                modifier = Modifier.padding(horizontal = 24.dp)
                            )
                        }
                    }

                    // Keypad
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(start = 32.dp, end = 32.dp, bottom = 16.dp),
                        verticalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        val leftKey = if (isBiometricEnabled && hasPin) "biometric" else ""
                        val rows = listOf(
                            listOf("1", "2", "3"),
                            listOf("4", "5", "6"),
                            listOf("7", "8", "9"),
                            listOf(leftKey, "0", "backspace")
                        )

                        rows.forEach { row ->
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                row.forEach { key ->
                                    Box(
                                        modifier = Modifier
                                            .weight(1f)
                                            .height(72.dp)
                                            .clickable(
                                                enabled = key.isNotEmpty(),
                                                onClick = {
                                                    if (key == "backspace") {
                                                        if (enteredPin.isNotEmpty()) {
                                                            enteredPin = enteredPin.dropLast(1)
                                                        }
                                                    } else if (key == "biometric") {
                                                        triggerBiometricPrompt(context,
                                                            onSuccess = { vaultViewModel.verifyBiometricSuccess() },
                                                            onError = { authErrorMessage = it }
                                                        )
                                                    } else if (key.isNotEmpty()) {
                                                        if (enteredPin.length < 4) {
                                                            enteredPin += key
                                                            authErrorMessage = ""
                                                        }
                                                    }
                                                }
                                            ),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        if (key == "backspace") {
                                            Icon(
                                                imageVector = Icons.Rounded.Backspace,
                                                contentDescription = "Backspace",
                                                tint = Color.White,
                                                modifier = Modifier.size(28.dp)
                                            )
                                        } else if (key == "biometric") {
                                            Icon(
                                                imageVector = Icons.Rounded.Fingerprint,
                                                contentDescription = "Biometric",
                                                tint = Color(0xFF10B981),
                                                modifier = Modifier.size(32.dp)
                                            )
                                        } else if (key.isNotEmpty()) {
                                            Text(
                                                text = key,
                                                color = Color.White,
                                                fontSize = 28.sp,
                                                fontWeight = FontWeight.Normal
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        } else {
            // --- VAULT HOME DASHBOARD SCREEN ---
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 16.dp)
            ) {
                Spacer(modifier = Modifier.height(60.dp))

                // Vault Header Actions
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(
                        onClick = {
                            if (activeSection != "HOME") {
                                vaultViewModel.setActiveSection("HOME")
                            } else {
                                vaultViewModel.lock()
                            }
                        }
                    ) {
                        Icon(
                            imageVector = if (activeSection != "HOME") Icons.Rounded.ArrowBack else Icons.Rounded.LockOpen,
                            contentDescription = "Lock",
                            tint = ElectricBlue
                        )
                    }

                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = if (activeSection == "HOME") { if (appLang == "hi") "गोपनीयता" else "Privacy" } else activeSection,
                            fontSize = 24.sp,
                            fontWeight = FontWeight.Black,
                            color = Color.White
                        )
                        GlowText("AES Keystore Secure", color = RoyalPurple, fontSize = 11.sp)
                    }

                    IconButton(onClick = { showSettingsSheet = true }) {
                        Icon(Icons.Rounded.Settings, contentDescription = "Settings", tint = Color.Gray)
                    }
                }

                Spacer(modifier = Modifier.height(24.dp))

                if (activeSection == "HOME") {
                    // --- VAULT HOME SECTIONS (VIDEOS, PHOTOS, MUSIC, DOCUMENTS, FAVORITES) ---
                    Column(
                        verticalArrangement = Arrangement.spacedBy(16.dp),
                        modifier = Modifier
                            .weight(1f)
                            .verticalScroll(rememberScrollState())
                    ) {
                        // Category Cards Grid
                        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            VaultCategoryCard(
                                title = "Videos",
                                count = videosList.size,
                                icon = Icons.Rounded.VideoLibrary,
                                color = ElectricBlue,
                                onClick = { vaultViewModel.setActiveSection("VIDEOS") },
                                modifier = Modifier.weight(1f)
                            )
                            VaultCategoryCard(
                                title = "Photos",
                                count = photosList.size,
                                icon = Icons.Rounded.PhotoLibrary,
                                color = Color(0xFFFF4081),
                                onClick = { vaultViewModel.setActiveSection("PHOTOS") },
                                modifier = Modifier.weight(1f)
                            )
                        }

                        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            VaultCategoryCard(
                                title = "Music",
                                count = audioList.size,
                                icon = Icons.Rounded.LibraryMusic,
                                color = RoyalPurple,
                                onClick = { vaultViewModel.setActiveSection("MUSIC") },
                                modifier = Modifier.weight(1f)
                            )
                            VaultCategoryCard(
                                title = "Documents",
                                count = documentsList.size,
                                icon = Icons.Rounded.FolderOpen,
                                color = Color(0xFFFFB300),
                                onClick = { vaultViewModel.setActiveSection("DOCUMENTS") },
                                modifier = Modifier.weight(1f)
                            )
                        }

                        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            VaultCategoryCard(
                                title = "Favorites",
                                count = favoritesList.size,
                                icon = Icons.Rounded.Favorite,
                                color = Color.Red,
                                onClick = { vaultViewModel.setActiveSection("FAVORITES") },
                                modifier = Modifier.weight(1.0f)
                            )
                        }

                        // Recently Added Section
                        if (recentlyAddedList.isNotEmpty()) {
                            Spacer(modifier = Modifier.height(16.dp))
                            Text(
                                "Recently Added",
                                color = Color.White,
                                fontWeight = FontWeight.Black,
                                fontSize = 18.sp
                            )
                            Spacer(modifier = Modifier.height(8.dp))

                            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                recentlyAddedList.take(3).forEach { item ->
                                    GlassCard(modifier = Modifier.fillMaxWidth().clickable {
                                        vaultViewModel.selectItemForPlaybackOrView(item, onError = { fileImportError = it })
                                    }) {
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            modifier = Modifier.fillMaxWidth()
                                        ) {
                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                val icon = when (item.type) {
                                                    "VIDEO" -> Icons.Rounded.VideoLibrary
                                                    "PHOTO" -> Icons.Rounded.Photo
                                                    "AUDIO" -> Icons.Rounded.Audiotrack
                                                    else -> Icons.Rounded.Description
                                                }
                                                val tint = when (item.type) {
                                                    "VIDEO" -> ElectricBlue
                                                    "PHOTO" -> Color(0xFFFF4081)
                                                    "AUDIO" -> RoyalPurple
                                                    else -> Color(0xFFFFB300)
                                                }
                                                Icon(icon, contentDescription = null, tint = tint, modifier = Modifier.size(24.dp))
                                                Spacer(modifier = Modifier.width(16.dp))
                                                Column {
                                                    Text(item.title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                                    Text("Encrypted & Secure", color = Color.Gray, fontSize = 11.sp)
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }

                        // Bottom Spacer for scrolling
                        Spacer(modifier = Modifier.height(80.dp))
                    }

                    // Floating action menu for imports
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 16.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(12.dp),
                            modifier = Modifier
                                .background(Color.Black.copy(alpha = 0.8f), RoundedCornerShape(32.dp))
                                .border(1.dp, Color.White.copy(alpha = 0.1f), RoundedCornerShape(32.dp))
                                .padding(horizontal = 20.dp, vertical = 10.dp)
                        ) {
                            IconButton(onClick = { videoPickerLauncher.launch("video/*") }) {
                                Icon(Icons.Rounded.VideoCall, contentDescription = "Import Video", tint = ElectricBlue)
                            }
                            IconButton(onClick = { photoPickerLauncher.launch("image/*") }) {
                                Icon(Icons.Rounded.AddAPhoto, contentDescription = "Import Photo", tint = Color(0xFFFF4081))
                            }
                            IconButton(onClick = { audioPickerLauncher.launch("audio/*") }) {
                                Icon(Icons.Rounded.AudioFile, contentDescription = "Import Audio", tint = RoyalPurple)
                            }
                            IconButton(onClick = { documentPickerLauncher.launch("*/*") }) {
                                Icon(Icons.Rounded.NoteAdd, contentDescription = "Import Document", tint = Color(0xFFFFB300))
                            }
                        }
                    }

                } else {
                    // --- SUB-CATEGORIES ITEMS LIST ---
                    val activeList = when (activeSection) {
                        "VIDEOS" -> videosList
                        "PHOTOS" -> photosList
                        "MUSIC" -> audioList
                        "DOCUMENTS" -> documentsList
                        "FAVORITES" -> favoritesList
                        else -> emptyList()
                    }

                    if (activeList.isEmpty()) {
                        val icon = when (activeSection) {
                            "VIDEOS" -> Icons.Rounded.VideoLibrary
                            "PHOTOS" -> Icons.Rounded.PhotoLibrary
                            "MUSIC" -> Icons.Rounded.LibraryMusic
                            "DOCUMENTS" -> Icons.Rounded.FolderZip
                            else -> Icons.Rounded.Favorite
                        }
                        ElegantVaultEmptyState(
                            icon = icon,
                            title = "No secret files yet",
                            description = "Use the import shortcuts in the dashboard to add files safely here."
                        )
                    } else {
                        LazyColumn(
                            modifier = Modifier.weight(1f),
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            items(activeList) { item ->
                                GlassCard(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable {
                                            vaultViewModel.selectItemForPlaybackOrView(item, onError = { fileImportError = it })
                                        }
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            modifier = Modifier.weight(1f)
                                        ) {
                                            val icon = when (item.type) {
                                                "VIDEO" -> Icons.Rounded.VideoLibrary
                                                "PHOTO" -> Icons.Rounded.Photo
                                                "AUDIO" -> Icons.Rounded.Audiotrack
                                                else -> Icons.Rounded.Description
                                            }
                                            val tint = when (item.type) {
                                                "VIDEO" -> ElectricBlue
                                                "PHOTO" -> Color(0xFFFF4081)
                                                "AUDIO" -> RoyalPurple
                                                else -> Color(0xFFFFB300)
                                            }
                                            Icon(icon, contentDescription = null, tint = tint, modifier = Modifier.size(24.dp))
                                            Spacer(modifier = Modifier.width(16.dp))
                                            Column {
                                                Text(item.title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                                Text(
                                                    text = "Added: ${android.text.format.DateFormat.format("MMM dd, yyyy", item.addedDate)}",
                                                    color = Color.Gray,
                                                    fontSize = 11.sp
                                                )
                                            }
                                        }

                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            IconButton(onClick = { vaultViewModel.toggleVaultFavorite(item) }) {
                                                Icon(
                                                    imageVector = if (item.isFavorite) Icons.Rounded.Favorite else Icons.Rounded.FavoriteBorder,
                                                    contentDescription = "Favorite",
                                                    tint = if (item.isFavorite) Color.Red else Color.Gray
                                                )
                                            }

                                            IconButton(
                                                onClick = {
                                                    val exportDir = File(
                                                        context.getExternalFilesDir(null), 
                                                        "VaultExports"
                                                    )
                                                    vaultViewModel.exportVaultItem(item, exportDir,
                                                        onSuccess = { msg -> fileImportError = msg },
                                                        onError = { err -> fileImportError = err }
                                                    )
                                                }
                                            ) {
                                                Icon(Icons.Rounded.IosShare, contentDescription = "Export file", tint = ElectricBlue)
                                            }

                                            IconButton(onClick = { vaultViewModel.deleteVaultItem(item) }) {
                                                Icon(Icons.Rounded.Delete, contentDescription = "Delete", tint = Color.Gray)
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // --- INTERNAL SECURE PLAYERS / VIEWERS LAYER ---
        activeDecryptedFile?.let { tempFile ->
            val item = activeDecryptedItem
            if (item != null) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(Color.Black)
                ) {
                    when (item.type) {
                        "VIDEO" -> {
                            VaultVideoPlayerView(
                                file = tempFile,
                                title = item.title,
                                onClose = { vaultViewModel.dismissActiveViewer() }
                            )
                        }
                        "AUDIO" -> {
                            VaultAudioPlayerView(
                                file = tempFile,
                                title = item.title,
                                onClose = { vaultViewModel.dismissActiveViewer() }
                            )
                        }
                        "PHOTO" -> {
                            VaultPhotoViewer(
                                file = tempFile,
                                title = item.title,
                                onClose = { vaultViewModel.dismissActiveViewer() }
                            )
                        }
                        "DOCUMENT" -> {
                            SecureDocumentReader(
                                file = tempFile,
                                title = item.title,
                                onBack = { vaultViewModel.dismissActiveViewer() },
                                onExport = {
                                    val exportDir = File(
                                        context.getExternalFilesDir(null), 
                                        "VaultExports"
                                    )
                                    vaultViewModel.exportVaultItem(item, exportDir,
                                        onSuccess = { msg -> fileImportError = msg },
                                        onError = { err -> fileImportError = err }
                                    )
                                }
                            )
                        }
                    }
                }
            }
        }

        // --- SETTINGS DIALOG / BOTTOM SHEET ---
        if (showSettingsSheet) {
            ModalBottomSheet(
                onDismissRequest = { showSettingsSheet = false },
                containerColor = Color(0xFF161622),
                contentColor = Color.White
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(24.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    Text(
                        "Vault Settings",
                        color = Color.White,
                        fontWeight = FontWeight.Black,
                        fontSize = 20.sp
                    )

                    Divider(color = Color.White.copy(alpha = 0.08f))

                    // Reset security PIN option
                    Button(
                        onClick = {
                            vaultViewModel.resetPin()
                            enteredPin = ""
                            firstAttemptPin = ""
                            isConfirming = false
                            authErrorMessage = ""
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color.Red.copy(alpha = 0.8f)),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth().height(44.dp)
                    ) {
                        Text(if (appLang == "hi") "सुरक्षा पिन रीसेट करें" else "Reset Security PIN", color = Color.White, fontWeight = FontWeight.Bold)
                    }

                    // Biometrics toggle
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("Fingerprint Authentication", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            Text("Enable biometrics for lightning unlock", color = Color.Gray, fontSize = 11.sp)
                        }
                        Switch(
                            checked = isBiometricEnabled,
                            onCheckedChange = { vaultViewModel.setBiometricEnabled(it) },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = ElectricBlue,
                                checkedTrackColor = RoyalPurple
                            )
                        )
                    }

                    // Auto-lock timeout config
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Auto-Lock Timeout", color = Color.Gray, fontSize = 12.sp)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            // (seconds: 0=immediate, 15s, 60s, 300s)
                            listOf(0 to "Immediate", 15 to "15s", 60 to "1m", 300 to "5m").forEach { (sec, label) ->
                                val selected = autoLockTimeout == sec
                                Box(
                                    modifier = Modifier
                                        .weight(1f)
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(if (selected) ElectricBlue else Color.White.copy(alpha = 0.05f))
                                        .clickable { vaultViewModel.setAutoLockTimeout(sec) }
                                        .padding(vertical = 10.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = label,
                                        color = if (selected) Color.Black else Color.White,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 11.sp
                                    )
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(24.dp))
                }
            }
        }

        // --- CUSTOM RENAME FOR PRIVACY DIALOG ---
        if (pickedUriForRename != null && pickedTypeForRename != null) {
            AlertDialog(
                onDismissRequest = {
                    pickedUriForRename = null
                    pickedTypeForRename = null
                },
                containerColor = Color(0xFF161622),
                title = {
                    Text(
                        text = if (appLang == "hi") "गोपनीयता के लिए नाम बदलें" else "Rename for Privacy",
                        color = Color.White,
                        fontWeight = FontWeight.Black,
                        fontSize = 20.sp
                    )
                },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text(
                            text = if (appLang == "hi") "गोपनीय फोल्डर में इसकी पहचान छिपाने के लिए इस फ़ाइल का नाम बदलें।" else "Rename this file to obfuscate its identity inside the privacy folder.",
                            color = Color.LightGray,
                            fontSize = 13.sp
                        )
                        OutlinedTextField(
                            value = privateRenameValue,
                            onValueChange = { privateRenameValue = it },
                            label = { Text(if (appLang == "hi") "गोपनीय नाम" else "Private Name") },
                            singleLine = true,
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedTextColor = Color.White,
                                unfocusedTextColor = Color.White,
                                focusedBorderColor = Color(0xFF10B981),
                                unfocusedBorderColor = Color.Gray,
                                focusedLabelColor = Color(0xFF10B981),
                                unfocusedLabelColor = Color.Gray
                            ),
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                },
                confirmButton = {
                    Button(
                        onClick = {
                            val uri = pickedUriForRename!!
                            val type = pickedTypeForRename!!
                            val customName = privateRenameValue.trim().ifEmpty { null }
                            
                            vaultViewModel.importFileFromUri(
                                uri = uri,
                                type = type,
                                customTitle = customName,
                                onKeepOriginalChecked = { tempFile ->
                                    fileToDeleteAfterImport = tempFile
                                    showDeleteOriginalDialog = true
                                },
                                onError = { err -> fileImportError = err }
                            )
                            pickedUriForRename = null
                            pickedTypeForRename = null
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF10B981))
                    ) {
                        Text(if (appLang == "hi") "सुरक्षित रूप से सहेजें" else "Save Privately", color = Color.White, fontWeight = FontWeight.Bold)
                    }
                },
                dismissButton = {
                    TextButton(
                        onClick = {
                            val uri = pickedUriForRename!!
                            val type = pickedTypeForRename!!
                            
                            vaultViewModel.importFileFromUri(
                                uri = uri,
                                type = type,
                                customTitle = null, // keeps original name
                                onKeepOriginalChecked = { tempFile ->
                                    fileToDeleteAfterImport = tempFile
                                    showDeleteOriginalDialog = true
                                },
                                onError = { err -> fileImportError = err }
                            )
                            pickedUriForRename = null
                            pickedTypeForRename = null
                        }
                    ) {
                        Text(if (appLang == "hi") "मूल नाम से सहेजें" else "Keep Original Name", color = Color.Gray)
                    }
                }
            )
        }

        // --- CONFIRMATION FOR DELETING ORIGINAL FILE ---
        if (showDeleteOriginalDialog && fileToDeleteAfterImport != null) {
            AlertDialog(
                onDismissRequest = {
                    fileToDeleteAfterImport?.delete()
                    fileToDeleteAfterImport = null
                    showDeleteOriginalDialog = false
                },
                containerColor = Color(0xFF161622),
                title = {
                    Text("Secure Import Complete", color = Color.White, fontWeight = FontWeight.Black)
                },
                text = {
                    Text(
                        text = "The file has been successfully copied into the encrypted vault storage. To prevent security leaks, would you like to securely delete the original unencrypted file?",
                        color = Color.LightGray,
                        fontSize = 13.sp
                    )
                },
                confirmButton = {
                    Button(
                        onClick = {
                            // Try deleting original.
                            fileToDeleteAfterImport?.let { file ->
                                try {
                                    if (file.exists()) {
                                        file.delete()
                                    }
                                } catch (e: Exception) {
                                    Timber.e(e, "Failed to delete original file")
                                }
                            }
                            fileToDeleteAfterImport = null
                            showDeleteOriginalDialog = false
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color.Red)
                    ) {
                        Text("Delete Original", color = Color.White, fontWeight = FontWeight.Bold)
                    }
                },
                dismissButton = {
                    TextButton(
                        onClick = {
                            // Just delete temp import and keep user's original
                            fileToDeleteAfterImport = null
                            showDeleteOriginalDialog = false
                        }
                    ) {
                        Text("Keep Original", color = Color.Gray)
                    }
                }
            )
        }

        // --- GENERIC MESSAGE TOAST DIALOG (ERRORS / SUCCESS) ---
        fileImportError?.let { msg ->
            AlertDialog(
                onDismissRequest = { fileImportError = null },
                containerColor = Color(0xFF161622),
                title = { Text("Nova Secure Alert", color = Color.White, fontWeight = FontWeight.Black) },
                text = { Text(msg, color = Color.LightGray, fontSize = 13.sp) },
                confirmButton = {
                    Button(
                        onClick = { fileImportError = null },
                        colors = ButtonDefaults.buttonColors(containerColor = ElectricBlue)
                    ) {
                        Text("Dismiss", color = Color.Black, fontWeight = FontWeight.Bold)
                    }
                }
            )
        }
    }
}

// ==========================================
// EQUALIZER DIALOG
// ==========================================
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun EqualizerDialog(
    activePreset: String,
    onPresetChanged: (String) -> Unit,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Column {
                Text("Parametric Equalizer", color = Color.White, fontWeight = FontWeight.Black)
                Text("Pro Audio DSP Customizer", color = ElectricBlue, fontSize = 11.sp)
            }
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
                // Preset chips
                FlowRow(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    listOf("Normal", "Bass Booster", "Vocal Booster", "3D Surround", "Classical").forEach { preset ->
                        val active = activePreset == preset
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (active) ElectricBlue else Color.White.copy(alpha = 0.05f))
                                .clickable { onPresetChanged(preset) }
                                .padding(horizontal = 10.dp, vertical = 6.dp)
                        ) {
                            Text(preset, color = if (active) Color.Black else Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }

                HorizontalDivider(color = Color.White.copy(alpha = 0.1f))

                // Frequency Sliders
                FrequencySlider("60 Hz (Bass Sub)", 0.8f)
                FrequencySlider("230 Hz (Kick)", 0.65f)
                FrequencySlider("910 Hz (Mids)", 0.5f)
                FrequencySlider("4 kHz (Presence)", 0.75f)
                FrequencySlider("14 kHz (Brilliance Air)", 0.9f)
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text("DONE", color = ElectricBlue)
            }
        },
        containerColor = Color(0xFF121212)
    )
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun FrequencySlider(label: String, initialValue: Float) {
    var sliderValue by remember { mutableStateOf(initialValue) }
    Column {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(label, color = Color.White, fontSize = 11.sp)
            Text("${((sliderValue - 0.5f) * 24).toInt()} dB", color = ElectricBlue, fontSize = 11.sp, fontWeight = FontWeight.Bold)
        }
        Slider(
            value = sliderValue,
            onValueChange = { sliderValue = it },
            colors = SliderDefaults.colors(
                thumbColor = ElectricBlue,
                activeTrackColor = ElectricBlue,
                inactiveTrackColor = Color.DarkGray
            ),
            modifier = Modifier.height(18.dp)
        )
    }
}

// Helpers
fun formatMillis(ms: Long): String {
    val totalSecs = ms / 1000
    val hours = totalSecs / 3600
    val minutes = (totalSecs % 3600) / 60
    val seconds = totalSecs % 60
    return if (hours > 0) {
        String.format("%02d:%02d:%02d", hours, minutes, seconds)
    } else {
        String.format("%02d:%02d", minutes, seconds)
    }
}

private fun isRecentlyAdded(video: com.example.data.model.ScannedVideo): Boolean {
    val currentTimeMs = System.currentTimeMillis()
    val dateAddedMs = if (video.dateAdded > 20000000000L) {
        video.dateAdded
    } else {
        video.dateAdded * 1000L
    }
    val diffMs = currentTimeMs - dateAddedMs
    val sevenDaysMs = 7L * 24 * 60 * 60 * 1000
    return diffMs in 0..sevenDaysMs
}

private fun formatWatchedDate(timestamp: Long): String {
    val sdf = java.text.SimpleDateFormat("MMM dd, yyyy - hh:mm a", java.util.Locale.getDefault())
    return sdf.format(java.util.Date(timestamp))
}

// ==========================================
// SMART COLLECTIONS COMPONENT
// ==========================================
@Composable
fun SmartCollectionCard(
    collection: com.example.data.model.SmartCollectionItem,
    onClick: () -> Unit
) {
    val visualGradient = remember(collection.id) {
        Brush.linearGradient(
            colors = listOf(
                ElectricBlue.copy(alpha = 0.4f),
                RoyalPurple.copy(alpha = 0.4f),
                Color.Black
            )
        )
    }

    GlassCard(
        modifier = Modifier
            .width(170.dp)
            .clickable(onClick = onClick)
            .testTag("collection_card_${collection.id}")
    ) {
        Column(modifier = Modifier.padding(2.dp)) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(105.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(visualGradient),
                contentAlignment = Alignment.Center
            ) {
                if (collection.coverThumbnailUrl != null) {
                    AsyncImage(
                        model = collection.coverThumbnailUrl,
                        contentDescription = collection.name,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(
                                Brush.verticalGradient(
                                    colors = listOf(Color.Transparent, Color.Black.copy(alpha = 0.7f))
                                )
                            )
                    )
                } else {
                    Icon(
                        imageVector = collection.icon,
                        contentDescription = collection.name,
                        tint = ElectricBlue,
                        modifier = Modifier.size(36.dp)
                    )
                }
                
                // Small Category Icon overlay
                Box(
                    modifier = Modifier
                        .align(Alignment.TopStart)
                        .padding(6.dp)
                        .size(28.dp)
                        .background(Color.Black.copy(alpha = 0.6f), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = collection.icon,
                        contentDescription = null,
                        tint = Color.White,
                        modifier = Modifier.size(14.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            Text(
                text = collection.name,
                color = Color.White,
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.padding(horizontal = 4.dp)
            )

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 4.dp, vertical = 2.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "${collection.videos.size} items",
                    color = Color.Gray,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Medium
                )
                Text(
                    text = formatBytes(collection.totalSize),
                    color = ElectricBlue,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

@Composable
fun DynamicHomeDashboard(
    smartCollectionsViewModel: com.example.ui.viewmodel.SmartCollectionsViewModel,
    mediaViewModel: MediaViewModel,
    onNavigateToCollection: (String) -> Unit,
    onPlayVideo: (MediaEntity) -> Unit
) {
    val recentlyOpenedFolder by smartCollectionsViewModel.recentlyOpenedFolder.collectAsState()
    val lastPlayedVideo by smartCollectionsViewModel.lastPlayedVideo.collectAsState()
    val favoriteCollection by smartCollectionsViewModel.favoriteCollection.collectAsState()
    val largestCollection by smartCollectionsViewModel.largestCollection.collectAsState()

    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = "Dynamic Intelligence",
            color = Color.White,
            fontSize = 18.sp,
            fontWeight = FontWeight.Bold
        )
        GlowText(text = "Real-time Metrics", fontSize = 12.sp, color = RoyalPurple)
    }
    Spacer(modifier = Modifier.height(12.dp))

    Column(
        verticalArrangement = Arrangement.spacedBy(12.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            // Card 1: Recently Opened Folder
            GlassCard(
                modifier = Modifier
                    .weight(1f)
                    .height(100.dp)
                    .testTag("dynamic_opened_folder")
            ) {
                Column(modifier = Modifier.padding(8.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Rounded.FolderOpen, contentDescription = null, tint = ElectricBlue, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Recent Folder", color = Color.Gray, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    val folderValue = recentlyOpenedFolder ?: lastPlayedVideo?.path?.let { File(it).parentFile?.name } ?: "None yet"
                    Text(
                        text = folderValue,
                        color = Color.White,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }

            // Card 2: Last Played Video
            val playAction = lastPlayedVideo?.let { video -> { onPlayVideo(video.toMediaEntity()) } } ?: {}
            GlassCard(
                modifier = Modifier
                    .weight(1f)
                    .height(100.dp)
                    .clickable(enabled = lastPlayedVideo != null, onClick = playAction)
                    .testTag("dynamic_last_played")
            ) {
                Column(modifier = Modifier.padding(8.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Rounded.PlayArrow, contentDescription = null, tint = RoyalPurple, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Last Played", color = Color.Gray, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = lastPlayedVideo?.title ?: "No history yet",
                        color = Color.White,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
        }

        Row(
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            // Card 3: Favorite Collection
            val favAction = favoriteCollection?.let { col -> { onNavigateToCollection("collection/${col.id}") } } ?: {}
            GlassCard(
                modifier = Modifier
                    .weight(1f)
                    .height(100.dp)
                    .clickable(enabled = favoriteCollection != null, onClick = favAction)
                    .testTag("dynamic_favorite_collection")
            ) {
                Column(modifier = Modifier.padding(8.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Rounded.Favorite, contentDescription = null, tint = Color.Red, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Fav Collection", color = Color.Gray, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = favoriteCollection?.name ?: "No favorites yet",
                        color = Color.White,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }

            // Card 4: Largest Collection
            val largestAction = largestCollection?.let { col -> { onNavigateToCollection("collection/${col.id}") } } ?: {}
            GlassCard(
                modifier = Modifier
                    .weight(1f)
                    .height(100.dp)
                    .clickable(enabled = largestCollection != null, onClick = largestAction)
                    .testTag("dynamic_largest_collection")
            ) {
                Column(modifier = Modifier.padding(8.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Rounded.DataUsage, contentDescription = null, tint = Color(0xFFFF9800), modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Largest Collection", color = Color.Gray, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = largestCollection?.let { "${it.name} (${formatBytes(it.totalSize)})" } ?: "Empty",
                        color = Color.White,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
        }
    }
}

private fun formatBytes(bytes: Long): String {
    if (bytes <= 0) return "0 B"
    val units = arrayOf("B", "KB", "MB", "GB", "TB")
    val digitGroups = (Math.log10(bytes.toDouble()) / Math.log10(1024.0)).toInt()
    return String.format("%.2f %s", bytes / Math.pow(1024.0, digitGroups.toDouble()), units[digitGroups])
}

@Composable
fun CapturedFramesView(
    capturedFrames: List<com.example.data.model.CapturedFrameEntity>,
    onOpenFrame: (com.example.data.model.CapturedFrameEntity) -> Unit,
    onShareFrame: (com.example.data.model.CapturedFrameEntity) -> Unit,
    onDeleteFrame: (com.example.data.model.CapturedFrameEntity) -> Unit
) {
    if (capturedFrames.isEmpty()) {
        Box(
            modifier = Modifier.fillMaxSize(),
            contentAlignment = Alignment.Center
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.padding(24.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(80.dp)
                        .background(Color.White.copy(alpha = 0.05f), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Rounded.PhotoCamera,
                        contentDescription = null,
                        tint = ElectricBlue,
                        modifier = Modifier.size(36.dp)
                    )
                }
                Spacer(modifier = Modifier.height(20.dp))
                Text(
                    text = "No Captured Frames Yet",
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp,
                    textAlign = TextAlign.Center
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "Capture ultra HD frames of your locally stored videos from the player's controls.",
                    color = Color.Gray,
                    fontSize = 13.sp,
                    textAlign = TextAlign.Center,
                    lineHeight = 18.sp
                )
            }
        }
    } else {
        LazyVerticalGrid(
            columns = GridCells.Adaptive(160.dp),
            contentPadding = PaddingValues(bottom = 120.dp, top = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            modifier = Modifier.fillMaxSize()
        ) {
            items(capturedFrames) { frame ->
                var showOptionsDialog by remember { mutableStateOf(false) }
                
                GlassCard(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { showOptionsDialog = true }
                ) {
                    Column {
                        // Image Thumbnail with Format Overlay
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(100.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(Color.Black)
                        ) {
                            AsyncImage(
                                model = java.io.File(frame.filePath),
                                contentDescription = frame.fileName,
                                contentScale = ContentScale.Crop,
                                modifier = Modifier.fillMaxSize()
                            )
                            
                            // Format/Quality Chip
                            Box(
                                modifier = Modifier
                                    .align(Alignment.TopEnd)
                                    .padding(4.dp)
                                    .background(Color.Black.copy(alpha = 0.65f), RoundedCornerShape(4.dp))
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                            ) {
                                Text(
                                    text = if (frame.format == "PNG") "PNG" else "JPG ${frame.quality}%",
                                    color = ElectricBlue,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }

                            // Timestamp Tag Overlay
                            Box(
                                modifier = Modifier
                                    .align(Alignment.BottomStart)
                                    .padding(4.dp)
                                    .background(Color.Black.copy(alpha = 0.65f), RoundedCornerShape(4.dp))
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                            ) {
                                val currentPos = frame.timestampMs
                                val timeText = if (currentPos > 3600000) {
                                    String.format("%02d:%02d:%02d", currentPos / 3600000, (currentPos % 3600000) / 60000, (currentPos % 60000) / 1000)
                                } else {
                                    String.format("%02d:%02d", (currentPos % 3600000) / 60000, (currentPos % 60000) / 1000)
                                }
                                Text(
                                    text = timeText,
                                    color = Color.White,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        // Text Info
                        Column(modifier = Modifier.padding(horizontal = 4.dp, vertical = 4.dp)) {
                            Text(
                                text = frame.fileName,
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                text = frame.videoTitle,
                                color = Color.Gray,
                                fontSize = 11.sp,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                }

                if (showOptionsDialog) {
                    AlertDialog(
                        onDismissRequest = { showOptionsDialog = false },
                        title = {
                            Text(
                                text = "Frame Actions",
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                fontSize = 18.sp
                            )
                        },
                        text = {
                            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                                Text(
                                    text = "Choose an action for ${frame.fileName}",
                                    color = Color.LightGray,
                                    fontSize = 14.sp
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                
                                // Open Option
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable {
                                            showOptionsDialog = false
                                            onOpenFrame(frame)
                                        }
                                        .padding(vertical = 12.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(Icons.Rounded.OpenInNew, contentDescription = null, tint = ElectricBlue, modifier = Modifier.size(20.dp))
                                    Spacer(modifier = Modifier.width(16.dp))
                                    Text("Open in Gallery", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                                }

                                // Share Option
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable {
                                            showOptionsDialog = false
                                            onShareFrame(frame)
                                        }
                                        .padding(vertical = 12.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(Icons.Rounded.Share, contentDescription = null, tint = ElectricBlue, modifier = Modifier.size(20.dp))
                                    Spacer(modifier = Modifier.width(16.dp))
                                    Text("Share Frame", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                                }

                                // Delete Option
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable {
                                            showOptionsDialog = false
                                            onDeleteFrame(frame)
                                        }
                                        .padding(vertical = 12.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(Icons.Rounded.Delete, contentDescription = null, tint = Color.Red, modifier = Modifier.size(20.dp))
                                    Spacer(modifier = Modifier.width(16.dp))
                                    Text("Delete Frame", color = Color.Red, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        },
                        confirmButton = {
                            TextButton(onClick = { showOptionsDialog = false }) {
                                Text("Cancel", color = Color.LightGray)
                            }
                        },
                        containerColor = Color(0xFF161622),
                        shape = RoundedCornerShape(20.dp)
                    )
                }
            }
        }
    }
}
