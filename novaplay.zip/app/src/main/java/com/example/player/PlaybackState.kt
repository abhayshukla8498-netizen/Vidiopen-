package com.example.player

sealed interface PlayerState {
    object Idle : PlayerState
    object Loading : PlayerState
    data class Ready(val duration: Long, val isPlaying: Boolean) : PlayerState
    data class Error(val message: String) : PlayerState
}

data class PlaybackConfig(
    val selectedAudioTrack: String = "English [Stereo]",
    val selectedSubtitleTrack: String = "None",
    val equalizerPreset: String = "Normal",
    val playbackSpeed: Float = 1.0f,
    val isScreenLocked: Boolean = false
)
