package com.example.player

import android.content.ComponentName
import android.content.Context
import android.os.Handler
import android.os.Looper
import androidx.annotation.OptIn
import androidx.core.content.ContextCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Player
import androidx.media3.common.PlaybackParameters
import androidx.media3.common.util.UnstableApi
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.example.data.model.ScannedSong
import com.example.data.repository.MusicRepository
import com.example.service.NovaPlaybackService
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import timber.log.Timber

@OptIn(UnstableApi::class)
class MusicPlayerManager(
    private val context: Context,
    private val musicRepository: MusicRepository,
    val balanceAudioProcessor: BalanceAudioProcessor,
    val audioEffectsManager: AudioEffectsManager
) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var mediaController: MediaController? = null

    private val _currentPlayingSong = MutableStateFlow<ScannedSong?>(null)
    val currentPlayingSong: StateFlow<ScannedSong?> = _currentPlayingSong.asStateFlow()

    private val _isPlaying = MutableStateFlow(false)
    val isPlaying: StateFlow<Boolean> = _isPlaying.asStateFlow()

    private val _playerState = MutableStateFlow<PlayerState>(PlayerState.Idle)
    val playerState: StateFlow<PlayerState> = _playerState.asStateFlow()

    private val _currentPosition = MutableStateFlow(0L)
    val currentPosition: StateFlow<Long> = _currentPosition.asStateFlow()

    private val _duration = MutableStateFlow(0L)
    val duration: StateFlow<Long> = _duration.asStateFlow()

    private val _queue = MutableStateFlow<List<ScannedSong>>(emptyList())
    val queue: StateFlow<List<ScannedSong>> = _queue.asStateFlow()

    private val _repeatMode = MutableStateFlow(Player.REPEAT_MODE_OFF)
    val repeatMode: StateFlow<Int> = _repeatMode.asStateFlow()

    private val _shuffleModeEnabled = MutableStateFlow(false)
    val shuffleModeEnabled: StateFlow<Boolean> = _shuffleModeEnabled.asStateFlow()

    private val _playbackSpeed = MutableStateFlow(1.0f)
    val playbackSpeed: StateFlow<Float> = _playbackSpeed.asStateFlow()

    // Premium Sleep Timer flows
    private val _sleepTimerRemaining = MutableStateFlow<Long?>(null)
    val sleepTimerRemaining: StateFlow<Long?> = _sleepTimerRemaining.asStateFlow()

    private val _sleepTimerMode = MutableStateFlow<String?>(null)
    val sleepTimerMode: StateFlow<String?> = _sleepTimerMode.asStateFlow()

    private var sleepTimerJob: kotlinx.coroutines.Job? = null
    private var pauseAtEndOfSong = false

    // Premium Fade options flows
    private val _fadeInEnabled = MutableStateFlow(true)
    val fadeInEnabled: StateFlow<Boolean> = _fadeInEnabled.asStateFlow()

    private val _fadeInDurationMs = MutableStateFlow(1000L)
    val fadeInDurationMs: StateFlow<Long> = _fadeInDurationMs.asStateFlow()

    private val _fadeOutEnabled = MutableStateFlow(true)
    val fadeOutEnabled: StateFlow<Boolean> = _fadeOutEnabled.asStateFlow()

    private val _fadeOutDurationMs = MutableStateFlow(1000L)
    val fadeOutDurationMs: StateFlow<Long> = _fadeOutDurationMs.asStateFlow()

    private var fadeJob: kotlinx.coroutines.Job? = null

    private val prefs = context.getSharedPreferences("music_player_prefs", Context.MODE_PRIVATE)
    private var allScannedSongs = listOf<ScannedSong>()

    init {
        initializeController()
        startPositionTracker()
    }

    private fun initializeController() {
        val sessionToken = SessionToken(context, ComponentName(context, NovaPlaybackService::class.java))
        val controllerFuture = MediaController.Builder(context, sessionToken).buildAsync()
        controllerFuture.addListener({
            try {
                val controller = controllerFuture.get()
                mediaController = controller
                setupControllerListener(controller)
                loadSavedState(controller)
                Timber.d("MusicPlayerManager: MediaController initialized successfully")
            } catch (e: Exception) {
                Timber.e(e, "MusicPlayerManager: Failed to initialize MediaController")
            }
        }, ContextCompat.getMainExecutor(context))
    }

    private fun setupControllerListener(controller: MediaController) {
        controller.addListener(object : Player.Listener {
            override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
                updateCurrentSong(controller)
                savePlaybackState()
                
                // End of song sleep timer check
                if (pauseAtEndOfSong) {
                    pause()
                    pauseAtEndOfSong = false
                    _sleepTimerMode.value = null
                }
            }

            override fun onIsPlayingChanged(isPlaying: Boolean) {
                _isPlaying.value = isPlaying
                savePlaybackState()
            }

            override fun onPlaybackStateChanged(state: Int) {
                when (state) {
                    Player.STATE_IDLE -> _playerState.value = PlayerState.Idle
                    Player.STATE_BUFFERING -> _playerState.value = PlayerState.Loading
                    Player.STATE_READY -> {
                        _playerState.value = PlayerState.Ready(controller.duration, controller.isPlaying)
                        _duration.value = controller.duration
                    }
                    Player.STATE_ENDED -> {
                        _playerState.value = PlayerState.Ready(controller.duration, false)
                        if (pauseAtEndOfSong) {
                            pauseAtEndOfSong = false
                            _sleepTimerMode.value = null
                        }
                    }
                }
                savePlaybackState()
            }

            override fun onTimelineChanged(timeline: androidx.media3.common.Timeline, reason: Int) {
                updateQueue(controller)
                savePlaybackState()
            }

            override fun onPlaybackParametersChanged(playbackParameters: PlaybackParameters) {
                _playbackSpeed.value = playbackParameters.speed
                savePlaybackState()
            }

            override fun onRepeatModeChanged(repeatMode: Int) {
                _repeatMode.value = repeatMode
                savePlaybackState()
            }

            override fun onShuffleModeEnabledChanged(shuffleModeEnabled: Boolean) {
                _shuffleModeEnabled.value = shuffleModeEnabled
                savePlaybackState()
            }
        })

        // Initial update
        updateCurrentSong(controller)
        _isPlaying.value = controller.isPlaying
        _duration.value = controller.duration
        updateQueue(controller)
        _repeatMode.value = controller.repeatMode
        _shuffleModeEnabled.value = controller.shuffleModeEnabled
        _playbackSpeed.value = controller.playbackParameters.speed
    }

    fun syncScannedSongs(songs: List<ScannedSong>) {
        allScannedSongs = songs
        mediaController?.let { controller ->
            updateCurrentSong(controller)
            updateQueue(controller)
        }
    }

    fun onAudioSessionIdChanged(sessionId: Int) {
        audioEffectsManager.onAudioSessionIdChanged(sessionId)
    }

    private fun updateCurrentSong(controller: MediaController) {
        val mediaId = controller.currentMediaItem?.mediaId ?: return
        val songId = mediaId.toLongOrNull() ?: return
        val song = allScannedSongs.find { it.id == songId }
        _currentPlayingSong.value = song
    }

    private fun updateQueue(controller: MediaController) {
        val list = mutableListOf<ScannedSong>()
        for (i in 0 until controller.mediaItemCount) {
            val item = controller.getMediaItemAt(i)
            val songId = item.mediaId.toLongOrNull()
            if (songId != null) {
                allScannedSongs.find { it.id == songId }?.let {
                    list.add(it)
                }
            }
        }
        _queue.value = list
    }

    fun play() {
        val controller = mediaController ?: return
        fadeJob?.cancel()
        
        if (_fadeInEnabled.value && _fadeInDurationMs.value > 0) {
            controller.volume = 0f
            controller.play()
            fadeJob = scope.launch {
                val duration = _fadeInDurationMs.value
                val steps = 20
                val delayTime = duration / steps
                for (i in 1..steps) {
                    kotlinx.coroutines.delay(delayTime)
                    controller.volume = i.toFloat() / steps
                }
                controller.volume = 1f
            }
        } else {
            controller.volume = 1f
            controller.play()
        }
    }

    fun pause() {
        val controller = mediaController ?: return
        fadeJob?.cancel()
        
        if (_fadeOutEnabled.value && _fadeOutDurationMs.value > 0 && controller.isPlaying) {
            fadeJob = scope.launch {
                val duration = _fadeOutDurationMs.value
                val steps = 20
                val delayTime = duration / steps
                val startVolume = controller.volume
                for (i in steps downTo 1) {
                    kotlinx.coroutines.delay(delayTime)
                    controller.volume = startVolume * (i.toFloat() / steps)
                }
                controller.volume = 0f
                controller.pause()
                controller.volume = 1f
            }
        } else {
            controller.pause()
        }
    }

    fun next() {
        mediaController?.seekToNext()
    }

    fun previous() {
        mediaController?.seekToPrevious()
    }

    fun stop() {
        mediaController?.stop()
    }

    fun seekTo(positionMs: Long) {
        mediaController?.seekTo(positionMs)
        _currentPosition.value = positionMs
    }

    fun fastSeekForward() {
        val controller = mediaController ?: return
        val newPos = minOf(controller.duration, controller.currentPosition + 10000L)
        seekTo(newPos)
    }

    fun fastSeekBackward() {
        val controller = mediaController ?: return
        val newPos = maxOf(0L, controller.currentPosition - 10000L)
        seekTo(newPos)
    }

    fun replay() {
        mediaController?.seekTo(0L)
        play()
    }

    fun playSong(song: ScannedSong, songContextList: List<ScannedSong>) {
        val controller = mediaController ?: return
        controller.stop()
        controller.clearMediaItems()

        val mediaItems = songContextList.map { createMediaItem(it) }
        controller.addMediaItems(mediaItems)

        val targetIndex = songContextList.indexOfFirst { it.id == song.id }
        if (targetIndex != -1) {
            controller.seekTo(targetIndex, 0L)
        }
        play()
    }

    fun playNext(song: ScannedSong) {
        val controller = mediaController ?: return
        val mediaItem = createMediaItem(song)
        val currentIndex = controller.currentMediaItemIndex
        if (currentIndex == -1) {
            controller.addMediaItem(mediaItem)
        } else {
            // Remove first if already present in queue, to avoid double play
            val existingIndex = _queue.value.indexOfFirst { it.id == song.id }
            if (existingIndex != -1) {
                controller.removeMediaItem(existingIndex)
            }
            val insertIndex = if (existingIndex != -1 && existingIndex < currentIndex) currentIndex else currentIndex + 1
            controller.addMediaItem(insertIndex, mediaItem)
        }
    }

    fun addToQueue(song: ScannedSong) {
        val controller = mediaController ?: return
        val existingIndex = _queue.value.indexOfFirst { it.id == song.id }
        if (existingIndex == -1) {
            controller.addMediaItem(createMediaItem(song))
        }
    }

    fun removeFromQueue(songId: Long) {
        val controller = mediaController ?: return
        val index = _queue.value.indexOfFirst { it.id == songId }
        if (index != -1) {
            controller.removeMediaItem(index)
        }
    }

    fun reorderQueue(fromIndex: Int, toIndex: Int) {
        val controller = mediaController ?: return
        if (fromIndex in 0 until controller.mediaItemCount && toIndex in 0 until controller.mediaItemCount) {
            controller.moveMediaItem(fromIndex, toIndex)
        }
    }

    fun clearQueue() {
        val controller = mediaController ?: return
        val currentIndex = controller.currentMediaItemIndex
        if (currentIndex != -1) {
            for (i in 0 until currentIndex) {
                controller.removeMediaItem(0)
            }
            while (controller.mediaItemCount > 1) {
                controller.removeMediaItem(1)
            }
        } else {
            controller.clearMediaItems()
        }
    }

    fun setRepeatMode(mode: Int) {
        mediaController?.repeatMode = mode
    }

    fun setShuffleMode(enabled: Boolean) {
        mediaController?.shuffleModeEnabled = enabled
    }

    fun setPlaybackSpeed(speed: Float) {
        mediaController?.setPlaybackSpeed(speed)
    }

    // Sleep Timer Setters
    fun setSleepTimer(minutes: Int?) {
        sleepTimerJob?.cancel()
        pauseAtEndOfSong = false
        
        if (minutes == null) {
            _sleepTimerRemaining.value = null
            _sleepTimerMode.value = null
            return
        }

        _sleepTimerMode.value = "$minutes min"
        val durationMs = minutes * 60 * 1000L
        _sleepTimerRemaining.value = durationMs

        sleepTimerJob = scope.launch {
            var remaining = durationMs
            while (remaining > 0) {
                kotlinx.coroutines.delay(1000L)
                remaining -= 1000L
                _sleepTimerRemaining.value = remaining
            }
            pause()
            setSleepTimer(null)
        }
    }

    fun setSleepTimerEndOfSong() {
        sleepTimerJob?.cancel()
        _sleepTimerRemaining.value = null
        _sleepTimerMode.value = "End of Song"
        pauseAtEndOfSong = true
    }

    // Fade Options Setters
    fun setFadeInEnabled(enabled: Boolean) {
        _fadeInEnabled.value = enabled
        prefs.edit().putBoolean("fade_in_enabled", enabled).apply()
    }

    fun setFadeInDuration(ms: Long) {
        _fadeInDurationMs.value = ms
        prefs.edit().putLong("fade_in_duration", ms).apply()
    }

    fun setFadeOutEnabled(enabled: Boolean) {
        _fadeOutEnabled.value = enabled
        prefs.edit().putBoolean("fade_out_enabled", enabled).apply()
    }

    fun setFadeOutDuration(ms: Long) {
        _fadeOutDurationMs.value = ms
        prefs.edit().putLong("fade_out_duration", ms).apply()
    }

    fun setBalance(balance: Float) {
        balanceAudioProcessor.setBalance(balance)
        prefs.edit().putFloat("balance", balance).apply()
    }

    fun getBalance(): Float {
        return balanceAudioProcessor.getBalance()
    }

    private fun createMediaItem(song: ScannedSong): MediaItem {
        val metadata = MediaMetadata.Builder()
            .setTitle(song.title)
            .setArtist(song.artist)
            .setAlbumTitle(song.album)
            .setArtworkUri(if (song.artworkUri != null) android.net.Uri.parse(song.artworkUri) else null)
            .build()

        return MediaItem.Builder()
            .setMediaId(song.id.toString())
            .setUri(android.net.Uri.parse(song.path))
            .setMediaMetadata(metadata)
            .build()
    }

    private fun startPositionTracker() {
        val handler = Handler(Looper.getMainLooper())
        handler.post(object : Runnable {
            override fun run() {
                val controller = mediaController
                if (controller != null && controller.isPlaying) {
                    _currentPosition.value = controller.currentPosition
                    savePlaybackPositionOnly(controller.currentPosition)
                }
                handler.postDelayed(this, 1000L)
            }
        })
    }

    private fun savePlaybackPositionOnly(position: Long) {
        prefs.edit().putLong("playback_position", position).apply()
    }

    private fun savePlaybackState() {
        val controller = mediaController ?: return
        val currentSong = _currentPlayingSong.value ?: return
        val currentPos = controller.currentPosition
        val queueIds = _queue.value.map { it.id }.joinToString(",")
        val speed = controller.playbackParameters.speed
        val repeat = controller.repeatMode
        val shuffle = controller.shuffleModeEnabled

        prefs.edit().apply {
            putLong("last_song_id", currentSong.id)
            putLong("playback_position", currentPos)
            putString("queue_ids", queueIds)
            putFloat("playback_speed", speed)
            putInt("repeat_mode", repeat)
            putBoolean("shuffle_mode", shuffle)
            apply()
        }
    }

    private fun loadSavedState(controller: MediaController) {
        scope.launch {
            allScannedSongs = musicRepository.scanAudio()

            val lastSongId = prefs.getLong("last_song_id", -1L)
            val position = prefs.getLong("playback_position", 0L)
            val queueIdsStr = prefs.getString("queue_ids", "") ?: ""
            val speed = prefs.getFloat("playback_speed", 1.0f)
            val repeat = prefs.getInt("repeat_mode", Player.REPEAT_MODE_OFF)
            val shuffle = prefs.getBoolean("shuffle_mode", false)

            _fadeInEnabled.value = prefs.getBoolean("fade_in_enabled", true)
            _fadeInDurationMs.value = prefs.getLong("fade_in_duration", 1000L)
            _fadeOutEnabled.value = prefs.getBoolean("fade_out_enabled", true)
            _fadeOutDurationMs.value = prefs.getLong("fade_out_duration", 1000L)

            val bal = prefs.getFloat("balance", 0.0f)
            balanceAudioProcessor.setBalance(bal)

            if (queueIdsStr.isNotEmpty()) {
                val ids = queueIdsStr.split(",").mapNotNull { it.toLongOrNull() }
                val restoredSongs = ids.mapNotNull { id -> allScannedSongs.find { it.id == id } }
                if (restoredSongs.isNotEmpty()) {
                    controller.clearMediaItems()
                    controller.addMediaItems(restoredSongs.map { createMediaItem(it) })

                    val targetIndex = restoredSongs.indexOfFirst { it.id == lastSongId }
                    if (targetIndex != -1) {
                        controller.seekTo(targetIndex, position)
                    } else {
                        controller.seekTo(0, position)
                    }
                }
            }

            controller.repeatMode = repeat
            controller.shuffleModeEnabled = shuffle
            controller.setPlaybackSpeed(speed)

            updateCurrentSong(controller)
            updateQueue(controller)
            _isPlaying.value = controller.isPlaying
            _duration.value = controller.duration
            _currentPosition.value = position
            _repeatMode.value = repeat
            _shuffleModeEnabled.value = shuffle
            _playbackSpeed.value = speed
        }
    }
}
