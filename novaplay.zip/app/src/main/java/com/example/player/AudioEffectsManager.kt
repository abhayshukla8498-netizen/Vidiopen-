package com.example.player

import android.content.Context
import android.media.audiofx.BassBoost
import android.media.audiofx.Equalizer
import android.media.audiofx.LoudnessEnhancer
import android.media.audiofx.Virtualizer
import timber.log.Timber

class AudioEffectsManager(private val context: Context) {
    private val prefs = context.getSharedPreferences("audio_effects_prefs", Context.MODE_PRIVATE)

    private var equalizer: Equalizer? = null
    private var bassBoost: BassBoost? = null
    private var virtualizer: Virtualizer? = null
    private var loudnessEnhancer: LoudnessEnhancer? = null
    private var currentSessionId: Int = 0

    // Properties initialized from SharedPreferences
    var eqEnabled: Boolean
        get() = prefs.getBoolean("eq_enabled", false)
        set(value) {
            prefs.edit().putBoolean("eq_enabled", value).apply()
            try {
                equalizer?.enabled = value
            } catch (e: Exception) {
                Timber.e(e, "Failed to enable/disable equalizer")
            }
        }

    var selectedPreset: String
        get() = prefs.getString("selected_preset", "Normal") ?: "Normal"
        set(value) {
            prefs.edit().putString("selected_preset", value).apply()
            applyPreset(value)
        }

    var bassBoostEnabled: Boolean
        get() = prefs.getBoolean("bass_boost_enabled", false)
        set(value) {
            prefs.edit().putBoolean("bass_boost_enabled", value).apply()
            try {
                bassBoost?.enabled = value
            } catch (e: Exception) {
                Timber.e(e, "Failed to enable/disable bass boost")
            }
        }

    var bassBoostStrength: Int
        get() = prefs.getInt("bass_boost_strength", 0)
        set(value) {
            prefs.edit().putInt("bass_boost_strength", value).apply()
            applyBassBoostStrength(value)
        }

    var virtualizerEnabled: Boolean
        get() = prefs.getBoolean("virtualizer_enabled", false)
        set(value) {
            prefs.edit().putBoolean("virtualizer_enabled", value).apply()
            try {
                virtualizer?.enabled = value
            } catch (e: Exception) {
                Timber.e(e, "Failed to enable/disable virtualizer")
            }
        }

    var virtualizerStrength: Int
        get() = prefs.getInt("virtualizer_strength", 0)
        set(value) {
            prefs.edit().putInt("virtualizer_strength", value).apply()
            applyVirtualizerStrength(value)
        }

    var loudnessEnabled: Boolean
        get() = prefs.getBoolean("loudness_enabled", false)
        set(value) {
            prefs.edit().putBoolean("loudness_enabled", value).apply()
            try {
                loudnessEnhancer?.enabled = value
            } catch (e: Exception) {
                Timber.e(e, "Failed to enable/disable loudness enhancer")
            }
        }

    var loudnessGain: Float
        get() = prefs.getFloat("loudness_gain", 0f)
        set(value) {
            prefs.edit().putFloat("loudness_gain", value).apply()
            applyLoudnessGain(value)
        }

    // Stores 10 virtual band gains in dB (-15 to +15)
    private val _eqBands = IntArray(10) { 0 }
    val eqBands: IntArray get() = _eqBands

    companion object {
        val PRESETS = mapOf(
            "Normal" to intArrayOf(0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
            "Pop" to intArrayOf(-1, 2, 4, 5, 3, -1, -2, -2, -1, 1),
            "Rock" to intArrayOf(4, 3, -1, -2, -1, 1, 3, 4, 4, 3),
            "Jazz" to intArrayOf(3, 2, 1, 2, -1, -1, 0, 1, 3, 3),
            "Classical" to intArrayOf(3, 2, 2, 1, -1, -1, 0, 2, 3, 3),
            "Dance" to intArrayOf(5, 4, 2, 0, -1, 2, 4, 4, 3, 1),
            "Bass Boost" to intArrayOf(6, 5, 4, 2, 1, 0, 0, 0, 0, 0),
            "Vocal" to intArrayOf(-3, -2, 0, 3, 5, 4, 3, 1, -1, -2)
        )
    }

    init {
        // Load eq bands
        for (i in 0..9) {
            _eqBands[i] = prefs.getInt("eq_band_$i", 0)
        }
    }

    fun onAudioSessionIdChanged(sessionId: Int) {
        if (sessionId == 0 || sessionId == currentSessionId) return
        currentSessionId = sessionId
        Timber.d("AudioEffectsManager: Initializing effects for sessionId: $sessionId")
        release()

        try {
            equalizer = Equalizer(0, sessionId).apply {
                enabled = eqEnabled
                applyAllBands()
            }
        } catch (e: Exception) {
            Timber.e(e, "Failed to initialize hardware Equalizer")
        }

        try {
            bassBoost = BassBoost(0, sessionId).apply {
                enabled = bassBoostEnabled
                if (strengthSupported) {
                    setStrength(bassBoostStrength.toShort())
                }
            }
        } catch (e: Exception) {
            Timber.e(e, "Failed to initialize hardware BassBoost")
        }

        try {
            virtualizer = Virtualizer(0, sessionId).apply {
                enabled = virtualizerEnabled
                if (strengthSupported) {
                    setStrength(virtualizerStrength.toShort())
                }
            }
        } catch (e: Exception) {
            Timber.e(e, "Failed to initialize hardware Virtualizer")
        }

        try {
            loudnessEnhancer = LoudnessEnhancer(sessionId).apply {
                enabled = loudnessEnabled
                setTargetGain(loudnessGain.toInt())
            }
        } catch (e: Exception) {
            Timber.e(e, "Failed to initialize hardware LoudnessEnhancer")
        }
    }

    fun setEqBand(bandIndex: Int, gainDb: Int) {
        if (bandIndex in 0..9) {
            _eqBands[bandIndex] = gainDb
            prefs.edit().putInt("eq_band_$bandIndex", gainDb).apply()
            applyBandToHardware(bandIndex, gainDb)
        }
    }

    private fun applyPreset(presetName: String) {
        val presetBands = PRESETS[presetName] ?: getCustomPreset(presetName) ?: PRESETS["Normal"]!!
        for (i in 0..9) {
            _eqBands[i] = presetBands[i]
            prefs.edit().putInt("eq_band_$i", presetBands[i]).apply()
            applyBandToHardware(i, presetBands[i])
        }
    }

    private fun applyBandToHardware(bandIndex: Int, gainDb: Int) {
        val eq = equalizer ?: return
        try {
            val numHardwareBands = eq.numberOfBands.toInt()
            if (numHardwareBands <= 0) return

            // Map virtual band to hardware bands
            val hardwareBandIndex = (bandIndex * numHardwareBands / 10).coerceIn(0, numHardwareBands - 1)
            
            val range = eq.bandLevelRange
            val minRange = range[0].toInt()
            val maxRange = range[1].toInt()
            
            // Level in millibels
            val levelmB = (gainDb * 100).coerceIn(minRange, maxRange).toShort()
            eq.setBandLevel(hardwareBandIndex.toShort(), levelmB)
        } catch (e: Exception) {
            Timber.e(e, "Failed to apply band level to hardware Equalizer")
        }
    }

    private fun applyAllBands() {
        for (i in 0..9) {
            applyBandToHardware(i, _eqBands[i])
        }
    }

    private fun applyBassBoostStrength(strength: Int) {
        try {
            if (bassBoost?.strengthSupported == true) {
                bassBoost?.setStrength(strength.toShort())
            }
        } catch (e: Exception) {
            Timber.e(e, "Failed to apply BassBoost strength")
        }
    }

    private fun applyVirtualizerStrength(strength: Int) {
        try {
            if (virtualizer?.strengthSupported == true) {
                virtualizer?.setStrength(strength.toShort())
            }
        } catch (e: Exception) {
            Timber.e(e, "Failed to apply Virtualizer strength")
        }
    }

    private fun applyLoudnessGain(gainDb: Float) {
        try {
            loudnessEnhancer?.setTargetGain(gainDb.toInt())
        } catch (e: Exception) {
            Timber.e(e, "Failed to apply LoudnessEnhancer target gain")
        }
    }

    // Custom Presets management
    fun saveCustomPreset(name: String, bands: IntArray) {
        val presetStr = bands.joinToString(",")
        prefs.edit().putString("custom_preset_$name", presetStr).apply()
        
        val existing = getCustomPresetNames().toMutableSet()
        existing.add(name)
        prefs.edit().putStringSet("custom_preset_names", existing).apply()
    }

    fun getCustomPresetNames(): Set<String> {
        return prefs.getStringSet("custom_preset_names", emptySet()) ?: emptySet()
    }

    fun deleteCustomPreset(name: String) {
        prefs.edit().remove("custom_preset_$name").apply()
        val existing = getCustomPresetNames().toMutableSet()
        existing.remove(name)
        prefs.edit().putStringSet("custom_preset_names", existing).apply()
    }

    fun getCustomPreset(name: String): IntArray? {
        val str = prefs.getString("custom_preset_$name", null) ?: return null
        return try {
            str.split(",").map { it.toInt() }.toIntArray()
        } catch (e: Exception) {
            null
        }
    }

    fun release() {
        try {
            equalizer?.release()
        } catch (e: Exception) {
            Timber.e(e, "Error releasing Equalizer")
        }
        equalizer = null

        try {
            bassBoost?.release()
        } catch (e: Exception) {
            Timber.e(e, "Error releasing BassBoost")
        }
        bassBoost = null

        try {
            virtualizer?.release()
        } catch (e: Exception) {
            Timber.e(e, "Error releasing Virtualizer")
        }
        virtualizer = null

        try {
            loudnessEnhancer?.release()
        } catch (e: Exception) {
            Timber.e(e, "Error releasing LoudnessEnhancer")
        }
        loudnessEnhancer = null
    }
}
