package com.example.service

import android.content.Context
import android.content.Intent
import androidx.annotation.OptIn
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.audio.AudioSink
import androidx.media3.exoplayer.audio.DefaultAudioSink
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService
import com.example.NovaPlayApplication
import com.example.player.BalanceAudioProcessor
import com.google.common.util.concurrent.ListenableFuture
import com.google.common.util.concurrent.SettableFuture
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import timber.log.Timber

@OptIn(UnstableApi::class)
class NovaPlaybackService : MediaSessionService() {

    private var player: ExoPlayer? = null
    private var mediaSession: MediaSession? = null

    override fun onCreate() {
        super.onCreate()
        Timber.d("NovaPlaybackService: Created")

        val app = application as? NovaPlayApplication
        val balanceAudioProcessor = app?.container?.balanceAudioProcessor

        // Initialize ExoPlayer with AudioAttributes and automatic focus handling
        val audioAttributes = androidx.media3.common.AudioAttributes.Builder()
            .setContentType(androidx.media3.common.C.AUDIO_CONTENT_TYPE_MUSIC)
            .setUsage(androidx.media3.common.C.USAGE_MEDIA)
            .build()

        // Configure renderers factory with custom balance audio processor
        val renderersFactory = object : DefaultRenderersFactory(this) {
            override fun buildAudioSink(
                context: Context,
                enableFloatOutput: Boolean,
                enableAudioTrackPlaybackParams: Boolean
            ): AudioSink? {
                return if (balanceAudioProcessor != null) {
                    DefaultAudioSink.Builder(context)
                        .setAudioProcessors(arrayOf(balanceAudioProcessor))
                        .build()
                } else {
                    super.buildAudioSink(context, enableFloatOutput, enableAudioTrackPlaybackParams)
                }
            }
        }

        player = ExoPlayer.Builder(this, renderersFactory)
            .setAudioAttributes(audioAttributes, true)
            .setHandleAudioBecomingNoisy(true)
            .build()

        // Register listener for audio session changes to enable equalizer/bassboost/virtualizer
        player?.addListener(object : Player.Listener {
            override fun onAudioSessionIdChanged(audioSessionId: Int) {
                Timber.d("NovaPlaybackService: AudioSessionId changed to $audioSessionId")
                val appInstance = application as? NovaPlayApplication
                appInstance?.container?.musicPlayerManager?.onAudioSessionIdChanged(audioSessionId)
            }
        })

        // Initialize MediaSession
        val callback = object : MediaSession.Callback {
            override fun onPlaybackResumption(
                mediaSession: MediaSession,
                controller: MediaSession.ControllerInfo
            ): ListenableFuture<MediaSession.MediaItemsWithStartPosition> {
                Timber.d("NovaPlaybackService: onPlaybackResumption requested")
                val future = SettableFuture.create<MediaSession.MediaItemsWithStartPosition>()
                CoroutineScope(Dispatchers.Main).launch {
                    try {
                        val app = application as? NovaPlayApplication
                        val musicRepository = app?.container?.musicRepository

                        val prefs = getSharedPreferences("music_player_prefs", Context.MODE_PRIVATE)
                        val lastSongId = prefs.getLong("last_song_id", -1L)
                        val position = prefs.getLong("playback_position", 0L)
                        val queueIdsStr = prefs.getString("queue_ids", "") ?: ""

                        if (queueIdsStr.isNotEmpty() && musicRepository != null) {
                            val ids = queueIdsStr.split(",").mapNotNull { it.toLongOrNull() }
                            val allScannedSongs = musicRepository.scanAudio()
                            val restoredSongs = ids.mapNotNull { id -> allScannedSongs.find { it.id == id } }
                            if (restoredSongs.isNotEmpty()) {
                                val mediaItems = restoredSongs.map { song ->
                                    val metadata = androidx.media3.common.MediaMetadata.Builder()
                                        .setTitle(song.title)
                                        .setArtist(song.artist)
                                        .setAlbumTitle(song.album)
                                        .setArtworkUri(if (song.artworkUri != null) android.net.Uri.parse(song.artworkUri) else null)
                                        .build()

                                    androidx.media3.common.MediaItem.Builder()
                                        .setMediaId(song.id.toString())
                                        .setUri(android.net.Uri.parse(song.path))
                                        .setMediaMetadata(metadata)
                                        .build()
                                }
                                val targetIndex = restoredSongs.indexOfFirst { it.id == lastSongId }
                                val startIndex = if (targetIndex != -1) targetIndex else 0
                                future.set(MediaSession.MediaItemsWithStartPosition(mediaItems, startIndex, position))
                                return@launch
                            }
                        }
                        future.set(MediaSession.MediaItemsWithStartPosition(emptyList(), 0, 0L))
                    } catch (e: Exception) {
                        Timber.e(e, "NovaPlaybackService: Error resuming playback")
                        future.set(MediaSession.MediaItemsWithStartPosition(emptyList(), 0, 0L))
                    }
                }
                return future
            }
        }

        player?.let {
            mediaSession = MediaSession.Builder(this, it)
                .setId("NovaPlaybackServiceSession")
                .setCallback(callback)
                .build()
        }
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession? {
        return mediaSession
    }

    override fun onTaskRemoved(rootIntent: Intent?) {
        val player = mediaSession?.player
        if (player != null && !player.playWhenReady) {
            stopSelf()
        }
    }

    override fun onDestroy() {
        Timber.d("NovaPlaybackService: Destroying service and releasing player")
        mediaSession?.run {
            player.release()
            release()
            mediaSession = null
        }
        super.onDestroy()
    }
}
