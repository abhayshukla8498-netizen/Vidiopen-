package com.example.service

import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import androidx.annotation.OptIn
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaMetadata
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.session.*
import com.example.MainActivity
import com.google.common.util.concurrent.Futures
import com.google.common.util.concurrent.ListenableFuture
import timber.log.Timber

@OptIn(UnstableApi::class)
class VideoPlaybackService : MediaSessionService() {

    private var mediaSession: MediaSession? = null

    companion object {
        private var activePlayer: ExoPlayer? = null
        private var currentTitle: String = ""
        private var currentArtist: String = ""

        fun start(context: Context, player: ExoPlayer, title: String, artist: String) {
            activePlayer = player
            currentTitle = title
            currentArtist = artist

            // Configure audio focus and attributes
            val audioAttributes = AudioAttributes.Builder()
                .setContentType(C.AUDIO_CONTENT_TYPE_MOVIE)
                .setUsage(C.USAGE_MEDIA)
                .build()
            player.setAudioAttributes(audioAttributes, true)

            val intent = Intent(context, VideoPlaybackService::class.java)
            try {
                context.startService(intent)
            } catch (e: Exception) {
                Timber.e(e, "Failed to start VideoPlaybackService via startService, trying startForegroundService as fallback")
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    try {
                        context.startForegroundService(intent)
                    } catch (fe: Exception) {
                        Timber.e(fe, "Failed to start VideoPlaybackService via startForegroundService")
                    }
                }
            }
        }

        fun stop(context: Context) {
            activePlayer = null
            val intent = Intent(context, VideoPlaybackService::class.java)
            context.stopService(intent)
        }
    }

    override fun onCreate() {
        super.onCreate()
        Timber.d("VideoPlaybackService: Created")
        setupSession()
    }

    private fun setupSession() {
        val player = activePlayer ?: return
        
        val intent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val pendingIntent = PendingIntent.getActivity(
            this,
            0,
            intent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val callback = object : MediaSession.Callback {
            override fun onCustomCommand(
                session: MediaSession,
                controller: MediaSession.ControllerInfo,
                customCommand: SessionCommand,
                args: Bundle
            ): ListenableFuture<SessionResult> {
                if (customCommand.customAction == "ACTION_CLOSE") {
                    player.pause()
                    stopSelf()
                    return Futures.immediateFuture(SessionResult(SessionResult.RESULT_SUCCESS))
                }
                return super.onCustomCommand(session, controller, customCommand, args)
            }
        }

        mediaSession = MediaSession.Builder(this, player)
            .setId("VideoPlaybackServiceSession")
            .setSessionActivity(pendingIntent)
            .setCallback(callback)
            .build()

        // Setup custom Close command button in layout
        val customCommand = SessionCommand("ACTION_CLOSE", Bundle.EMPTY)
        val closeButton = CommandButton.Builder()
            .setSessionCommand(customCommand)
            .setDisplayName("Close")
            .setIconResId(android.R.drawable.ic_menu_close_clear_cancel)
            .setEnabled(true)
            .build()

        mediaSession?.setCustomLayout(listOf(closeButton))
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession? {
        return mediaSession
    }

    override fun onTaskRemoved(rootIntent: Intent?) {
        val player = mediaSession?.player
        if (player != null && !player.playWhenReady) {
            stopSelf()
        }
    }

    override fun onDestroy() {
        Timber.d("VideoPlaybackService: Destroying service")
        mediaSession?.run {
            release()
            mediaSession = null
        }
        activePlayer = null
        super.onDestroy()
    }
}
