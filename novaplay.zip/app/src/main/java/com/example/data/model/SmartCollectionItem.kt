package com.example.data.model

import androidx.compose.ui.graphics.vector.ImageVector

data class SmartCollectionItem(
    val id: String,
    val name: String,
    val icon: ImageVector,
    val videos: List<ScannedVideo>,
    val totalSize: Long = videos.sumOf { it.size },
    val coverThumbnailUrl: String? = videos.firstOrNull()?.thumbnailUrl,
    val description: String = ""
)
