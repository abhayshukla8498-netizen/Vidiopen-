package com.example.data.repository

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "music_themes_pref")

class MusicThemeRepository(private val context: Context) {
    companion object {
        val SELECTED_THEME_ID = stringPreferencesKey("selected_theme_id")
        val CUSTOM_THEME_IMAGE_URI = stringPreferencesKey("custom_theme_image_uri")
    }

    val selectedThemeId: Flow<String> = context.dataStore.data.map { preferences ->
        preferences[SELECTED_THEME_ID] ?: "nova_black"
    }

    val customThemeImageUri: Flow<String?> = context.dataStore.data.map { preferences ->
        preferences[CUSTOM_THEME_IMAGE_URI]
    }

    suspend fun saveSelectedThemeId(themeId: String) {
        context.dataStore.edit { preferences ->
            preferences[SELECTED_THEME_ID] = themeId
        }
    }

    suspend fun saveCustomThemeImageUri(uriString: String?) {
        context.dataStore.edit { preferences ->
            if (uriString != null) {
                preferences[CUSTOM_THEME_IMAGE_URI] = uriString
            } else {
                preferences.remove(CUSTOM_THEME_IMAGE_URI)
            }
        }
    }
}
