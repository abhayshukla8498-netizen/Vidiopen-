package com.example.data.model

data class ScannedSong(
    val id: Long,
    val title: String,
    val artist: String?,
    val album: String?,
    val duration: Long,
    val size: Long,
    val path: String,
    val dateAdded: Long,
    val albumId: Long,
    val artworkUri: String? = null
)
