package com.example.data.model

data class ConnectionRequest(
    val deviceIp: String,
    val deviceName: String,
    val sessionCode: String,
    val onResponse: (Boolean) -> Unit
)
