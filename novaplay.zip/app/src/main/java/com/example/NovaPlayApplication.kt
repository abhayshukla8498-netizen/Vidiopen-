package com.example

import android.app.Application
import com.example.di.AppContainer
import com.example.di.AppContainerImpl
import timber.log.Timber

class NovaPlayApplication : Application() {
    lateinit var container: AppContainer

    override fun onCreate() {
        super.onCreate()
        container = AppContainerImpl(this)
        
        // Initialize Timber logging
        Timber.plant(Timber.DebugTree())
        Timber.d("NovaPlayApplication: Initialized successfully with manual DI and Timber")
    }
}
